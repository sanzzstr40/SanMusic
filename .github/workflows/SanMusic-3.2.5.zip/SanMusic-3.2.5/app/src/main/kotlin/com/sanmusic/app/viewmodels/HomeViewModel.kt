/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.viewmodels

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sanmusic.innertube.YouTube
import com.sanmusic.innertube.models.AlbumItem
import com.sanmusic.innertube.models.Artist
import com.sanmusic.innertube.models.PlaylistItem
import com.sanmusic.innertube.models.SongItem
import com.sanmusic.innertube.models.WatchEndpoint
import com.sanmusic.innertube.models.YTItem
import com.sanmusic.innertube.models.filterExplicit
import com.sanmusic.innertube.models.filterOutNulls
import com.sanmusic.innertube.models.filterVideoSongs
import com.sanmusic.innertube.pages.ExplorePage
import com.sanmusic.innertube.pages.HomePage
import com.sanmusic.innertube.utils.completed
import com.sanmusic.innertube.utils.parseCookieString
import com.sanmusic.app.constants.HideExplicitKey
import com.sanmusic.app.constants.HideVideoSongsKey
import com.sanmusic.app.constants.InnerTubeCookieKey
import com.sanmusic.app.constants.AccountNameKey
import com.sanmusic.app.constants.AudiobookIdsKey
import com.sanmusic.app.constants.AudiobookPositionsKey
import com.sanmusic.app.constants.QuickPicks
import com.sanmusic.app.constants.QuickPicksKey
import com.sanmusic.app.constants.ShowWrappedCardKey
import com.sanmusic.app.constants.LastWrappedMonthKey
import com.sanmusic.app.constants.WrappedSeenKey
import com.sanmusic.app.constants.DataSyncIdKey
import com.sanmusic.app.constants.VisitorDataKey
import com.sanmusic.app.db.MusicDatabase
import com.sanmusic.app.db.entities.Album
import com.sanmusic.app.db.entities.LocalItem
import com.sanmusic.app.db.entities.Song
import com.sanmusic.app.db.entities.SpeedDialItem
import com.sanmusic.app.extensions.filterVideoSongs
import com.sanmusic.app.extensions.toEnum
import com.sanmusic.app.models.SimilarRecommendation
import com.sanmusic.app.ui.screens.wrapped.WrappedAudioService
import com.sanmusic.app.ui.screens.wrapped.WrappedManager
import com.sanmusic.app.utils.AUDIOBOOK_MIN_DURATION_SECONDS
import com.sanmusic.app.utils.AUDIOBOOK_RESUME_THRESHOLD_MS
import com.sanmusic.app.utils.SyncUtils
import com.sanmusic.app.utils.dataStore
import com.sanmusic.app.utils.decodeAudiobookIds
import com.sanmusic.app.utils.decodeAudiobookPositions
import com.sanmusic.app.utils.get
import com.sanmusic.app.utils.reportException
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import java.time.LocalDate
import javax.inject.Inject

data class CommunityPlaylistItem(
    val playlist: PlaylistItem,
    val songs: List<SongItem>
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext val context: Context,
    val database: MusicDatabase,
    val syncUtils: SyncUtils,
    val wrappedManager: WrappedManager,
    private val wrappedAudioService: WrappedAudioService,
) : ViewModel() {
    val isRefreshing = MutableStateFlow(false)
    val isLoading = MutableStateFlow(false)

    private val quickPicksEnum = context.dataStore.data.map {
        it[QuickPicksKey].toEnum(QuickPicks.QUICK_PICKS)
    }.distinctUntilChanged()

    val quickPicks = MutableStateFlow<List<Song>?>(null)
    val forgottenFavorites = MutableStateFlow<List<Song>?>(null)
    val keepListening = MutableStateFlow<List<LocalItem>?>(null)
    val similarRecommendations = MutableStateFlow<List<SimilarRecommendation>?>(null)
    val accountPlaylists = MutableStateFlow<List<PlaylistItem>?>(null)
    val homePage = MutableStateFlow<HomePage?>(null)
    val explorePage = MutableStateFlow<ExplorePage?>(null)
    val selectedChip = MutableStateFlow<HomePage.Chip?>(null)
    private val previousHomePage = MutableStateFlow<HomePage?>(null)

    val allLocalItems = MutableStateFlow<List<LocalItem>>(emptyList())
    val allYtItems = MutableStateFlow<List<YTItem>>(emptyList())

    val communityPlaylists = MutableStateFlow<List<CommunityPlaylistItem>?>(null)

    val pinnedSpeedDialItems: StateFlow<List<SpeedDialItem>> =
        database.speedDialDao.getAll()
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val speedDialItems: StateFlow<List<YTItem>> =
        combine(
            database.speedDialDao.getAll(),
            keepListening,
            quickPicks
        ) { pinned, keepListening, quick ->
            val pinnedItems = pinned.map { it.toYTItem() }
            val filled = pinnedItems.toMutableList()
            val targetSize = 27

            if (filled.size < targetSize) {
                keepListening?.let { k ->
                    val needed = targetSize - filled.size
                    val available = k.filter { item ->
                        filled.none { p -> p.id == item.id }
                    }.mapNotNull { item ->
                        when (item) {
                            is Song -> SongItem(
                                id = item.id,
                                title = item.title,
                                artists = item.artists.map { Artist(name = it.name, id = it.id) },
                                thumbnail = item.thumbnailUrl ?: "",
                                explicit = false,
                                musicVideoType = if (item.song.isVideo) "MUSIC_VIDEO_TYPE_OMV" else null
                            )
                            is Album -> AlbumItem(
                                browseId = item.id,
                                playlistId = item.album.playlistId ?: "",
                                title = item.title,
                                artists = item.artists.map { Artist(name = it.name, id = it.id) },
                                year = item.album.year,
                                thumbnail = item.thumbnailUrl ?: ""
                            )
                            else -> null
                        }
                    }
                    filled.addAll(available.take(needed))
                }
            }

            if (filled.size < targetSize) {
                quick?.let { q ->
                    val needed = targetSize - filled.size
                    val available = q.filter { song ->
                        filled.none { p -> p.id == song.id }
                    }.map { song ->
                        SongItem(
                            id = song.id,
                            title = song.title,
                            artists = song.artists.map { Artist(name = it.name, id = it.id) },
                            thumbnail = song.thumbnailUrl ?: "",
                            explicit = false,
                            musicVideoType = if (song.song.isVideo) "MUSIC_VIDEO_TYPE_OMV" else null
                        )
                    }
                    filled.addAll(available.take(needed))
                }
            }
            
            filled.take(targetSize)
        }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val resumeAudiobook: StateFlow<AudiobookLibraryItem?> =
        combine(
            database.allSongs(),
            context.dataStore.data,
        ) { songs, preferences ->
            val audiobookIds = decodeAudiobookIds(preferences[AudiobookIdsKey])
            val positions = decodeAudiobookPositions(preferences[AudiobookPositionsKey])
            val hideExplicit = preferences[HideExplicitKey] ?: false
            val hideVideoSongs = preferences[HideVideoSongsKey] ?: false

            songs
                .asSequence()
                .filter { !hideExplicit || !it.song.explicit }
                .filter { !hideVideoSongs || !it.song.isVideo }
                .filter { it.id in audiobookIds || it.song.duration >= AUDIOBOOK_MIN_DURATION_SECONDS }
                .mapNotNull { song ->
                    val durationMs = (song.song.duration * 1000L).coerceAtLeast(0L)
                    val positionMs = positions[song.id]?.coerceIn(0L, durationMs) ?: 0L
                    val resumable = positionMs >= AUDIOBOOK_RESUME_THRESHOLD_MS && positionMs < durationMs - AUDIOBOOK_RESUME_THRESHOLD_MS
                    if (!resumable) {
                        null
                    } else {
                        AudiobookLibraryItem(
                            song = song,
                            resumePositionMs = positionMs,
                            pinned = song.id in audiobookIds,
                        )
                    }
                }
                .maxByOrNull { it.resumePositionMs }
        }.stateIn(viewModelScope, SharingStarted.Lazily, null)

    val accountName = MutableStateFlow("Tamu")
    val accountImageUrl = MutableStateFlow<String?>(null)

	val showWrappedCard: StateFlow<Boolean> = context.dataStore.data.map { prefs ->
        val showWrappedPref = prefs[ShowWrappedCardKey] ?: false
        val lastWrappedMonth = prefs[LastWrappedMonthKey]
        val currentMonth = LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM"))
        val isNewMonth = lastWrappedMonth != currentMonth

        isNewMonth || showWrappedPref
    }.stateIn(viewModelScope, SharingStarted.Lazily, false)

    val wrappedSeen: StateFlow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[WrappedSeenKey] ?: false
    }.stateIn(viewModelScope, SharingStarted.Lazily, false)

fun markWrappedAsSeen() {
        viewModelScope.launch(Dispatchers.IO) {
            context.dataStore.edit {
                val currentMonth = java.time.LocalDate.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM"))
                it[LastWrappedMonthKey] = currentMonth
            }
        }
    }

    fun togglePin(item: YTItem) {
        viewModelScope.launch(Dispatchers.IO) {
            val speedDialItem = SpeedDialItem.fromYTItem(item)
            val isPinned = database.speedDialDao.isPinned(speedDialItem.id).first()
            if (isPinned) {
                database.speedDialDao.delete(speedDialItem.id)
            } else {
                database.speedDialDao.insert(speedDialItem)
            }
        }
    }

    fun setHomeLayoutMode(mode: com.sanmusic.app.constants.HomeLayoutMode) {
        viewModelScope.launch(Dispatchers.IO) {
            context.dataStore.edit { prefs ->
                prefs[com.sanmusic.app.constants.HomeLayoutModeKey] = mode.name
            }
        }
    }
    private fun normalizedDataSyncId(dataSyncId: String?): String? = dataSyncId
        ?.takeIf { it.isNotBlank() && it != "null" }
        ?.let {
            it.takeIf { !it.contains("||") }
                ?: it.takeIf { it.endsWith("||") }?.substringBefore("||")
                ?: it.substringAfter("||")
        }
        ?.takeIf { it.isNotBlank() && it != "null" }

    private suspend fun getQuickPicks() {
        val hideVideoSongs = context.dataStore.get(HideVideoSongsKey, false)
        when (quickPicksEnum.first()) {
            QuickPicks.QUICK_PICKS -> {
                val relatedSongs = database.quickPicks().first().filterVideoSongs(hideVideoSongs)
                val forgotten = database.forgottenFavorites().first().filterVideoSongs(hideVideoSongs).take(8)
                
                // Get similar songs from YouTube based on recent listening
                val recentSong = database.events().first().firstOrNull()?.song
                val ytSimilarSongs = mutableListOf<Song>()
                
                if (recentSong != null) {
                    val endpoint = YouTube.next(WatchEndpoint(videoId = recentSong.id)).getOrNull()?.relatedEndpoint
                    if (endpoint != null) {
                        YouTube.related(endpoint).onSuccess { page ->
                            // Convert YouTube songs to local Song format if they exist in database
                            page.songs.take(10).forEach { ytSong ->
                                database.song(ytSong.id).first()?.let { localSong ->
                                    if (!hideVideoSongs || !localSong.song.isVideo) {
                                        ytSimilarSongs.add(localSong)
                                    }
                                }
                            }
                        }
                    }
                }
                
                // Combine all sources and remove duplicates
                val combined = (relatedSongs + forgotten + ytSimilarSongs)
                    .distinctBy { it.id }
                    .shuffled()
                    .take(20)
                
                quickPicks.value = combined.ifEmpty { relatedSongs.shuffled().take(20) }
            }
            QuickPicks.LAST_LISTEN -> {
                val song = database.events().first().firstOrNull()?.song
                if (song != null && database.hasRelatedSongs(song.id)) {
                    quickPicks.value = database.getRelatedSongs(song.id).first().filterVideoSongs(hideVideoSongs).shuffled().take(20)
                }
            }
        }
    }

    private suspend fun load() {
        isLoading.value = true
        val hideExplicit = context.dataStore.get(HideExplicitKey, false)
        val hideVideoSongs = context.dataStore.get(HideVideoSongsKey, false)

        supervisorScope {
            // Local database queries - fast, run first
            launch {
                getQuickPicks()
            }
            launch {
                forgottenFavorites.value = database.forgottenFavorites().first().filterVideoSongs(hideVideoSongs).shuffled().take(20)
            }
            launch {
                val fromTimeStamp = System.currentTimeMillis() - 86400000 * 7 * 2
                val keepListeningSongs = database.mostPlayedSongs(fromTimeStamp, limit = 15, offset = 5).first().filterVideoSongs(hideVideoSongs).filter { it.song.thumbnailUrl != null }.shuffled().take(10)
                val keepListeningAlbums = database.mostPlayedAlbums(fromTimeStamp, limit = 8, offset = 2).first().filter { it.album.thumbnailUrl != null }.shuffled().take(5)
                val keepListeningArtists = database.mostPlayedArtists(fromTimeStamp).first().filter { it.artist.isYouTubeArtist && it.artist.thumbnailUrl != null }.shuffled().take(5)
                keepListening.value = (keepListeningSongs + keepListeningAlbums + keepListeningArtists).shuffled()
            }

            // Account playlists - independent
            launch {
                if (YouTube.cookie != null) {
                    YouTube.library("FEmusic_liked_playlists").completed().onSuccess {
                        accountPlaylists.value = it.items.filterIsInstance<PlaylistItem>().filterNot { it.id == "SE" }
                    }.onFailure {
                        reportException(it)
                    }
                }
            }

            // Network-heavy: similar recommendations
            launch {
                val fromTimeStamp = System.currentTimeMillis() - 86400000 * 7 * 2

                val artistRecommendations = database.mostPlayedArtists(fromTimeStamp, limit = 15).first()
                    .filter { it.artist.isYouTubeArtist }
                    .shuffled().take(4)
                    .mapNotNull {
                        val items = mutableListOf<YTItem>()
                        YouTube.artist(it.id).onSuccess { page ->
                            page.sections.takeLast(3).forEach { section ->
                                items += section.items
                            }
                        }
                        SimilarRecommendation(
                            title = it,
                            items = items
                                .distinctBy { item -> item.id }
                                .filterExplicit(hideExplicit)
                                .filterVideoSongs(hideVideoSongs)
                                .shuffled()
                                .take(12)
                                .ifEmpty { return@mapNotNull null }
                        )
                    }

                val songRecommendations = database.mostPlayedSongs(fromTimeStamp, limit = 15).first()
                    .filter { it.album != null }
                    .shuffled().take(3)
                    .mapNotNull { song ->
                        val endpoint = YouTube.next(WatchEndpoint(videoId = song.id)).getOrNull()?.relatedEndpoint ?: return@mapNotNull null
                        val page = YouTube.related(endpoint).getOrNull() ?: return@mapNotNull null
                        SimilarRecommendation(
                            title = song,
                            items = (page.songs.shuffled().take(10) +
                                    page.albums.shuffled().take(5) +
                                    page.artists.shuffled().take(3) +
                                    page.playlists.shuffled().take(3))
                                .distinctBy { it.id }
                                .filterExplicit(hideExplicit)
                                .filterVideoSongs(hideVideoSongs)
                                .shuffled()
                                .ifEmpty { return@mapNotNull null }
                        )
                    }

                val albumRecommendations = database.mostPlayedAlbums(fromTimeStamp, limit = 10).first()
                    .filter { it.album.thumbnailUrl != null }
                    .shuffled().take(2)
                    .mapNotNull { album ->
                        val items = mutableListOf<YTItem>()
                        YouTube.album(album.id).onSuccess { page ->
                            page.otherVersions.let { items += it }
                        }
                        album.artists.firstOrNull()?.id?.let { artistId ->
                            YouTube.artist(artistId).onSuccess { page ->
                                page.sections.lastOrNull()?.items?.let { items += it }
                            }
                        }
                        SimilarRecommendation(
                            title = album,
                            items = items
                                .distinctBy { it.id }
                                .filterExplicit(hideExplicit)
                                .filterVideoSongs(hideVideoSongs)
                                .shuffled()
                                .take(10)
                                .ifEmpty { return@mapNotNull null }
                        )
                    }

                similarRecommendations.value = (artistRecommendations + songRecommendations + albumRecommendations).shuffled()
            }

            // Home page - independent
            launch {
                YouTube.home().onSuccess { page ->
                    homePage.value = page.copy(
                        sections = page.sections.mapNotNull { section ->
                            val filtered = section.items
                                .filterOutNulls()
                                .filterExplicit(hideExplicit)
                                .filterVideoSongs(hideVideoSongs)
                            if (filtered.isEmpty()) null else section.copy(items = filtered)
                        }
                    )
                }.onFailure {
                    reportException(it)
                }
            }

            // Explore page - independent
            launch {
                YouTube.explore().onSuccess { page ->
                    explorePage.value = page.copy(
                        newReleaseAlbums = page.newReleaseAlbums.filterExplicit(hideExplicit)
                    )
                }.onFailure {
                    reportException(it)
                }

                if (explorePage.value?.podcasts.isNullOrEmpty()) {
                    YouTube.podcasts().onSuccess { podcastsPage ->
                        explorePage.value = explorePage.value?.copy(
                            podcasts = podcastsPage.featured
                        )
                    }.onFailure {
                        reportException(it)
                    }
                }

                if (explorePage.value?.mixes.isNullOrEmpty()) {
                    YouTube.mixes().onSuccess { mixesPage ->
                        explorePage.value = explorePage.value?.copy(
                            mixes = mixesPage.mixes
                        )
                    }.onFailure {
                        reportException(it)
                    }
                }
            }
        }

        allLocalItems.value = (quickPicks.value.orEmpty() + forgottenFavorites.value.orEmpty() + keepListening.value.orEmpty())
            .filter { it is Song || it is Album }
        allYtItems.value = similarRecommendations.value?.flatMap { it.items }.orEmpty() +
                homePage.value?.sections?.flatMap { it.items }.orEmpty()

        isLoading.value = false

        viewModelScope.launch(Dispatchers.IO) { getCommunityPlaylists() }
    }

    private suspend fun getCommunityPlaylists() {
        val fromTimeStamp = System.currentTimeMillis() - 86400000L * 7 * 4
        val artistSeeds = database.mostPlayedArtists(fromTimeStamp, limit = 10).first()
            .filter { it.artist.isYouTubeArtist }
            .shuffled().take(3)
        val songSeeds = database.mostPlayedSongs(fromTimeStamp, limit = 5).first()
            .shuffled().take(2)

        val candidatePlaylists = java.util.Collections.synchronizedList(mutableListOf<PlaylistItem>())

        supervisorScope {
            artistSeeds.map { seed ->
                launch(Dispatchers.IO) {
                    YouTube.artist(seed.id).onSuccess { page ->
                        page.sections.forEach { section ->
                            section.items.filterIsInstance<PlaylistItem>().forEach { playlist ->
                                if (playlist.author?.name != "YouTube Music" && 
                                    playlist.author?.name != "YouTube" && 
                                    playlist.author?.name != "Playlist" &&
                                    playlist.author?.name != seed.artist.name &&
                                    !playlist.id.startsWith("RD") &&
                                    !playlist.id.startsWith("OLAK")
                                ) {
                                    candidatePlaylists.add(playlist)
                                }
                            }
                        }
                    }
                }
            }
            
            songSeeds.map { seed ->
                launch(Dispatchers.IO) {
                    val endpoint = YouTube.next(WatchEndpoint(videoId = seed.id)).getOrNull()?.relatedEndpoint
                    if (endpoint != null) {
                        YouTube.related(endpoint).onSuccess { page ->
                            page.playlists.forEach { playlist ->
                                if (playlist.author?.name != "YouTube Music" && 
                                    playlist.author?.name != "YouTube" && 
                                    playlist.author?.name != "Playlist" &&
                                    !playlist.id.startsWith("RD") &&
                                    !playlist.id.startsWith("OLAK")
                                ) {
                                    candidatePlaylists.add(playlist)
                                }
                            }
                        }
                    }
                }
            }
        }

        val uniqueCandidates = candidatePlaylists.distinctBy { it.id }.shuffled().take(5)

        val playlists = java.util.Collections.synchronizedList(mutableListOf<CommunityPlaylistItem>())

        supervisorScope {
            uniqueCandidates.map { playlist ->
                launch(Dispatchers.IO) {
                    YouTube.playlist(playlist.id).onSuccess { page ->
                        val songs = page.songs.take(10)
                        if (songs.isNotEmpty()) {
                            val songCountText = page.playlist.songCountText ?: playlist.songCountText
                            val updatedPlaylist = playlist.copy(songCountText = songCountText)
                            playlists.add(CommunityPlaylistItem(updatedPlaylist, songs))
                        }
                    }
                }
            }.forEach { it.join() }
        }

        communityPlaylists.value = playlists.shuffled()
    }

    private val _isLoadingMore = MutableStateFlow(false)
    fun loadMoreYouTubeItems(continuation: String?) {
        if (continuation == null || _isLoadingMore.value) return
        val hideExplicit = context.dataStore.get(HideExplicitKey, false)
        val hideVideoSongs = context.dataStore.get(HideVideoSongsKey, false)

        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingMore.value = true
            val nextSections = YouTube.home(continuation).getOrNull() ?: run {
                _isLoadingMore.value = false
                return@launch
            }

            val existingTitles = homePage.value?.sections.orEmpty().map { it.title }.toSet()
            val newSections = nextSections.sections.filter { it.title !in existingTitles }
            homePage.value = nextSections.copy(
                chips = homePage.value?.chips,
                sections = (homePage.value?.sections.orEmpty() + newSections).mapNotNull { section ->
                    val filtered = section.items
                        .filterOutNulls()
                        .filterExplicit(hideExplicit)
                        .filterVideoSongs(hideVideoSongs)
                    if (filtered.isEmpty()) null else section.copy(items = filtered)
                }
            )
            _isLoadingMore.value = false
        }
    }

    fun toggleChip(chip: HomePage.Chip?) {
        if (chip == null || chip == selectedChip.value && previousHomePage.value != null) {
            homePage.value = previousHomePage.value
            previousHomePage.value = null
            selectedChip.value = null
            return
        }

        if (selectedChip.value == null) {
            previousHomePage.value = homePage.value
        }

        viewModelScope.launch(Dispatchers.IO) {
            val hideExplicit = context.dataStore.get(HideExplicitKey, false)
            val hideVideoSongs = context.dataStore.get(HideVideoSongsKey, false)
            val nextSections = YouTube.home(params = chip.endpoint?.params).getOrNull() ?: return@launch

            homePage.value = nextSections.copy(
                chips = homePage.value?.chips,
                sections = nextSections.sections.mapNotNull { section ->
                    val filtered = section.items
                        .filterOutNulls()
                        .filterExplicit(hideExplicit)
                        .filterVideoSongs(hideVideoSongs)
                    if (filtered.isEmpty()) null else section.copy(items = filtered)
                }
            )
            selectedChip.value = chip
        }
    }

    fun refresh() {
        if (isRefreshing.value) return
        viewModelScope.launch(Dispatchers.IO) {
            isRefreshing.value = true
            load()
            isRefreshing.value = false
        }
        // Run sync when user manually refreshes
        viewModelScope.launch(Dispatchers.IO) {
            syncUtils.tryAutoSync()
        }
    }

    init {
        // Load home data whenever the effective YouTube session changes. Login writes cookie,
        // visitor data, and dataSyncId separately, so waiting on cookie alone can load stale
        // guest content until the app is restarted.
        viewModelScope.launch(Dispatchers.IO) {
            context.dataStore.data
                .map { prefs ->
                    Triple(
                        prefs[InnerTubeCookieKey],
                        prefs[VisitorDataKey],
                        normalizedDataSyncId(prefs[DataSyncIdKey])
                    )
                }
                .distinctUntilChanged()
                .collectLatest { (cookie, visitorData, dataSyncId) ->
                    YouTube.cookie = cookie
                    YouTube.visitorData = visitorData?.takeIf { it.isNotBlank() && it != "null" } ?: YouTube.visitorData
                    YouTube.dataSyncId = dataSyncId
                    load()
                }
        }
        
        // Run sync in separate coroutine with cooldown to avoid blocking UI
        viewModelScope.launch(Dispatchers.IO) {
            syncUtils.tryAutoSync()
        }

        // Prepare wrapped data in background
        viewModelScope.launch(Dispatchers.IO) {
            showWrappedCard.collect { shouldShow ->
                if (shouldShow && !wrappedManager.state.value.isDataReady) {
                    try {
                        wrappedManager.prepare()
                        val state = wrappedManager.state.first { it.isDataReady }
                        val trackMap = state.trackMap
                        if (trackMap.isNotEmpty()) {
                            val firstTrackId = trackMap.entries.first().value
                            wrappedAudioService.prepareTrack(firstTrackId)
                        }
                    } catch (e: Exception) {
                        reportException(e)
                    }
                }
            }
        }

        // Listen for complete session changes and reload account data. A cookie without the
        // matching dataSyncId is not enough for account/account_menu and may return guest-like
        // results, especially right after WebView login.
        viewModelScope.launch(Dispatchers.IO) {
            context.dataStore.data
                .map { prefs ->
                    Triple(
                        prefs[InnerTubeCookieKey],
                        prefs[VisitorDataKey],
                        normalizedDataSyncId(prefs[DataSyncIdKey])
                    )
                }
                .distinctUntilChanged()
                .collectLatest { (cookie, visitorData, dataSyncId) ->
                    val isLoggedIn = cookie?.let { "SAPISID" in parseCookieString(it) } == true
                    if (!isLoggedIn) {
                        accountName.value = "Tamu"
                        accountImageUrl.value = null
                        accountPlaylists.value = null
                        return@collectLatest
                    }

                    // Show the last verified identity immediately while refreshing it. Without
                    // this hydration every ViewModel recreation incorrectly displayed "Guest".
                    accountName.value = context.dataStore.get(AccountNameKey, "")
                        .takeIf { it.isNotBlank() }
                        ?: accountName.value.takeUnless { it == "Guest" || it == "Tamu" }
                        ?: "Telah Masuk"

                    YouTube.cookie = cookie
                    YouTube.visitorData = visitorData?.takeIf { it.isNotBlank() }
                    YouTube.dataSyncId = dataSyncId

                    YouTube.accountInfo().onSuccess { info ->
                        accountName.value = info.name
                        accountImageUrl.value = info.thumbnailUrl
                        context.dataStore.edit { prefs ->
                            prefs[AccountNameKey] = info.name
                        }
                    }.onFailure {
                        reportException(it)
                    }

                    YouTube.library("FEmusic_liked_playlists").completed().onSuccess {
                        accountPlaylists.value = it.items.filterIsInstance<PlaylistItem>().filterNot { playlist -> playlist.id == "SE" }
                    }.onFailure {
                        reportException(it)
                    }
                }
        }
    }
}
