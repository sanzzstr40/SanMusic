/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.lyrics

import android.content.Context
import com.sanmusic.music.betterlyrics.BetterLyrics
import com.sanmusic.app.constants.EnableBetterLyricsKey
import com.sanmusic.app.utils.dataStore
import com.sanmusic.app.utils.get

object BetterLyricsProvider : LyricsProvider {
    override val name = "BetterLyrics"

    override fun isEnabled(context: Context): Boolean = context.dataStore[EnableBetterLyricsKey] ?: true

    override suspend fun getLyrics(
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = BetterLyrics.getLyrics(title, artist, duration, album)
}
