/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.viewmodels

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sanmusic.innertube.YouTube
import com.sanmusic.innertube.models.filterExplicit
import com.sanmusic.innertube.pages.ExplorePage
import com.sanmusic.innertube.PodcastsPage
import com.sanmusic.innertube.MixesPage
import com.sanmusic.innertube.Top100ChartsPage
import com.sanmusic.app.constants.HideExplicitKey
import com.sanmusic.app.db.MusicDatabase
import com.sanmusic.app.utils.dataStore
import com.sanmusic.app.utils.get
import com.sanmusic.app.utils.reportException
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ExploreViewModel
@Inject
constructor(
    @ApplicationContext val context: Context,
    val database: MusicDatabase,
) : ViewModel() {
    val explorePage = MutableStateFlow<ExplorePage?>(null)
    val podcastsPage = MutableStateFlow<PodcastsPage?>(null)
    val mixesPage = MutableStateFlow<MixesPage?>(null)
    val top100ChartsPage = MutableStateFlow<Top100ChartsPage?>(null)

    private suspend fun loadPodcastsInternal() {
        YouTube.podcasts().onSuccess { page ->
            podcastsPage.value = page
        }.onFailure {
            reportException(it)
        }
    }

    private suspend fun loadMixesInternal() {
        YouTube.mixes().onSuccess { page ->
            mixesPage.value = page
        }.onFailure {
            reportException(it)
        }
    }

    private suspend fun loadTop100ChartsInternal(countryCode: String = "US") {
        YouTube.getTop100Charts(countryCode).onSuccess { page ->
            top100ChartsPage.value = page
        }.onFailure {
            reportException(it)
        }
    }

    private suspend fun load() {
        YouTube
            .explore()
            .onSuccess { page ->
                val artists: MutableMap<Int, String> = mutableMapOf()
                val favouriteArtists: MutableMap<Int, String> = mutableMapOf()
                database.allArtistsByPlayTime().first().let { list ->
                    var favIndex = 0
                    for ((artistsIndex, artist) in list.withIndex()) {
                        artists[artistsIndex] = artist.id
                        if (artist.artist.bookmarkedAt != null) {
                            favouriteArtists[favIndex] = artist.id
                            favIndex++
                        }
                    }
                }
                // Use podcasts/mixes from explore page itself, fall back to separate browse calls
                val podcasts = page.podcasts.ifEmpty { podcastsPage.value?.featured ?: emptyList() }
                val mixes = page.mixes.ifEmpty { mixesPage.value?.mixes ?: emptyList() }
                explorePage.value =
                    page.copy(
                        newReleaseAlbums =
                        page.newReleaseAlbums
                            .sortedBy { album ->
                                val artistIds = album.artists.orEmpty().mapNotNull { it.id }
                                val firstArtistKey =
                                    artistIds.firstNotNullOfOrNull { artistId ->
                                        if (artistId in favouriteArtists.values) {
                                            favouriteArtists.entries.firstOrNull { it.value == artistId }?.key
                                        } else {
                                            artists.entries.firstOrNull { it.value == artistId }?.key
                                        }
                                    } ?: Int.MAX_VALUE
                                firstArtistKey
                            }.filterExplicit(context.dataStore.get(HideExplicitKey, false)),
                        podcasts = podcasts,
                        mixes = mixes,
                    )
            }.onFailure {
                reportException(it)
            }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            load()
            // If explore() didn't find podcasts/mixes sections, try separate browse calls
            if (explorePage.value?.podcasts.isNullOrEmpty()) loadPodcastsInternal()
            if (explorePage.value?.mixes.isNullOrEmpty()) loadMixesInternal()
        }
        viewModelScope.launch(Dispatchers.IO) {
            loadTop100ChartsInternal()
        }
    }

    fun loadPodcasts() = viewModelScope.launch(Dispatchers.IO) { loadPodcastsInternal() }
    fun loadMixes() = viewModelScope.launch(Dispatchers.IO) { loadMixesInternal() }
    fun loadTop100Charts(countryCode: String = "US") = viewModelScope.launch(Dispatchers.IO) { loadTop100ChartsInternal(countryCode) }
}
