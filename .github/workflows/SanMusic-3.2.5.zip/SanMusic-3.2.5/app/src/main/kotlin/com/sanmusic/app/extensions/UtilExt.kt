/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.extensions

fun <T> tryOrNull(block: () -> T): T? =
    try {
        block()
    } catch (e: Exception) {
        null
    }
