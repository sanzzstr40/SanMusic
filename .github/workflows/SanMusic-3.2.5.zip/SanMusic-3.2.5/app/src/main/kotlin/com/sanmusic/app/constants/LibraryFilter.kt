/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.constants

enum class LibraryFilter {
    SONGS,
    ARTISTS,
    ALBUMS,
    PLAYLISTS,
    AUDIOBOOKS,
    LIBRARY,
}
