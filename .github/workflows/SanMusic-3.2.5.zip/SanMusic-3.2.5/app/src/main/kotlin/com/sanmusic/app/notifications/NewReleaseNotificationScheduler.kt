/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object NewReleaseNotificationScheduler {
    const val ACTION_CHECK_NEW_RELEASES = "com.sanmusic.app.notifications.ACTION_CHECK_NEW_RELEASES"

    private const val REQUEST_CODE = 4207

    fun schedule(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.setInexactRepeating(
            AlarmManager.RTC,
            nextCheckTimeMillis(),
            AlarmManager.INTERVAL_HOUR,
            pendingIntent(context),
        )
    }

    fun cancel(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(pendingIntent(context))
    }

    private fun pendingIntent(context: Context): PendingIntent =
        PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            Intent(context, NewReleaseNotificationReceiver::class.java).setAction(ACTION_CHECK_NEW_RELEASES),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

    private fun nextCheckTimeMillis(): Long =
        Calendar.getInstance().apply {
            add(Calendar.MINUTE, 15)
        }.timeInMillis
}
