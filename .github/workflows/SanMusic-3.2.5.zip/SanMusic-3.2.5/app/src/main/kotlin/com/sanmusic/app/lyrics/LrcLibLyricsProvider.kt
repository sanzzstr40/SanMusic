/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.lyrics

import android.content.Context
import com.sanmusic.lrclib.LrcLib
import com.sanmusic.app.constants.EnableLrcLibKey
import com.sanmusic.app.utils.dataStore
import com.sanmusic.app.utils.get

object LrcLibLyricsProvider : LyricsProvider {
    override val name = "LrcLib"

    override fun isEnabled(context: Context): Boolean = context.dataStore[EnableLrcLibKey] ?: true

    override suspend fun getLyrics(
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = LrcLib.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        LrcLib.getAllLyrics(title, artist, duration, album, callback)
    }
}
