/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.di

import com.sanmusic.app.voice.VoiceCommandManager
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@EntryPoint
@InstallIn(SingletonComponent::class)
interface VoiceCommandEntryPoint {
    fun voiceCommandManager(): VoiceCommandManager
}
