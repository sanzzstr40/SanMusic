/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.add
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalWindowInfo
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.fastAny
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.net.toUri
import androidx.core.util.Consumer
import androidx.core.view.WindowCompat
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.coroutineScope
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import coil3.compose.AsyncImage
import coil3.imageLoader
import coil3.request.CachePolicy
import coil3.request.ImageRequest
import coil3.request.allowHardware
import coil3.request.crossfade
import coil3.toBitmap
import com.sanmusic.innertube.YouTube
import com.sanmusic.innertube.models.SongItem
import com.sanmusic.innertube.models.WatchEndpoint
import com.sanmusic.app.constants.AppBarHeight
import com.sanmusic.app.constants.AppLanguageKey
import com.sanmusic.app.constants.CheckForUpdatesKey
import com.sanmusic.app.constants.DarkModeKey
import com.sanmusic.app.constants.DefaultOpenTabKey
import com.sanmusic.app.constants.DisableScreenshotKey
import com.sanmusic.app.constants.DynamicThemeKey
import com.sanmusic.app.constants.EnableHighRefreshRateKey
import com.sanmusic.app.constants.ListenTogetherUsernameKey
import com.sanmusic.app.constants.MiniPlayerBottomSpacing
import com.sanmusic.app.constants.MiniPlayerHeight
import com.sanmusic.app.constants.NavigationBarAnimationSpec
import com.sanmusic.app.constants.NavigationBarHeight
import com.sanmusic.app.constants.PauseSearchHistoryKey
import com.sanmusic.app.constants.PureBlackKey
import com.sanmusic.app.constants.SYSTEM_DEFAULT
import com.sanmusic.app.constants.SelectedThemeColorKey
import com.sanmusic.app.constants.SlimNavBarHeight
import com.sanmusic.app.constants.SlimNavBarKey
import com.sanmusic.app.constants.StopMusicOnTaskClearKey
import com.sanmusic.app.constants.UseNewMiniPlayerDesignKey
import com.sanmusic.app.constants.SelectedFontKey
import com.sanmusic.app.constants.FontScaleKey
import com.sanmusic.app.constants.FontBoldnessKey
import com.sanmusic.app.db.MusicDatabase
import com.sanmusic.app.db.entities.SearchHistory
import com.sanmusic.app.extensions.toEnum
import com.sanmusic.app.extensions.toMediaItem
import com.sanmusic.app.models.toMediaMetadata
import com.sanmusic.app.playback.DownloadUtil
import com.sanmusic.app.playback.MusicService
import com.sanmusic.app.playback.MusicService.MusicBinder
import com.sanmusic.app.playback.PlayerConnection
import com.sanmusic.app.playback.queues.YouTubeQueue
import com.sanmusic.app.ui.component.AccountSettingsDialog
import com.sanmusic.app.ui.component.AppNavigationBar
import com.sanmusic.app.ui.component.AppNavigationRail
import com.sanmusic.app.ui.component.BottomSheetMenu
import com.sanmusic.app.ui.component.BottomSheetPage
import com.sanmusic.app.ui.component.LocalBottomSheetPageState
import com.sanmusic.app.ui.component.LocalMenuState
import com.sanmusic.app.ui.component.UpdateAvailableDialog
import com.sanmusic.app.ui.component.rememberBottomSheetState
import com.sanmusic.app.ui.component.shimmer.ShimmerTheme
import com.sanmusic.app.ui.menu.YouTubeSongMenu
import com.sanmusic.app.ui.player.BottomSheetPlayer
import com.sanmusic.app.ui.screens.Screens
import com.sanmusic.app.ui.screens.navigationBuilder
import com.sanmusic.app.ui.screens.settings.DarkMode
import com.sanmusic.app.ui.screens.settings.NavigationTab
import com.sanmusic.app.ui.theme.ColorSaver
import com.sanmusic.app.ui.theme.DefaultThemeColor
import com.sanmusic.app.ui.theme.AuraMusicTheme
import com.sanmusic.app.ui.theme.extractThemeColor
import com.sanmusic.app.ui.utils.appBarScrollBehavior
import com.sanmusic.app.ui.utils.frostedGlassSurface
import com.sanmusic.app.ui.utils.liquidGlassPill
import com.sanmusic.app.ui.utils.resetHeightOffset
import com.sanmusic.app.utils.SyncUtils
import com.sanmusic.app.utils.UpdateInfo
import com.sanmusic.app.utils.Updater
import com.sanmusic.app.utils.dataStore
import com.sanmusic.app.utils.get
import com.sanmusic.app.utils.rememberEnumPreference
import com.sanmusic.app.utils.rememberPreference
import com.sanmusic.app.utils.reportException
import com.sanmusic.app.utils.setAppLocale
import com.sanmusic.app.viewmodels.HomeViewModel
import com.sanmusic.app.voice.LocalVoiceCommandController
import com.sanmusic.app.voice.VoiceCommandController
import com.sanmusic.app.voice.VoiceCommandOverlay
import com.sanmusic.app.voice.VoiceCommandViewModel
import com.sanmusic.app.streak.StreakManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.DisposableEffect
import com.valentinilk.shimmer.LocalShimmerTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.Locale
import javax.inject.Inject

@Suppress("DEPRECATION", "ASSIGNED_BUT_NEVER_ACCESSED_VARIABLE")
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    companion object {
        private const val ACTION_SEARCH = "com.sanmusic.app.action.SEARCH"
        private const val ACTION_LIBRARY = "com.sanmusic.app.action.LIBRARY"
    }

    private fun isRunningOnTv(): Boolean {
        val uiModeManager = getSystemService(UI_MODE_SERVICE) as android.app.UiModeManager
        return uiModeManager.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
               packageManager.hasSystemFeature("android.software.leanback")
    }



    @Inject
    lateinit var database: MusicDatabase

    @Inject
    lateinit var downloadUtil: DownloadUtil

    @Inject
    lateinit var syncUtils: SyncUtils
    
    @Inject
    lateinit var listenTogetherManager: com.sanmusic.app.listentogether.ListenTogetherManager

    @Inject
    lateinit var hardwareIntegrationManager: com.sanmusic.app.hardware.HardwareIntegrationManager

    private lateinit var navController: NavHostController
    private var pendingIntent: Intent? = null
    private var latestVersionName by mutableStateOf(BuildConfig.VERSION_NAME)
    private var pendingUpdateInfo by mutableStateOf<UpdateInfo?>(null)
    private var hasCheckedUpdateOnLaunch = false
    private var sharedImportUrl by mutableStateOf<String?>(null)

    private var playerConnection by mutableStateOf<PlayerConnection?>(null)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            if (service is MusicBinder) {
                try {
                    playerConnection = PlayerConnection(this@MainActivity, service, database, lifecycleScope)
                    Timber.tag("MainActivity").d("PlayerConnection created successfully")
                    // Connect Listen Together manager to player
                    listenTogetherManager.setPlayerConnection(playerConnection)
                } catch (e: Exception) {
                    Timber.tag("MainActivity").e(e, "Failed to create PlayerConnection")
                    // Retry after a delay of 500ms
                    lifecycleScope.launch {
                        delay(500)
                        try {
                            playerConnection = PlayerConnection(this@MainActivity, service, database, lifecycleScope)
                            listenTogetherManager.setPlayerConnection(playerConnection)
                        } catch (e2: Exception) {
                            Timber.tag("MainActivity").e(e2, "Failed to create PlayerConnection on retry")
                        }
                    }
                }
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            // Disconnect Listen Together manager
            listenTogetherManager.setPlayerConnection(null)
            playerConnection?.dispose()
            playerConnection = null
        }
    }

    override fun onStart() {
        super.onStart()
        com.sanmusic.app.ui.component.DynamicIslandOverlayState.setAppInForeground(true)
        // Request notification permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1000)
            }
        }

        // On Android 12+, we can't start foreground services from background
        // Use BIND_AUTO_CREATE which will create the service if needed
        // The service will call startForeground() in onCreate() when bound
        bindService(
            Intent(this, MusicService::class.java),
            serviceConnection,
            BIND_AUTO_CREATE
        )
    }

    override fun onStop() {
        com.sanmusic.app.ui.component.DynamicIslandOverlayState.setAppInForeground(false)
        val isCurrentlyPlaying = playerConnection?.isPlaying?.value == true
        if (isFinishing || !isCurrentlyPlaying) {
            com.sanmusic.app.ui.component.DynamicIslandOverlayState.resetOnAppExit(this)
        }
        unbindService(serviceConnection)
        super.onStop()
    }

    override fun onDestroy() {
        com.sanmusic.app.ui.component.DynamicIslandOverlayState.resetOnAppExit(this)
        super.onDestroy()
        if (dataStore.get(StopMusicOnTaskClearKey, false) && 
            playerConnection?.isPlaying?.value == true && 
            isFinishing
        ) {
            stopService(Intent(this, MusicService::class.java))
            unbindService(serviceConnection)
            playerConnection = null
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (::navController.isInitialized) {
            handleDeepLinkIntent(intent, navController)
        } else {
            pendingIntent = intent
        }
    }

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.sanmusic.app.utils.SecurityGuard.verifyRuntimeIntegrity(this)

        // For TV builds, use TV activity directly
        if (BuildConfig.FLAVOR.contains("tv")) {
            try {
                val tvActivityClass = Class.forName("com.sanmusic.app.TvMainActivity")
                val intent = Intent(this, tvActivityClass.asSubclass(Activity::class.java))
                startActivity(intent)
                finish()
                return
            } catch (e: ClassNotFoundException) {
                // TV activity not found, continue with normal UI
            }
        }

        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_LTR
        WindowCompat.setDecorFitsSystemWindows(window, false)
        
        // Initialize Listen Together manager
        listenTogetherManager.initialize()

        // Start hardware integration discovery
        hardwareIntegrationManager.start()

        val indonesianLocale = Locale("id", "ID")
        Locale.setDefault(indonesianLocale)
        setAppLocale(this, indonesianLocale)

        lifecycleScope.launch {
            com.sanmusic.app.ui.component.DynamicIslandOverlayState.initializeOnAppProcessStart(this@MainActivity)
        }

        lifecycleScope.launch {
            dataStore.data
                .map { it[DisableScreenshotKey] ?: false }
                .distinctUntilChanged()
                .collectLatest {
                    if (it) {
                        window.setFlags(
                            WindowManager.LayoutParams.FLAG_SECURE,
                            WindowManager.LayoutParams.FLAG_SECURE,
                        )
                    } else {
                        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    }
                }
        }

        setContent {
            AuraMusicApp(
                latestVersionName = latestVersionName,
                onLatestVersionNameChange = { latestVersionName = it },
                playerConnection = playerConnection,
                database = database,
                downloadUtil = downloadUtil,
                syncUtils = syncUtils,
            )
        }
    }

    @SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun AuraMusicApp(
        latestVersionName: String,
        onLatestVersionNameChange: (String) -> Unit,
        playerConnection: PlayerConnection?,
        database: MusicDatabase,
        downloadUtil: DownloadUtil,
        syncUtils: SyncUtils,
    ) {
        // Automatic update check once per app launch (raw GitHub version.json)
        LaunchedEffect(Unit) {
            if (hasCheckedUpdateOnLaunch) return@LaunchedEffect
            hasCheckedUpdateOnLaunch = true

            val updatesEnabled = withContext(Dispatchers.IO) {
                runCatching { dataStore.get(CheckForUpdatesKey, true) }.getOrDefault(true)
            }
            if (!updatesEnabled) {
                onLatestVersionNameChange(BuildConfig.VERSION_NAME)
                return@LaunchedEffect
            }

            val result = Updater.checkForUpdateOnLaunch(this@MainActivity)
            if (result != null && result.hasUpdate) {
                onLatestVersionNameChange(result.updateInfo.versionName)
                if (result.shouldShowDialog && !isFinishing && !isDestroyed) {
                    pendingUpdateInfo = result.updateInfo
                }
            } else {
                onLatestVersionNameChange(BuildConfig.VERSION_NAME)
            }
        }

        val enableDynamicTheme by rememberPreference(DynamicThemeKey, defaultValue = false)
        val enableHighRefreshRate by rememberPreference(EnableHighRefreshRateKey, defaultValue = true)

        LaunchedEffect(enableHighRefreshRate) {
            val window = this@MainActivity.window
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val layoutParams = window.attributes
                if (enableHighRefreshRate) {
                    layoutParams.preferredDisplayModeId = 0
                } else {
                    val modes = window.windowManager.defaultDisplay.supportedModes
                    val mode60 = modes.firstOrNull { kotlin.math.abs(it.refreshRate - 60f) < 1f }
                        ?: modes.minByOrNull { kotlin.math.abs(it.refreshRate - 60f) }

                    if (mode60 != null) {
                        layoutParams.preferredDisplayModeId = mode60.modeId
                    }
                }
                window.attributes = layoutParams
            } else {
                val params = window.attributes
                if (enableHighRefreshRate) {
                    params.preferredRefreshRate = 0f
                } else {
                    params.preferredRefreshRate = 60f
                }
                window.attributes = params
            }
        }

        val (darkTheme, onDarkThemeChange) = rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.ON)
        val useDarkTheme = remember(darkTheme) {
            darkTheme != DarkMode.OFF
        }

        LaunchedEffect(useDarkTheme) {
            setSystemBarAppearance(useDarkTheme)
        }

        val pureBlack = useDarkTheme

        val selectedFont by rememberPreference(SelectedFontKey, defaultValue = "DEFAULT")
        val fontScale by rememberPreference(FontScaleKey, defaultValue = 1f)
        val fontBoldness by rememberPreference(FontBoldnessKey, defaultValue = 0f)

        var themeColor by rememberSaveable(stateSaver = ColorSaver) {
            mutableStateOf(DefaultThemeColor)
        }

        LaunchedEffect(enableDynamicTheme) {
            if (!enableDynamicTheme) {
                themeColor = DefaultThemeColor
            }
        }

        LaunchedEffect(playerConnection, enableDynamicTheme) {
            val playerConnection = playerConnection
            if (!enableDynamicTheme || playerConnection == null) {
                themeColor = DefaultThemeColor
                return@LaunchedEffect
            }

            playerConnection.service.currentMediaMetadata.collectLatest { song ->
                if (song?.thumbnailUrl != null) {
                    withContext(Dispatchers.IO) {
                        try {
                            val result = imageLoader.execute(
                                ImageRequest.Builder(this@MainActivity)
                                    .data(song.thumbnailUrl)
                                    .allowHardware(false)
                                    .memoryCachePolicy(CachePolicy.ENABLED)
                                    .diskCachePolicy(CachePolicy.ENABLED)
                                    .networkCachePolicy(CachePolicy.ENABLED)
                                    .crossfade(false)
                                    .build()
                            )
                            themeColor = result.image?.toBitmap()?.extractThemeColor() ?: DefaultThemeColor
                        } catch (e: Exception) {
                            themeColor = DefaultThemeColor
                        }
                    }
                } else {
                    themeColor = DefaultThemeColor
                }
            }
        }

        val (appVisualStyle, _) = rememberEnumPreference(
            com.sanmusic.app.constants.AppVisualStyleKey,
            defaultValue = com.sanmusic.app.constants.AppVisualStyle.LIQUID_GLASS
        )
        val (softLightMode, _) = rememberPreference(
            com.sanmusic.app.constants.SoftLightModeKey,
            defaultValue = true
        )

        AuraMusicTheme(
            darkTheme = useDarkTheme,
            pureBlack = pureBlack,
            softLight = softLightMode,
            themeColor = themeColor,
            selectedFont = selectedFont,
            fontScale = fontScale,
            fontBoldness = fontBoldness,
            visualStyle = appVisualStyle.name,
        ) {
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                com.sanmusic.app.ui.utils.GlassmorphicAmbientBackdrop(
                    isDark = useDarkTheme
                )
                val focusManager = LocalFocusManager.current
                val density = LocalDensity.current
                val configuration = LocalWindowInfo.current
                val cutoutInsets = WindowInsets.displayCutout
                val windowsInsets = WindowInsets.systemBars
                val bottomInset = with(density) { windowsInsets.getBottom(density).toDp() }
                val bottomInsetDp = WindowInsets.systemBars.asPaddingValues().calculateBottomPadding()

                val navController = rememberNavController()
                DisposableEffect(navController) {
                    this@MainActivity.navController = navController
                    com.sanmusic.app.poster.PosterSession.navigateCallback = {
                        navController.navigate("poster")
                    }
                    onDispose {
                        com.sanmusic.app.poster.PosterSession.navigateCallback = null
                    }
                }
                val homeViewModel: HomeViewModel = hiltViewModel()
                val accountImageUrl by homeViewModel.accountImageUrl.collectAsState()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val (previousTab, setPreviousTab) = rememberSaveable { mutableStateOf("home") }

                // Voice command system
                val voiceCommandViewModel: VoiceCommandViewModel = hiltViewModel()
                val voiceUiState by voiceCommandViewModel.uiState.collectAsState()

                var hasMicPermission by remember {
                    mutableStateOf(
                        ContextCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                    )
                }

                val micPermissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { granted ->
                    hasMicPermission = granted
                    voiceCommandViewModel.onMicPermissionChanged(granted)
                    if (granted) {
                        voiceCommandViewModel.startManualSession()
                    }
                }

                LaunchedEffect(Unit) {
                    voiceCommandViewModel.onMicPermissionChanged(hasMicPermission)
                    voiceCommandViewModel.onAppForeground()
                }

                DisposableEffect(Unit) {
                    onDispose {
                        voiceCommandViewModel.onAppBackground()
                    }
                }

                LaunchedEffect(playerConnection) {
                    voiceCommandViewModel.bindHandlers(
                        playerConnectionProvider = { playerConnection },
                        onSearch = { query ->
                            navController.navigate("search/$query")
                        },
                        onNavigate = { route ->
                            navController.navigate(route)
                        }
                    )
                }

                val voiceCommandController = remember(voiceCommandViewModel, hasMicPermission) {
                    object : VoiceCommandController {
                        override fun requestManualActivation() {
                            if (hasMicPermission) {
                                voiceCommandViewModel.startManualSession()
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        }
                    }
                }

                val (slimNav) = rememberPreference(SlimNavBarKey, defaultValue = false)

                LaunchedEffect(Unit) {
                    StreakManager.ensureInitialized(this@MainActivity)
                    com.sanmusic.app.streak.MusicJourneyManager.ensureInitialized(this@MainActivity)
                }

                // Navigation items: Home (Beranda), Search (Cari), Library (Pustaka), Profile (Profil)
                val navigationItems = remember {
                    listOf(Screens.Home, Screens.Search, Screens.Library, Screens.Profile)
                }
                
                val (useNewMiniPlayerDesign) = rememberPreference(UseNewMiniPlayerDesignKey, defaultValue = true)
                val defaultOpenTab = remember {
                    dataStore[DefaultOpenTabKey].toEnum(defaultValue = NavigationTab.HOME)
                }
                val tabOpenedFromShortcut = remember {
                    when (intent?.action) {
                        ACTION_SEARCH -> NavigationTab.SEARCH
                        ACTION_LIBRARY -> NavigationTab.LIBRARY
                        else -> null
                    }
                }

                val topLevelScreens = remember {
                    listOf(
                        Screens.Home.route,
                        Screens.Search.route,
                        Screens.Library.route,
                        Screens.Profile.route,
                        "listen_together",
                        "settings",
                    )
                }

                val (query, onQueryChange) = rememberSaveable(stateSaver = TextFieldValue.Saver) {
                    mutableStateOf(TextFieldValue())
                }

                val onSearch: (String) -> Unit = remember {
                    { searchQuery ->
                        if (searchQuery.isNotEmpty()) {
                            navController.navigate("search/${URLEncoder.encode(searchQuery, "UTF-8")}")

                            if (dataStore[PauseSearchHistoryKey] != true) {
                                lifecycleScope.launch(Dispatchers.IO) {
                                    database.query {
                                        insert(SearchHistory(query = searchQuery))
                                    }
                                }
                            }
                        }
                    }
                }

                // Use derivedStateOf to avoid unnecessary recompositions
                val currentRoute by remember {
                    derivedStateOf { navBackStackEntry?.destination?.route }
                }

                val inSearchScreen by remember {
                    derivedStateOf { currentRoute?.startsWith("search/") == true }
                }
                val navigationItemRoutes = remember(navigationItems) {
                    navigationItems.map { it.route }.toSet()
                }

                val shouldShowNavigationBar = remember(currentRoute, navigationItemRoutes) {
                    currentRoute == null ||
                        navigationItemRoutes.contains(currentRoute) ||
                        currentRoute!!.startsWith("search/")
                }

                val windowSize = configuration.containerDpSize
                val isLandscape = windowSize.width > windowSize.height
                val isTabletWidth = windowSize.width >= 600.dp && windowSize.height >= 480.dp

                val showRail = (isLandscape || isTabletWidth) && !inSearchScreen
                val navDragTransitionState = com.sanmusic.app.ui.component.rememberNavDragTransitionState()

                val navPadding = if (shouldShowNavigationBar && !showRail) {
                    if (slimNav) SlimNavBarHeight else NavigationBarHeight
                } else {
                    0.dp
                }

                val navigationBarHeight by animateDpAsState(
                    targetValue = if (shouldShowNavigationBar && !showRail) NavigationBarHeight else 0.dp,
                    animationSpec = NavigationBarAnimationSpec,
                    label = "navBarHeight",
                )

                val playerBottomSheetState = rememberBottomSheetState(
                    dismissedBound = 0.dp,
                    collapsedBound = bottomInset +
                        (if (!showRail && shouldShowNavigationBar) navPadding else 0.dp) +
                        (if (useNewMiniPlayerDesign) MiniPlayerBottomSpacing else 0.dp) +
                        MiniPlayerHeight,
                    expandedBound = maxHeight,
                )

                val playerAwareWindowInsets = remember(
                    bottomInset,
                    shouldShowNavigationBar,
                    playerBottomSheetState.isDismissed,
                    showRail,
                    currentRoute,
                ) {
                    var bottom = bottomInset
                    if (shouldShowNavigationBar && !showRail) {
                        bottom += NavigationBarHeight
                    }
                    if (!playerBottomSheetState.isDismissed) bottom += MiniPlayerHeight
                    val topOffset = if (currentRoute == Screens.Search.route || currentRoute == Screens.Profile.route) 0.dp else AppBarHeight
                    windowsInsets
                        .only(WindowInsetsSides.Horizontal + WindowInsetsSides.Top)
                        .add(WindowInsets(top = topOffset, bottom = bottom))
                }
                appBarScrollBehavior(
                    canScroll = {
                        !inSearchScreen &&
                            (playerBottomSheetState.isCollapsed || playerBottomSheetState.isDismissed)
                    }
                )

                val topAppBarScrollBehavior = appBarScrollBehavior(
                    canScroll = {
                        !inSearchScreen &&
                            (playerBottomSheetState.isCollapsed || playerBottomSheetState.isDismissed)
                    },
                )

                // Navigation tracking
                LaunchedEffect(navBackStackEntry) {
                    if (inSearchScreen) {
                        val searchQuery = withContext(Dispatchers.IO) {
                            if (navBackStackEntry?.arguments?.getString("query")!!.contains("%")) {
                                navBackStackEntry?.arguments?.getString("query")!!
                            } else {
                                URLDecoder.decode(
                                    navBackStackEntry?.arguments?.getString("query")!!,
                                    "UTF-8"
                                )
                            }
                        }
                        onQueryChange(
                            TextFieldValue(
                                searchQuery,
                                TextRange(searchQuery.length)
                            )
                        )
                    } else if (navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route }) {
                        onQueryChange(TextFieldValue())
                    }

                    // Reset scroll behavior for main navigation items
                    if (navigationItems.fastAny { it.route == navBackStackEntry?.destination?.route }) {
                        if (navigationItems.fastAny { it.route == previousTab }) {
                            topAppBarScrollBehavior.state.resetHeightOffset()
                        }
                    }

                    topAppBarScrollBehavior.state.resetHeightOffset()

                    // Track previous tab for animations
                    navController.currentBackStackEntry?.destination?.route?.let {
                        setPreviousTab(it)
                    }
                }

                LaunchedEffect(playerConnection) {
                    val player = playerConnection?.player ?: return@LaunchedEffect
                    if (player.currentMediaItem == null) {
                        if (!playerBottomSheetState.isDismissed) {
                            playerBottomSheetState.dismiss()
                        }
                    } else {
                        if (playerBottomSheetState.isDismissed) {
                            playerBottomSheetState.collapseSoft()
                        }
                    }
                }

                DisposableEffect(playerConnection, playerBottomSheetState) {
                    val player = playerConnection?.player ?: return@DisposableEffect onDispose { }
                    val listener = object : Player.Listener {
                        override fun onMediaItemTransition(
                            mediaItem: MediaItem?,
                            reason: Int,
                        ) {
                            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED &&
                                mediaItem != null &&
                                playerBottomSheetState.isDismissed
                            ) {
                                playerBottomSheetState.collapseSoft()
                            }
                        }
                    }
                    player.addListener(listener)
                    onDispose {
                        player.removeListener(listener)
                    }
                }

                var shouldShowTopBar by rememberSaveable { mutableStateOf(false) }

                LaunchedEffect(navBackStackEntry) {
                    val route = navBackStackEntry?.destination?.route
                    shouldShowTopBar = route in topLevelScreens &&
                        route != "settings" &&
                        route != Screens.Search.route &&
                        route != Screens.Profile.route
                }

                val coroutineScope = rememberCoroutineScope()
                var sharedSong: SongItem? by remember {
                    mutableStateOf(null)
                }
                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(Unit) {
                    if (pendingIntent != null) {
                        handleDeepLinkIntent(pendingIntent!!, navController)
                        pendingIntent = null
                    } else {
                        handleDeepLinkIntent(intent, navController)
                    }
                }

                DisposableEffect(Unit) {
                    val listener = Consumer<Intent> { intent ->
                        handleDeepLinkIntent(intent, navController)
                    }

                    addOnNewIntentListener(listener)
                    onDispose { removeOnNewIntentListener(listener) }
                }

                val currentTitleRes = remember(navBackStackEntry) {
                    when (navBackStackEntry?.destination?.route) {
                        Screens.Home.route -> R.string.home
                        Screens.Search.route -> R.string.search
                        Screens.Library.route -> R.string.filter_library
                        "listen_together" -> R.string.together
                        else -> null
                    }
                }

                var showAccountDialog by remember { mutableStateOf(false) }
                var showDynamicIslandDialog by rememberSaveable { mutableStateOf(false) }
                val (dynamicIslandAutoMode, _) = rememberPreference(
                    com.sanmusic.app.constants.DynamicIslandAutoEnableOnStartKey,
                    defaultValue = true
                )
                val (dynamicIslandEnabled, _) = rememberPreference(
                    com.sanmusic.app.constants.DynamicIslandEnabledKey,
                    defaultValue = false
                )
                val (dynamicIslandDismissed, onDynamicIslandDismissedChange) = rememberPreference(
                    com.sanmusic.app.constants.DynamicIslandDismissedKey,
                    defaultValue = false
                )

                val baseBg = if (useDarkTheme) Color.Black else Color.White

                CompositionLocalProvider(
                    LocalDatabase provides database,
                    LocalContentColor provides if (useDarkTheme) Color.White else Color(0xFF0A0C10),
                    LocalPlayerConnection provides playerConnection,
                    LocalPlayerAwareWindowInsets provides playerAwareWindowInsets,
                    LocalDownloadUtil provides downloadUtil,
                    LocalShimmerTheme provides ShimmerTheme,
                    LocalSyncUtils provides syncUtils,
                    LocalListenTogetherManager provides listenTogetherManager,
                    LocalHardwareIntegrationManager provides hardwareIntegrationManager,
                    LocalVoiceCommandController provides voiceCommandController,
                ) {

                    Scaffold(
                        containerColor = Color.Transparent,
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        topBar = {
                            AnimatedVisibility(
                                visible = shouldShowTopBar,
                                enter = fadeIn(animationSpec = tween(durationMillis = 300)),
                                exit = fadeOut(animationSpec = tween(durationMillis = 200))
                            ) {
                                val isEditorialTopBar = com.sanmusic.app.ui.theme.LocalAppVisualStyle.current == "EDITORIAL"
                                val topBarBrush = if (isEditorialTopBar) {
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.background.copy(alpha = 0.96f),
                                            MaterialTheme.colorScheme.background.copy(alpha = 0.92f)
                                        )
                                    )
                                } else if (useDarkTheme) {
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        listOf(
                                            Color(0xFF0E131D).copy(alpha = 0.88f),
                                            Color(0xFF090D14).copy(alpha = 0.76f)
                                        )
                                    )
                                } else {
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        listOf(
                                            Color(0xFFF6F9FE).copy(alpha = 0.92f),
                                            Color(0xFFEEF3FA).copy(alpha = 0.84f)
                                        )
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(topBarBrush)
                                        .windowInsetsPadding(
                                            WindowInsets.systemBars.only(WindowInsetsSides.Top)
                                        )
                                        .windowInsetsPadding(
                                            if (showRail) {
                                                WindowInsets(left = NavigationBarHeight)
                                                    .add(cutoutInsets.only(WindowInsetsSides.Start))
                                            } else {
                                                cutoutInsets.only(WindowInsetsSides.Start + WindowInsetsSides.End)
                                            }
                                        )
                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = currentTitleRes?.let { stringResource(it) } ?: "",
                                            style = MaterialTheme.typography.headlineSmall.copy(
                                                fontSize = 22.sp,
                                                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                                            ),
                                            color = if (useDarkTheme) Color.White else Color.Black,
                                            maxLines = 1
                                        )

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            val iconTint = if (useDarkTheme) Color.White else Color.Black
                                            val isLibraryRoute = currentRoute == Screens.Library.route
                                            val (localProfileAvatarUri, _) = rememberPreference(
                                                com.sanmusic.app.constants.ProfileLocalAvatarUriV2Key,
                                                defaultValue = ""
                                            )
                                            if (!isLibraryRoute) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(34.dp)
                                                        .liquidGlassPill(isSelected = false, shape = CircleShape)
                                                        .clickable { navController.navigate("history") },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        painter = painterResource(R.drawable.history),
                                                        contentDescription = stringResource(R.string.history),
                                                        tint = iconTint,
                                                        modifier = Modifier.size(17.dp)
                                                    )
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .size(34.dp)
                                                        .liquidGlassPill(isSelected = false, shape = CircleShape)
                                                        .clickable { navController.navigate("stats") },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        painter = painterResource(R.drawable.stats),
                                                        contentDescription = stringResource(R.string.stats),
                                                        tint = iconTint,
                                                        modifier = Modifier.size(17.dp)
                                                    )
                                                }
                                            }
                                            // Quick Monochrome Hitam/Putih & Theme Settings Button
                                            Box(
                                                modifier = Modifier
                                                    .size(34.dp)
                                                    .liquidGlassPill(isSelected = false, shape = CircleShape)
                                                    .clickable {
                                                        navController.navigate("settings/appearance/theme") {
                                                            launchSingleTop = true
                                                        }
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    painter = painterResource(R.drawable.contrast),
                                                    contentDescription = "Tema Monochrome Hitam/Putih",
                                                    tint = iconTint,
                                                    modifier = Modifier.size(17.dp)
                                                )
                                            }
                                            val isIslandActive = (dynamicIslandAutoMode || dynamicIslandEnabled) && !dynamicIslandDismissed
                                            Box(
                                                modifier = Modifier
                                                    .size(34.dp)
                                                    .liquidGlassPill(
                                                        isSelected = isIslandActive,
                                                        shape = CircleShape,
                                                        accentColor = Color(0xFF1E90FF)
                                                    )
                                                    .clickable {
                                                        if ((dynamicIslandAutoMode || dynamicIslandEnabled) && dynamicIslandDismissed) {
                                                            onDynamicIslandDismissedChange(false)
                                                        } else {
                                                            showDynamicIslandDialog = true
                                                        }
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    painter = painterResource(R.drawable.equalizer),
                                                    contentDescription = "Dynamic Island",
                                                    tint = if (isIslandActive) {
                                                        if (isEditorialTopBar) {
                                                            if (useDarkTheme) Color.Black else Color.White
                                                        } else {
                                                            if (useDarkTheme) Color(0xFF63B3FF) else Color(0xFF0B65C6)
                                                        }
                                                    } else {
                                                        iconTint
                                                    },
                                                    modifier = Modifier.size(17.dp)
                                                )
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .size(34.dp)
                                                    .liquidGlassPill(isSelected = false, shape = CircleShape)
                                                    .clickable {
                                                        val startDestId = navController.graph.startDestinationId
                                                        navController.navigate(Screens.Profile.route) {
                                                            popUpTo(startDestId) {
                                                                saveState = true
                                                            }
                                                            launchSingleTop = true
                                                            restoreState = true
                                                        }
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                BadgedBox(badge = {
                                                    if (latestVersionName != BuildConfig.VERSION_NAME || Updater.hasNewerCachedUpdate(this@MainActivity)) {
                                                        Badge()
                                                    }
                                                }) {
                                                    val avatarModel = localProfileAvatarUri.ifBlank { accountImageUrl.orEmpty() }
                                                    if (avatarModel.isNotBlank()) {
                                                        AsyncImage(
                                                            model = avatarModel,
                                                            contentDescription = stringResource(R.string.account),
                                                            modifier = Modifier
                                                                .size(22.dp)
                                                                .clip(CircleShape)
                                                        )
                                                    } else {
                                                        Icon(
                                                            painter = painterResource(R.drawable.account),
                                                            contentDescription = stringResource(R.string.account),
                                                            tint = iconTint,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        },
                        bottomBar = {
                            val onNavItemClick: (Screens, Boolean) -> Unit = remember(navController, coroutineScope, topAppBarScrollBehavior, playerBottomSheetState) {
                                { screen: Screens, _: Boolean ->
                                    if (playerBottomSheetState.isExpanded) {
                                        playerBottomSheetState.collapseSoft()
                                    }

                                    val actualRoute = navController.currentBackStackEntry?.destination?.route
                                    if (actualRoute == screen.route) {
                                        navController.currentBackStackEntry?.savedStateHandle?.set("scrollToTop", true)
                                        coroutineScope.launch {
                                            topAppBarScrollBehavior.state.resetHeightOffset()
                                        }
                                    } else {
                                        val startDestId = navController.graph.startDestinationId
                                        navController.navigate(screen.route) {
                                            popUpTo(startDestId) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                }
                            }

                            // Pre-calculate values for graphicsLayer to avoid reading state during composition
                            val navBarTotalHeight = bottomInset + NavigationBarHeight

                            if (!showRail && currentRoute != "wrapped") {
                                Box(modifier = Modifier.graphicsLayer { clip = false }) {
                                    BottomSheetPlayer(
                                        state = playerBottomSheetState,
                                        navController = navController,
                                        pureBlack = pureBlack
                                    )

                                    AppNavigationBar(
                                        navigationItems = navigationItems,
                                        currentRoute = currentRoute,
                                        onItemClick = onNavItemClick,
                                        pureBlack = pureBlack,
                                        slimNav = slimNav,
                                        dragTransitionState = navDragTransitionState,
                                        modifier = Modifier
                                            .align(Alignment.BottomCenter)
                                            .height(bottomInset + navPadding)
                                            .graphicsLayer {
                                                clip = false
                                                val navBarHeightPx = navigationBarHeight.toPx()
                                                val totalHeightPx = navBarTotalHeight.toPx()

                                                translationY = if (navBarHeightPx == 0f) {
                                                    totalHeightPx
                                                } else {
                                                    val progress = playerBottomSheetState.progress.coerceIn(0f, 1f)
                                                    val slideOffset = totalHeightPx * progress
                                                    val hideOffset = totalHeightPx * (1 - navBarHeightPx / NavigationBarHeight.toPx())
                                                    slideOffset + hideOffset
                                                }
                                            }
                                    )
                                }
                            } else {
                                if (currentRoute != "wrapped") {
                                    BottomSheetPlayer(
                                        state = playerBottomSheetState,
                                        navController = navController,
                                        pureBlack = pureBlack
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .align(Alignment.BottomCenter)
                                        .height(bottomInsetDp)
                                        // Use graphicsLayer for background color changes
                                        .graphicsLayer {
                                            val progress = playerBottomSheetState.progress
                                            alpha = if (progress > 0f || (useNewMiniPlayerDesign && !shouldShowNavigationBar)) 0f else 1f
                                        }
                                        .background(baseBg)
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .nestedScroll(topAppBarScrollBehavior.nestedScrollConnection)
                    ) {
                        Row(Modifier.fillMaxSize()) {
                            val onRailItemClick: (Screens, Boolean) -> Unit = remember(navController, coroutineScope, topAppBarScrollBehavior, playerBottomSheetState) {
                                { screen: Screens, _: Boolean ->
                                    if (playerBottomSheetState.isExpanded) {
                                        playerBottomSheetState.collapseSoft()
                                    }

                                    val actualRoute = navController.currentBackStackEntry?.destination?.route
                                    if (actualRoute == screen.route) {
                                        navController.currentBackStackEntry?.savedStateHandle?.set("scrollToTop", true)
                                        coroutineScope.launch {
                                            topAppBarScrollBehavior.state.resetHeightOffset()
                                        }
                                    } else {
                                        val startDestId = navController.graph.startDestinationId
                                        navController.navigate(screen.route) {
                                            popUpTo(startDestId) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                }
                            }

                            if (showRail && currentRoute != "wrapped") {
                                AppNavigationRail(
                                    navigationItems = navigationItems,
                                    currentRoute = currentRoute,
                                    onItemClick = onRailItemClick,
                                    pureBlack = pureBlack,
                                )
                            }

                            // Smoothly animate the sub-slot finger offset so the screen viewport physically
                            // glides with the user's finger inside the 3D Liquid Glass Navbar and settles with a spring
                            val rawFingerSubSlotOffset = if (navDragTransitionState.isDragging && shouldShowNavigationBar) {
                                (navDragTransitionState.activeSlotIndex.toFloat() - navDragTransitionState.fractionalIndex)
                                    .coerceIn(-1f, 1f)
                            } else {
                                0f
                            }
                            val animatedFingerSubSlotOffset by animateFloatAsState(
                                targetValue = rawFingerSubSlotOffset,
                                animationSpec = if (navDragTransitionState.isDragging) {
                                    spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessHigh
                                    )
                                } else {
                                    spring(
                                        dampingRatio = 0.78f,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                },
                                label = "navFingerViewportOffset"
                            )

                            val resolveTabIndex: (String?) -> Int = remember(navigationItems) {
                                { route ->
                                    if (route == null) {
                                        -1
                                    } else {
                                        navigationItems.indexOfFirst { item ->
                                            item.route == route ||
                                                (item.route == Screens.Search.route && (route.startsWith("search/") || route == "search_input")) ||
                                                route.startsWith("${item.route}/")
                                        }
                                    }
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .graphicsLayer {
                                        val offsetFraction = animatedFingerSubSlotOffset
                                        if (kotlin.math.abs(offsetFraction) > 0.001f) {
                                            // Screen follows finger direction smoothly before and after crossing slot boundaries
                                            translationX = offsetFraction * size.width * 0.14f
                                            val depthScale = 1f - kotlin.math.abs(offsetFraction) * 0.022f
                                            scaleX = depthScale
                                            scaleY = depthScale
                                        }
                                    }
                            ) {
                                // NavHost with directional spring transitions synchronized with the 3D Liquid Glass Navbar
                                NavHost(
                                    navController = navController,
                                    startDestination = when (tabOpenedFromShortcut ?: defaultOpenTab) {
                                        NavigationTab.HOME -> Screens.Home
                                        NavigationTab.LIBRARY -> Screens.Library
                                        NavigationTab.PROFILE -> Screens.Profile
                                        else -> Screens.Home
                                    }.route,
                                    enterTransition = {
                                        val targetIdx = resolveTabIndex(targetState.destination.route)
                                        val initialIdx = resolveTabIndex(initialState.destination.route)

                                        if (targetIdx != -1 && initialIdx != -1 && targetIdx != initialIdx) {
                                            val direction = if (targetIdx > initialIdx) 1 else -1
                                            slideInHorizontally(
                                                animationSpec = spring(
                                                    dampingRatio = 0.82f,
                                                    stiffness = 430f
                                                ),
                                                initialOffsetX = { fullWidth -> (fullWidth * 0.28f * direction).toInt() }
                                            ) + fadeIn(
                                                animationSpec = tween(durationMillis = 210, easing = FastOutSlowInEasing)
                                            ) + scaleIn(
                                                initialScale = 0.965f,
                                                animationSpec = spring(
                                                    dampingRatio = 0.82f,
                                                    stiffness = 430f
                                                )
                                            )
                                        } else {
                                            slideInHorizontally(
                                                animationSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing),
                                                initialOffsetX = { it / 7 }
                                            ) + fadeIn(tween(200))
                                        }
                                    },
                                    exitTransition = {
                                        val initialIdx = resolveTabIndex(initialState.destination.route)
                                        val targetIdx = resolveTabIndex(targetState.destination.route)

                                        if (targetIdx != -1 && initialIdx != -1 && targetIdx != initialIdx) {
                                            val direction = if (targetIdx > initialIdx) -1 else 1
                                            slideOutHorizontally(
                                                animationSpec = spring(
                                                    dampingRatio = 0.84f,
                                                    stiffness = 430f
                                                ),
                                                targetOffsetX = { fullWidth -> (fullWidth * 0.24f * direction).toInt() }
                                            ) + fadeOut(
                                                animationSpec = tween(durationMillis = 175, easing = FastOutSlowInEasing)
                                            ) + scaleOut(
                                                targetScale = 0.965f,
                                                animationSpec = spring(
                                                    dampingRatio = 0.84f,
                                                    stiffness = 430f
                                                )
                                            )
                                        } else {
                                            slideOutHorizontally(
                                                animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
                                                targetOffsetX = { -it / 8 }
                                            ) + fadeOut(tween(180))
                                        }
                                    },
                                    popEnterTransition = {
                                        val targetIdx = resolveTabIndex(targetState.destination.route)
                                        val initialIdx = resolveTabIndex(initialState.destination.route)

                                        if (targetIdx != -1 && initialIdx != -1 && targetIdx != initialIdx) {
                                            val direction = if (targetIdx > initialIdx) 1 else -1
                                            slideInHorizontally(
                                                animationSpec = spring(
                                                    dampingRatio = 0.82f,
                                                    stiffness = 430f
                                                ),
                                                initialOffsetX = { fullWidth -> (fullWidth * 0.28f * direction).toInt() }
                                            ) + fadeIn(
                                                animationSpec = tween(durationMillis = 210, easing = FastOutSlowInEasing)
                                            ) + scaleIn(
                                                initialScale = 0.965f,
                                                animationSpec = spring(
                                                    dampingRatio = 0.82f,
                                                    stiffness = 430f
                                                )
                                            )
                                        } else {
                                            slideInHorizontally(
                                                animationSpec = tween(durationMillis = 240, easing = FastOutSlowInEasing),
                                                initialOffsetX = { -it / 7 }
                                            ) + fadeIn(tween(200))
                                        }
                                    },
                                    popExitTransition = {
                                        val initialIdx = resolveTabIndex(initialState.destination.route)
                                        val targetIdx = resolveTabIndex(targetState.destination.route)

                                        if (targetIdx != -1 && initialIdx != -1 && targetIdx != initialIdx) {
                                            val direction = if (targetIdx > initialIdx) -1 else 1
                                            slideOutHorizontally(
                                                animationSpec = spring(
                                                    dampingRatio = 0.84f,
                                                    stiffness = 430f
                                                ),
                                                targetOffsetX = { fullWidth -> (fullWidth * 0.24f * direction).toInt() }
                                            ) + fadeOut(
                                                animationSpec = tween(durationMillis = 175, easing = FastOutSlowInEasing)
                                            ) + scaleOut(
                                                targetScale = 0.965f,
                                                animationSpec = spring(
                                                    dampingRatio = 0.84f,
                                                    stiffness = 430f
                                                )
                                            )
                                        } else {
                                            slideOutHorizontally(
                                                animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
                                                targetOffsetX = { it / 8 }
                                            ) + fadeOut(tween(180))
                                        }
                                    },
                                    modifier = Modifier.nestedScroll(topAppBarScrollBehavior.nestedScrollConnection)
                                ) {
                                    navigationBuilder(
                                        navController = navController,
                                        scrollBehavior = topAppBarScrollBehavior,
                                        latestVersionName = latestVersionName,
                                        activity = this@MainActivity,
                                        snackbarHostState = snackbarHostState
                                    )
                                }
                            }
                        }
                    }

                    BottomSheetMenu(
                        state = LocalMenuState.current,
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )

                    BottomSheetPage(
                        state = LocalBottomSheetPageState.current,
                        modifier = Modifier.align(Alignment.BottomCenter)
                    )

                    if (showAccountDialog) {
                        AccountSettingsDialog(
                            navController = navController,
                            onDismiss = {
                                showAccountDialog = false
                                homeViewModel.refresh()
                            },
                            latestVersionName = latestVersionName
                        )
                    }

                    sharedSong?.let { song ->
                        playerConnection?.let {
                            Dialog(
                                onDismissRequest = { sharedSong = null },
                                properties = DialogProperties(usePlatformDefaultWidth = false),
                            ) {
                                Surface(
                                    modifier = Modifier.padding(24.dp),
                                    shape = RoundedCornerShape(16.dp),
                                    color = AlertDialogDefaults.containerColor,
                                    tonalElevation = AlertDialogDefaults.TonalElevation,
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                    ) {
                                        YouTubeSongMenu(
                                            song = song,
                                            navController = navController,
                                            onDismiss = { sharedSong = null },
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Global voice command overlay (Siri/Gemini-like)
                    VoiceCommandOverlay(
                        state = voiceUiState,
                        onDismiss = { voiceCommandViewModel.dismissOverlay() },
                    )

                    if (showDynamicIslandDialog) {
                        com.sanmusic.app.ui.component.DynamicIslandSettingsDialog(
                            onDismiss = { showDynamicIslandDialog = false }
                        )
                    }

                    sharedImportUrl?.let { importUrl ->
                        com.sanmusic.app.ui.component.SpotifyImportDialog(
                            initialUrl = importUrl,
                            onDismiss = { sharedImportUrl = null },
                            onPlaylistImported = { newPlaylistId ->
                                sharedImportUrl = null
                                navController.navigate("local_playlist/$newPlaylistId")
                            },
                            onPlaySong = { matchedSong ->
                                sharedImportUrl = null
                                playerConnection?.playQueue(
                                    YouTubeQueue(
                                        WatchEndpoint(videoId = matchedSong.id),
                                        matchedSong.toMediaMetadata()
                                    )
                                )
                            },
                            onOpenArtist = { artistBrowseId ->
                                sharedImportUrl = null
                                navController.navigate("artist/$artistBrowseId")
                            }
                        )
                    }

                    pendingUpdateInfo?.let { updateInfo ->
                        if (!isFinishing && !isDestroyed) {
                            UpdateAvailableDialog(
                                updateInfo = updateInfo,
                                onUpdate = {
                                    pendingUpdateInfo = null
                                    Updater.openUpdateUrl(this@MainActivity, updateInfo.url)
                                },
                                onLater = {
                                    pendingUpdateInfo = null
                                    lifecycleScope.launch {
                                        Updater.dismissUpdateVersion(this@MainActivity, updateInfo.versionCode)
                                    }
                                },
                                onDismiss = {
                                    pendingUpdateInfo = null
                                },
                            )
                        }
                    }

                    // Global Spotify Dynamic Island overlay (opt-in, disabled by default)
                    com.sanmusic.app.ui.component.DynamicIslandOverlay(
                        isPlayerExpanded = playerBottomSheetState.isExpanded,
                        onExpandPlayer = { playerBottomSheetState.expandSoft() },
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .zIndex(100f)
                    )
                }
            }
        }
    }

    private fun handleDeepLinkIntent(intent: Intent?, navController: NavHostController) {
        if (intent == null) return

        // Music alarm: fire playback of the user-selected songs.
        if (intent.action == com.sanmusic.app.alarm.AlarmReceiver.ACTION_OPEN_ALARM) {
            intent.action = null
            handleAlarmFire()
            return
        }

        val isSendAction = intent.action == Intent.ACTION_SEND
        val rawSharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            ?: intent.clipData?.getItemAt(0)?.text?.toString()
        val rawTarget = intent.dataString ?: rawSharedText ?: return

        intent.data = null
        intent.removeExtra(Intent.EXTRA_TEXT)
        if (isSendAction) {
            intent.action = null
        }

        // Extract clean URL if user shared descriptive text containing a link (e.g. from Spotify or YT Music share sheet)
        val extractedSupportedUrl = com.sanmusic.app.utils.SpotifyPlaylistImporter.extractSupportedUrl(rawTarget)
        val effectiveUrlString = extractedSupportedUrl ?: rawTarget.trim()

        // 1. If it's a Spotify link (playlist, album, track, or artist), open the Import / Action Dialog directly
        if (com.sanmusic.app.utils.SpotifyPlaylistImporter.isSpotifyUrl(effectiveUrlString)) {
            sharedImportUrl = effectiveUrlString
            return
        }

        val uri = effectiveUrlString.toUri()
        val coroutineScope = lifecycle.coroutineScope

        val listenCode = uri.getQueryParameter("code")
            ?: uri.getQueryParameter("room")
            ?: uri.pathSegments.getOrNull(1)
        val isListenLink = uri.pathSegments.firstOrNull() == "listen" || uri.host?.equals("listen", ignoreCase = true) == true
        if (!listenCode.isNullOrBlank() && isListenLink) {
            val username = dataStore.get(ListenTogetherUsernameKey, "").ifBlank { "Guest" }
            listenTogetherManager.joinRoom(listenCode, username)
            return
        }

        // 2. If user explicitly shared a YouTube Music / YouTube Playlist or Album via Share Sheet (ACTION_SEND),
        // open the Import Playlist Dialog so they can import it directly into their local library.
        val firstSegment = uri.pathSegments.firstOrNull()
        val listQueryParam = uri.getQueryParameter("list")
        val videoQueryParam = uri.getQueryParameter("v")
        val isSharedYtPlaylistOrAlbum = isSendAction && (
            firstSegment == "playlist" ||
                (firstSegment == "browse" && (uri.lastPathSegment?.startsWith("VL") == true || uri.lastPathSegment?.startsWith("MPREb_") == true)) ||
                (!listQueryParam.isNullOrBlank() && videoQueryParam.isNullOrBlank())
            )
        if (isSharedYtPlaylistOrAlbum && com.sanmusic.app.utils.SpotifyPlaylistImporter.isSupportedImportUrl(effectiveUrlString)) {
            sharedImportUrl = effectiveUrlString
            return
        }

        when (val path = firstSegment) {
            "playlist" -> uri.getQueryParameter("list")?.let { playlistId ->
                if (playlistId.startsWith("OLAK5uy_")) {
                    coroutineScope.launch(Dispatchers.IO) {
                        YouTube.albumSongs(playlistId).onSuccess { songs ->
                            songs.firstOrNull()?.album?.id?.let { browseId ->
                                withContext(Dispatchers.Main) {
                                    navController.navigate("album/$browseId")
                                }
                            }
                        }.onFailure { reportException(it) }
                    }
                } else {
                    navController.navigate("online_playlist/$playlistId")
                }
            }

            "browse" -> uri.lastPathSegment?.let { browseId ->
                when {
                    browseId.startsWith("VL") -> {
                        navController.navigate("online_playlist/${browseId.removePrefix("VL")}")
                    }
                    browseId.startsWith("UC") -> {
                        navController.navigate("artist/$browseId")
                    }
                    else -> {
                        navController.navigate("album/$browseId")
                    }
                }
            }

            "channel", "c", "user" -> uri.lastPathSegment?.let { artistId ->
                navController.navigate("artist/$artistId")
            }

            "search" -> {
                uri.getQueryParameter("q")?.let {
                    navController.navigate("search/${URLEncoder.encode(it, "UTF-8")}")
                }
            }

            else -> {
                val videoId = when {
                    path == "watch" -> uri.getQueryParameter("v")
                    uri.host == "youtu.be" -> uri.pathSegments.firstOrNull()
                    path == "play" && uri.host == "www.auramusic.site" -> uri.pathSegments.getOrNull(1)
                    (uri.scheme == "auramusic" || uri.scheme == "sanmusic") && uri.host == "play" -> uri.pathSegments.firstOrNull()
                    else -> null
                }

                val playlistId = uri.getQueryParameter("list")

                if (videoId != null) {
                    coroutineScope.launch(Dispatchers.IO) {
                        YouTube.queue(listOf(videoId), playlistId).onSuccess { queue ->
                            withContext(Dispatchers.Main) {
                                playerConnection?.playQueue(
                                    YouTubeQueue(
                                        WatchEndpoint(videoId = queue.firstOrNull()?.id, playlistId = playlistId),
                                        queue.firstOrNull()?.toMediaMetadata()
                                    )
                                )
                            }
                        }.onFailure {
                            reportException(it)
                        }
                    }
                } else if (playlistId != null) {
                    coroutineScope.launch(Dispatchers.IO) {
                        YouTube.queue(null, playlistId).onSuccess { queue ->
                            val firstItem = queue.firstOrNull()
                            withContext(Dispatchers.Main) {
                                playerConnection?.playQueue(
                                    YouTubeQueue(
                                        WatchEndpoint(videoId = firstItem?.id, playlistId = playlistId),
                                        firstItem?.toMediaMetadata()
                                    )
                                )
                            }
                        }.onFailure {
                            reportException(it)
                        }
                    }
                }
            }
        }
    }

    private fun handleAlarmFire() {
        val ds = dataStore
        val csv = ds.get(com.sanmusic.app.constants.AlarmSongIdsKey, "")
        val songIds = csv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (songIds.isEmpty()) return
        val shuffle = ds.get(com.sanmusic.app.constants.AlarmShuffleKey, false)

        lifecycle.coroutineScope.launch(Dispatchers.IO) {
            val songs = database.getSongsByIds(songIds)
            val ordered = if (shuffle) songs.shuffled() else songs
            val mediaItems = ordered.map { it.toMediaItem() }
            if (mediaItems.isEmpty()) return@launch
            withContext(Dispatchers.Main) {
                // Wait briefly for the service binding to complete.
                var attempts = 0
                while (playerConnection == null && attempts < 30) {
                    delay(100)
                    attempts++
                }
                playerConnection?.playQueue(
                    com.sanmusic.app.playback.queues.ListQueue(
                        title = getString(R.string.alarm_title),
                        items = mediaItems,
                        startIndex = 0,
                        position = 0L,
                    )
                )
            }
        }
    }

    @SuppressLint("ObsoleteSdkInt")
    private fun setSystemBarAppearance(isDark: Boolean) {
        WindowCompat.getInsetsController(window, window.decorView.rootView).apply {
            isAppearanceLightStatusBars = !isDark
            isAppearanceLightNavigationBars = !isDark
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            window.statusBarColor = (if (isDark) Color.Transparent else Color.Black.copy(alpha = 0.2f)).toArgb()
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            window.navigationBarColor = (if (isDark) Color.Transparent else Color.Black.copy(alpha = 0.2f)).toArgb()
        }
    }
}

val LocalDatabase = staticCompositionLocalOf<MusicDatabase> { error("No database provided") }
val LocalPlayerConnection = staticCompositionLocalOf<PlayerConnection?> { error("No PlayerConnection provided") }
val LocalPlayerAwareWindowInsets = compositionLocalOf<WindowInsets> { error("No WindowInsets provided") }
val LocalDownloadUtil = staticCompositionLocalOf<DownloadUtil> { error("No DownloadUtil provided") }
val LocalSyncUtils = staticCompositionLocalOf<SyncUtils> { error("No SyncUtils provided") }
val LocalListenTogetherManager = staticCompositionLocalOf<com.sanmusic.app.listentogether.ListenTogetherManager?> { null }
val LocalHardwareIntegrationManager = staticCompositionLocalOf<com.sanmusic.app.hardware.HardwareIntegrationManager?> { null }
val LocalIsPlayerExpanded = compositionLocalOf { false }
