/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.datastore.preferences.core.edit
import coil3.ImageLoader
import coil3.PlatformContext
import coil3.SingletonImageLoader
import coil3.disk.DiskCache
import coil3.disk.directory
import coil3.memory.MemoryCache
import com.sanmusic.music.betterlyrics.BetterLyrics
import coil3.request.CachePolicy
import coil3.request.ErrorResult
import coil3.request.ImageResult
import coil3.request.allowHardware
import coil3.request.crossfade
import coil3.intercept.Interceptor
import com.sanmusic.innertube.YouTube
import com.sanmusic.innertube.models.YouTubeLocale
import com.sanmusic.kugou.KuGou
import com.sanmusic.lastfm.LastFM
import com.sanmusic.app.BuildConfig
import com.sanmusic.app.constants.*
import com.sanmusic.app.db.MusicDatabase
import com.sanmusic.app.di.ApplicationScope
import com.sanmusic.app.extensions.toEnum
import com.sanmusic.app.extensions.toInetSocketAddress
import com.sanmusic.app.notifications.NewReleaseNotificationChecker
import com.sanmusic.app.notifications.NewReleaseNotificationScheduler
import com.sanmusic.app.utils.CrashHandler
 import com.sanmusic.app.utils.dataStore
 import com.sanmusic.app.utils.reportException
 import com.sanmusic.app.voice.VoiceFeedbackManager
 import dagger.hilt.android.HiltAndroidApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.Credentials
import timber.log.Timber
import java.net.Authenticator
import java.net.PasswordAuthentication
import java.net.Proxy
import java.util.Locale
import javax.inject.Inject

@HiltAndroidApp
class App : Application(), SingletonImageLoader.Factory {

    @Inject
    @ApplicationScope
    lateinit var applicationScope: CoroutineScope

    @Inject
    lateinit var voiceFeedbackManager: VoiceFeedbackManager

    @Inject
    lateinit var database: MusicDatabase

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Verify release integrity (blocks active debugger/tracer/repack tampering)
        com.sanmusic.app.utils.SecurityGuard.verifyRuntimeIntegrity(this)
        
        // Install crash handler first
        CrashHandler.install(this)
        
        // Enforce 100% Bahasa Indonesia
        val indonesianLocale = Locale("id", "ID")
        Locale.setDefault(indonesianLocale)
        val config = resources.configuration
        config.setLocale(indonesianLocale)
        @Suppress("DEPRECATION")
        resources.updateConfiguration(config, resources.displayMetrics)
        androidx.appcompat.app.AppCompatDelegate.setApplicationLocales(
            androidx.core.os.LocaleListCompat.forLanguageTags("id-ID")
        )

        if (BuildConfig.DEBUG) {
            Timber.plant(Timber.DebugTree())
        }

        // Initialize Paxsenix synchronously so lyrics can be fetched immediately
        com.sanmusic.paxsenix.Paxsenix.init(this)

        // Initialize settings
        applicationScope.launch {
            initializeSettings()
            observeSettingsChanges()
        }
        
        // Initialize voice feedback manager (TTS)
        voiceFeedbackManager.initialize()
    }

    private suspend fun initializeSettings() {
        val settings = dataStore.data.first()
        val indonesianLocale = Locale("id", "ID")
        Locale.setDefault(indonesianLocale)

        YouTube.locale = YouTubeLocale(
            gl = settings[ContentCountryKey]?.takeIf { it != SYSTEM_DEFAULT } ?: "ID",
            hl = "id"
        )


        // Initialize LastFM with API keys from BuildConfig (GitHub Secrets)
        LastFM.initialize(
            apiKey = BuildConfig.LASTFM_API_KEY.takeIf { it.isNotEmpty() } ?: "",
            secret = BuildConfig.LASTFM_SECRET.takeIf { it.isNotEmpty() } ?: ""
        )

        // Initialize BetterLyrics with API key from BuildConfig (GitHub Secrets)
        BetterLyrics.apiKey = BuildConfig.BETTERLYRICS_API_KEY.takeIf { it.isNotEmpty() } ?: ""

        if (settings[ProxyEnabledKey] == true) {
            val username = settings[ProxyUsernameKey].orEmpty()
            val password = settings[ProxyPasswordKey].orEmpty()
            val type = settings[ProxyTypeKey].toEnum(defaultValue = Proxy.Type.HTTP)

            if (username.isNotEmpty() || password.isNotEmpty()) {
                if (type == Proxy.Type.HTTP) {
                    YouTube.proxyAuth = Credentials.basic(username, password)
                } else {
                    Authenticator.setDefault(object : Authenticator() {
                        override fun getPasswordAuthentication(): PasswordAuthentication =
                            PasswordAuthentication(username, password.toCharArray())
                    })
                }
            }
            try {
                settings[ProxyUrlKey]?.let {
                    YouTube.proxy = Proxy(type, it.toInetSocketAddress())
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@App, getString(R.string.failed_to_parse_proxy), Toast.LENGTH_SHORT).show()
                }
                reportException(e)
            }
        }

        YouTube.useLoginForBrowse = settings[UseLoginForBrowse] ?: true

        val channel = NotificationChannel(
            "updates",
            getString(R.string.update_channel_name),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = getString(R.string.update_channel_desc)
            enableVibration(true)
            enableLights(true)
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)

        nm.createNotificationChannel(
            NotificationChannel(
                NewReleaseNotificationChecker.CHANNEL_ID,
                getString(R.string.new_releases_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = getString(R.string.new_releases_channel_desc)
            }
        )

        if (settings[NewReleaseNotificationsEnabledKey] ?: true) {
            NewReleaseNotificationScheduler.schedule(this)
            NewReleaseNotificationChecker.check(this, database)
        } else {
            NewReleaseNotificationScheduler.cancel(this)
        }
    }

    private fun observeSettingsChanges() {
        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[VisitorDataKey] }
                .distinctUntilChanged()
                .collect { visitorData ->
                    YouTube.visitorData = visitorData?.takeIf { it != "null" }
                        ?: YouTube.visitorData().getOrNull()?.also { newVisitorData ->
                            dataStore.edit { settings ->
                                settings[VisitorDataKey] = newVisitorData
                            }
                        }
                }
        }

        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[DataSyncIdKey] }
                .distinctUntilChanged()
                .collect { dataSyncId ->
                    YouTube.dataSyncId = dataSyncId?.let {
                        it.takeIf { it.isNotBlank() && it != "null" && !it.contains("||") }
                            ?: it.takeIf { it.endsWith("||") }?.substringBefore("||")
                            ?: it.substringAfter("||")
                    }?.takeIf { it.isNotBlank() && it != "null" }
                }
        }

        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[InnerTubeCookieKey] }
                .distinctUntilChanged()
                .collect { cookie ->
                    try {
                        YouTube.cookie = cookie
                    } catch (e: Exception) {
                        Timber.e(e, "Could not parse cookie. Clearing existing cookie.")
                        forgetAccount(this@App)
                    }
                }
        }

        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[LastFMSessionKey] }
                .distinctUntilChanged()
                .collect { session ->
                    try {
                        LastFM.sessionKey = session
                    } catch (e: Exception) {
                        Timber.e("Error while loading last.fm session key. %s", e.message)
                    }
                }
        }

        applicationScope.launch(Dispatchers.IO) {
            dataStore.data
                .map { it[NewReleaseNotificationsEnabledKey] ?: true }
                .distinctUntilChanged()
                .collect { enabled ->
                    if (enabled) {
                        NewReleaseNotificationScheduler.schedule(this@App)
                        NewReleaseNotificationChecker.check(this@App, database)
                    } else {
                        NewReleaseNotificationScheduler.cancel(this@App)
                    }
                }
        }
    }

    override fun newImageLoader(context: PlatformContext): ImageLoader {
        val isTv = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
        val defaultCacheSize = if (isTv) 64 else 512 // Smaller default for TV to prevent storage accumulation
        val cacheSize = runBlocking {
            dataStore.data.map { it[MaxImageCacheSizeKey] ?: defaultCacheSize }.first()
        }
        return ImageLoader.Builder(this).apply {
            crossfade(true)
            allowHardware(Build.VERSION.SDK_INT >= Build.VERSION_CODES.P)
            // Memory cache for fast image loading (prevents network requests on recomposition)
            memoryCache {
                MemoryCache.Builder()
                    .maxSizePercent(context, if (isTv) 0.15 else 0.25) // Smaller memory cache for TV
                    .build()
            }
            // Retry YouTube video poster thumbnails with a lower-quality variant when the
            // requested size (e.g. maxresdefault.jpg) returns a 404. Not every YouTube video
            // has a maxresdefault image, which left video-song album art blank across the app.
            // hqdefault/sddefault exist for (essentially) every video, so they are safe fallbacks.
            components {
                if (Build.VERSION.SDK_INT >= 28) {
                    add(coil3.gif.AnimatedImageDecoder.Factory())
                } else {
                    add(coil3.gif.GifDecoder.Factory())
                }
                add(object : Interceptor {
                    override suspend fun intercept(chain: Interceptor.Chain): ImageResult {
                        val result = chain.proceed()
                        val data = chain.request.data as? String ?: return result
                        if (result is ErrorResult && data.contains("i.ytimg.com")) {
                            val fallbacks = listOf("hqdefault.jpg", "sddefault.jpg")
                                .map { fb -> data.replace("maxresdefault.jpg", fb) }
                                .filter { it != data }
                            for (fallback in fallbacks) {
                                val fbResult = chain.withRequest(
                                    chain.request.newBuilder().data(fallback).build()
                                ).proceed()
                                if (fbResult !is ErrorResult) return fbResult
                            }
                        }
                        return result
                    }
                })
            }
            if (cacheSize == 0) {
                diskCachePolicy(CachePolicy.DISABLED)
            } else {
                diskCache(
                    DiskCache.Builder()
                        .directory(cacheDir.resolve("coil"))
                        .maxSizeBytes(cacheSize * 1024 * 1024L)
                        .build()
                )
            }
        }.build()
    }

    companion object {
        lateinit var instance: App
            private set

        suspend fun forgetAccount(context: Context) {
            context.dataStore.edit { settings ->
                settings.remove(InnerTubeCookieKey)
                settings.remove(VisitorDataKey)
                settings.remove(DataSyncIdKey)
                settings.remove(AccountNameKey)
                settings.remove(AccountEmailKey)
                settings.remove(AccountChannelHandleKey)
            }
        }
    }
}
