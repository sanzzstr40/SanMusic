/**
 * San Music Project (C) 2026
 */

@file:Suppress("DEPRECATION")

package com.sanmusic.app.playback

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.app.ForegroundServiceStartNotAllowedException
import android.database.SQLException
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.audiofx.AudioEffect
import android.media.audiofx.LoudnessEnhancer
import android.net.ConnectivityManager
import android.os.Binder
import android.os.Build
import android.os.Bundle
import androidx.core.app.NotificationCompat
import androidx.core.content.getSystemService
import androidx.core.net.toUri
import androidx.datastore.preferences.core.edit
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.Player.EVENT_POSITION_DISCONTINUITY
import androidx.media3.common.Player.EVENT_TIMELINE_CHANGED
import androidx.media3.common.Player.REPEAT_MODE_ALL
import androidx.media3.common.Player.REPEAT_MODE_OFF
import androidx.media3.common.Player.REPEAT_MODE_ONE
import androidx.media3.common.Player.STATE_IDLE
import androidx.media3.common.Timeline
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.analytics.PlaybackStats
import androidx.media3.exoplayer.analytics.PlaybackStatsListener
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.AudioCapabilities
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.audio.SilenceSkippingAudioProcessor
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.source.ShuffleOrder.DefaultShuffleOrder
import androidx.media3.extractor.ExtractorsFactory
import androidx.media3.extractor.mkv.MatroskaExtractor
import androidx.media3.extractor.mp3.Mp3Extractor
import androidx.media3.extractor.mp4.FragmentedMp4Extractor
import androidx.media3.extractor.mp4.Mp4Extractor
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaController
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionToken
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.MoreExecutors
import com.sanmusic.innertube.YouTube
import com.sanmusic.innertube.models.SongItem
import com.sanmusic.innertube.models.WatchEndpoint
import com.sanmusic.lastfm.LastFM
import com.sanmusic.app.MainActivity
import com.sanmusic.app.R
import com.sanmusic.app.constants.AudioNormalizationKey
import com.sanmusic.app.constants.AudioOffload
import com.sanmusic.app.constants.AudiobookIdsKey
import com.sanmusic.app.constants.AudiobookPositionsKey
import com.sanmusic.app.constants.AudioQualityKey
import com.sanmusic.app.constants.AudioQuality
import com.sanmusic.app.constants.AudioStyleMode
import com.sanmusic.app.constants.AudioStyleModeKey
import com.sanmusic.app.utils.YTPlayerUtils
import com.sanmusic.app.sponsorblock.SponsorBlockManager
import kotlinx.coroutines.flow.firstOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import com.sanmusic.app.constants.AutoDownloadOnLikeKey
import com.sanmusic.app.constants.AutoLoadMoreKey
import com.sanmusic.app.constants.AutoSkipNextOnErrorKey
import com.sanmusic.app.constants.CrossfadeCurve
import com.sanmusic.app.constants.CrossfadeCurveKey
import com.sanmusic.app.constants.CrossfadeDurationKey
import com.sanmusic.app.constants.VideoQuality
import com.sanmusic.app.constants.VideoQualityKey
import com.sanmusic.app.constants.CrossfadeEnabledKey
import com.sanmusic.app.constants.AutomixEnabledKey
import com.sanmusic.app.constants.AutomixBlendPercentKey
import com.sanmusic.app.constants.CrossfadeGaplessKey
import com.sanmusic.app.constants.DisableLoadMoreWhenRepeatAllKey
import com.sanmusic.app.constants.DiscordUseDetailsKey
import com.sanmusic.app.constants.EnableDiscordRPCKey
import com.sanmusic.app.discord.DiscordActivity
import com.sanmusic.app.discord.DiscordActivityBuilder
import com.sanmusic.app.discord.DiscordDefaults
import com.sanmusic.app.discord.DiscordRpcManager
import com.sanmusic.app.discord.PresenceStatus
import com.sanmusic.app.constants.EnableLastFMScrobblingKey
import com.sanmusic.app.constants.HideExplicitKey
import com.sanmusic.app.constants.HideVideoSongsKey
import com.sanmusic.app.constants.HistoryDuration
import com.sanmusic.app.constants.LastFMUseNowPlaying
import com.sanmusic.app.constants.LateNightModeKey
import com.sanmusic.app.constants.MediaSessionConstants.CommandToggleLike
import com.sanmusic.app.constants.MediaSessionConstants.CommandToggleRepeatMode
import com.sanmusic.app.constants.MediaSessionConstants.CommandToggleShuffle
import com.sanmusic.app.constants.MediaSessionConstants.CommandToggleStartRadio
import com.sanmusic.app.constants.PauseListenHistoryKey
import com.sanmusic.app.constants.PauseOnMute
import com.sanmusic.app.constants.PersistentQueueKey
import com.sanmusic.app.constants.PersistentShuffleAcrossQueuesKey
import com.sanmusic.app.constants.PlayerVolumeKey
import com.sanmusic.app.constants.RememberShuffleAndRepeatKey
import com.sanmusic.app.constants.RepeatModeKey
import com.sanmusic.app.constants.ScrobbleDelayPercentKey
import com.sanmusic.app.constants.ScrobbleDelaySecondsKey
import com.sanmusic.app.constants.ScrobbleMinSongDurationKey
import com.sanmusic.app.constants.ShowLyricsKey
import com.sanmusic.app.constants.ShuffleModeKey
import com.sanmusic.app.constants.ShufflePlaylistFirstKey
import com.sanmusic.app.constants.SimilarContent
import com.sanmusic.app.constants.SponsorBlockEnabledKey
import com.sanmusic.app.constants.SponsorBlockSkipFillerKey
import com.sanmusic.app.constants.SponsorBlockSkipInteractionKey
import com.sanmusic.app.constants.SponsorBlockSkipIntroKey
import com.sanmusic.app.constants.SponsorBlockSkipMusicOffTopicKey
import com.sanmusic.app.constants.SponsorBlockSkipOutroKey
import com.sanmusic.app.constants.SponsorBlockSkipPreviewKey
import com.sanmusic.app.constants.SponsorBlockSkipSelfPromoKey
import com.sanmusic.app.constants.SponsorBlockSkipSponsorKey
import com.sanmusic.app.constants.SkipSilenceInstantKey
import com.sanmusic.app.constants.SkipSilenceKey
import com.sanmusic.app.db.MusicDatabase
import com.sanmusic.app.db.entities.ArtistEntity
import com.sanmusic.app.db.entities.Event
import com.sanmusic.app.db.entities.FormatEntity
import com.sanmusic.app.db.entities.LyricsEntity
import com.sanmusic.app.db.entities.RelatedSongMap
import com.sanmusic.app.db.entities.Song
import com.sanmusic.app.di.DownloadCache
import com.sanmusic.app.di.PlayerCache
import com.sanmusic.app.eq.EqualizerService
import com.sanmusic.app.eq.audio.VocalSuppressionAudioProcessor
import com.sanmusic.app.eq.audio.CustomEqualizerAudioProcessor
import com.sanmusic.app.eq.data.EQProfileRepository
import com.sanmusic.app.extensions.SilentHandler
import com.sanmusic.app.extensions.collect
import com.sanmusic.app.extensions.collectLatest
import com.sanmusic.app.extensions.currentMetadata
import com.sanmusic.app.extensions.findNextMediaItemById
import com.sanmusic.app.extensions.mediaItems
import com.sanmusic.app.extensions.metadata
import com.sanmusic.app.extensions.setOffloadEnabled
import com.sanmusic.app.extensions.toEnum
import com.sanmusic.app.extensions.toMediaItem
import com.sanmusic.app.extensions.toPersistQueue
import com.sanmusic.app.extensions.toQueue
import com.sanmusic.app.lyrics.LyricsHelper
import com.sanmusic.app.models.MediaMetadata
import com.sanmusic.app.models.PersistPlayerState
import com.sanmusic.app.models.PersistQueue
import com.sanmusic.app.models.toMediaMetadata
import com.sanmusic.app.playback.audio.SilenceDetectorAudioProcessor
import com.sanmusic.app.playback.audio.DualStemAudioEngine
import com.sanmusic.app.playback.audio.DynamicRangeCompressionAudioProcessor
import com.sanmusic.app.playback.audio.RemoveMusicVocalRemover
import com.sanmusic.app.playback.audio.ReverbAudioProcessor
import com.sanmusic.app.playback.audio.StudioAudioProcessorChain
import com.sanmusic.app.playback.audio.VocalSeparationStatus
import com.sanmusic.app.playback.queues.EmptyQueue
import com.sanmusic.app.playback.queues.Queue
import com.sanmusic.app.playback.queues.YouTubeQueue
import com.sanmusic.app.playback.queues.filterExplicit
import com.sanmusic.app.playback.queues.filterVideoSongs
import com.sanmusic.app.subtitles.SubtitleInfo
import com.sanmusic.app.streak.StreakManager
import com.sanmusic.app.utils.CoilBitmapLoader
import com.sanmusic.app.utils.SanMusicPlayerUtils
import com.sanmusic.app.utils.NetworkConnectivityObserver
import com.sanmusic.app.utils.AUDIOBOOK_MIN_DURATION_SECONDS
import com.sanmusic.app.utils.AUDIOBOOK_RESUME_THRESHOLD_MS
import com.sanmusic.app.utils.ScrobbleManager
import com.sanmusic.app.utils.SyncUtils
import com.sanmusic.app.utils.dataStore
import com.sanmusic.app.utils.decodeAudiobookIds
import com.sanmusic.app.utils.decodeAudiobookPositions
import com.sanmusic.app.utils.encodeAudiobookPositions
import com.sanmusic.app.utils.get
import com.sanmusic.app.utils.reportException
import com.sanmusic.app.widget.SanMusicWidgetManager
import com.sanmusic.app.widget.MusicWidgetReceiver
import com.sanmusic.app.widget.CompactSquareWidgetReceiver
import com.sanmusic.app.widget.CompactWideWidgetReceiver
import com.sanmusic.app.widget.LiquidGlassWidgetReceiver
import com.sanmusic.app.widget.LiquidGlassWideWidgetReceiver
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException
import timber.log.Timber
import java.io.File
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.time.LocalDateTime
import javax.inject.Inject
import com.sanmusic.innertube.PoTokenProvider
import kotlin.coroutines.coroutineContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.time.Duration.Companion.seconds

private const val INSTANT_SILENCE_SKIP_STEP_MS = 15_000L
private const val INSTANT_SILENCE_SKIP_SETTLE_MS = 350L

private data class SponsorBlockPreferences(
    val enabled: Boolean,
    val skipSponsor: Boolean,
    val skipSelfPromo: Boolean,
    val skipInteraction: Boolean,
    val skipIntro: Boolean,
    val skipOutro: Boolean,
    val skipPreview: Boolean,
    val skipMusicOffTopic: Boolean,
    val skipFiller: Boolean,
)

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
@androidx.annotation.OptIn(UnstableApi::class)
@AndroidEntryPoint
class MusicService :
    MediaLibraryService(),
    Player.Listener,
    PlaybackStatsListener.Callback {
    @Inject
    lateinit var database: MusicDatabase

    @Inject
    lateinit var lyricsHelper: LyricsHelper

    @Inject
    lateinit var syncUtils: SyncUtils

    @Inject
    lateinit var downloadUtil: DownloadUtil

    @Inject
    lateinit var mediaLibrarySessionCallback: MediaLibrarySessionCallback

    @Inject
    lateinit var equalizerService: EqualizerService

    @Inject
    lateinit var eqProfileRepository: EQProfileRepository

    @Inject
    lateinit var widgetManager: SanMusicWidgetManager

    @Inject
    lateinit var poTokenProvider: PoTokenProvider

    private lateinit var audioManager: AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null
    private var lastAudioFocusState = AudioManager.AUDIOFOCUS_NONE
    private var wasPlayingBeforeAudioFocusLoss = false
    private var hasAudioFocus = false
    private var reentrantFocusGain = false
    private var wasPlayingBeforeVolumeMute = false
    private var isPausedByVolumeMute = false
    private var dynamicRangeCompressionProcessor: DynamicRangeCompressionAudioProcessor? = null

    private lateinit var foregroundNotification: Notification

    @Volatile
    private var latestMediaNotification: Notification? = null

    private var crossfadeEnabled = false
    private var crossfadeDuration = 5000f
    private var crossfadeGapless = true
    private var crossfadeCurve = CrossfadeCurve.EQUAL_POWER
    private var crossfadeTriggerJob: Job? = null
    private var automixEnabled = false
    private var automixBlendPercent = 90f
    
    private val secondaryPlayerListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            Timber.tag(TAG).e(error, "Secondary player error")
            secondaryPlayer?.let { failedPlayer ->
                failedPlayer.stop()
                failedPlayer.clearMediaItems()
                playerSilenceProcessors.remove(failedPlayer)
                playerReverbProcessors.remove(failedPlayer)
                failedPlayer.release()
            }
            secondaryPlayer = null
        }
    }

    private var scope = CoroutineScope(Dispatchers.Main) + Job()
    
    private val binder = MusicBinder()

    inner class MusicBinder : Binder() {
        val service: MusicService
            get() = this@MusicService
    }

    private lateinit var connectivityManager: ConnectivityManager
    lateinit var connectivityObserver: NetworkConnectivityObserver
    val waitingForNetworkConnection = MutableStateFlow(false)
    private val isNetworkConnected = MutableStateFlow(false)

    private lateinit var audioQuality: com.sanmusic.app.constants.AudioQuality

    private var currentQueue: Queue = EmptyQueue
    private var currentQueueGeneration = 0L
    var queueTitle: String? = null

    val currentMediaMetadata = MutableStateFlow<com.sanmusic.app.models.MediaMetadata?>(null)
    val currentSong =
        currentMediaMetadata
            .flatMapLatest { mediaMetadata ->
                database.song(mediaMetadata?.id)
            }.stateIn(scope, SharingStarted.Lazily, null)
    private var dynamicIslandSystemOverlayManager: com.sanmusic.app.ui.component.DynamicIslandSystemOverlayManager? = null
    private val currentFormat =
        currentMediaMetadata.flatMapLatest { mediaMetadata ->
            database.format(mediaMetadata?.id)
        }

    private fun MediaMetadata.toDiscordSong() =
        Song(
            song = toSongEntity(),
            artists = artists.map { artist ->
                ArtistEntity(
                    id = artist.id ?: "discord:${artist.name}",
                    name = artist.name,
                )
            },
            album = null,
        )

    private fun syncDiscordState() {
        if (!discordRpcEnabled) return
        scope.launch {
            val metadata = currentMediaMetadata.value
            val song = currentSong.value
                ?.takeIf { it.song.id == metadata?.id }
                ?: metadata?.toDiscordSong()
            if (song == null) {
                if (DiscordRpcManager.isReady()) DiscordRpcManager.clear()
                return@launch
            }
            if (!DiscordRpcManager.isReady()) {
                val token = DiscordRpcManager.getAccessToken()
                if (token != null) {
                    if (!DiscordRpcManager.isInitialized()) DiscordRpcManager.init(this@MusicService)
                    DiscordRpcManager.reconnectWithToken(token)
                }
                return@launch
            }
            updateDiscordRPC(song, player.isPlaying)
        }
    }

    private fun updateDiscordRPC(song: Song, isPlaying: Boolean) {
        if (!DiscordRpcManager.isReady() || !discordRpcEnabled) return
        val useDetails = dataStore.get(DiscordUseDetailsKey, false)
        val position = player.currentPosition
        val speed = player.playbackParameters.speed.takeIf { it > 0f } ?: 1f
        val now = System.currentTimeMillis()
        val startTimestamp = now - (position / speed).toLong()
        val durationMs = song.song.duration.takeIf { it > 0 }?.times(1000L)
        val endTimestamp = durationMs?.let { d ->
            val remaining = d - position
            if (remaining > 0) now + (remaining / speed).toLong() else null
        }
        val artistName = song.artists.joinToString { it.name }.ifEmpty { DiscordDefaults.UNKNOWN_ARTIST }
        val activity = DiscordActivityBuilder.build(
            song = song,
            artistName = artistName,
            albumName = song.album?.title,
            artistThumbnail = song.artists.firstOrNull()?.thumbnailUrl,
            songTitle = song.song.title,
            startTimestamp = startTimestamp,
            endTimestamp = endTimestamp,
            advancedMode = false,
            activityType = DiscordActivity.TYPE_LISTENING,
        )
        DiscordRpcManager.setActivity(
            activity = activity,
            songId = song.song.id,
            isPlaying = isPlaying,
            status = PresenceStatus.Online,
            statusDisplayType = if (useDetails) 2 else 1,
        )
    }

    lateinit var playerVolume: MutableStateFlow<Float>
    val isMuted = MutableStateFlow(false)

    fun toggleMute() {
        isMuted.value = !isMuted.value
    }

    fun setMuted(muted: Boolean) {
        isMuted.value = muted
    }


    lateinit var sleepTimer: SleepTimer
    lateinit var sponsorBlockManager: SponsorBlockManager

    @Inject
    @PlayerCache
    lateinit var playerCache: SimpleCache

    @Inject
    @DownloadCache
    lateinit var downloadCache: SimpleCache

    lateinit var player: ExoPlayer
        private set
    private var secondaryPlayer: ExoPlayer? = null
    private var fadingPlayer: ExoPlayer? = null
    private var isCrossfading = false
    private var crossfadeJob: Job? = null

    private lateinit var mediaSession: MediaLibrarySession
    
    // Tracks if player has been properly initilized
    private val playerInitialized = MutableStateFlow(false)
    val isPlayerReady: kotlinx.coroutines.flow.StateFlow<Boolean> = playerInitialized.asStateFlow()

    // Expose active player flow for UI/Connection updates
    private val _playerFlow = MutableStateFlow<ExoPlayer?>(null)
    val playerFlow = _playerFlow.asStateFlow()

    private val playerSilenceProcessors = java.util.concurrent.ConcurrentHashMap<Player, SilenceDetectorAudioProcessor>()
    private val playerReverbProcessors = java.util.concurrent.ConcurrentHashMap<Player, ReverbAudioProcessor>()

    val audioStyleMode = MutableStateFlow(AudioStyleMode.NORMAL)
    val vocalRemoverState = RemoveMusicVocalRemover.state

    private val dualStemAudioEngine = DualStemAudioEngine()
    private var loadedStemSongId: String? = null
    private var stemSyncJob: Job? = null
    @Volatile
    private var stemRefPositionMs: Long = 0L
    @Volatile
    private var stemRefElapsedRealtimeMs: Long = 0L
    @Volatile
    private var stemMainIsPlaying: Boolean = false

    private fun refreshStemClockFromMainThread() {
        if (::player.isInitialized) {
            stemRefPositionMs = player.currentPosition.coerceAtLeast(0L)
            stemRefElapsedRealtimeMs = android.os.SystemClock.elapsedRealtime()
            stemMainIsPlaying = player.playWhenReady && player.playbackState == Player.STATE_READY
        }
    }

    fun startVocalInstrumentSeparation() {
        val meta = currentMediaMetadata.value
        val currentSongId = meta?.id
            ?: (if (::player.isInitialized) player.currentMediaItem?.mediaId else null)
        val songTitle = meta?.title
        val songArtist = meta?.artists?.joinToString(", ") { it.name }
        val songDurationSec = meta?.duration ?: 0

        // Reset speed/pitch/reverb style to NORMAL while Vocal & Instrument Remover is active
        audioStyleMode.value = AudioStyleMode.NORMAL
        playerReverbProcessors.values.forEach {
            it.setAudioStyleMode(AudioStyleMode.NORMAL)
        }
        try {
            if (::player.isInitialized) {
                player.setOffloadEnabled(false)
                player.playbackParameters = PlaybackParameters(1.0f, 1.0f)
            }
            secondaryPlayer?.let { sec ->
                sec.setOffloadEnabled(false)
                sec.playbackParameters = PlaybackParameters(1.0f, 1.0f)
            }
        } catch (e: Exception) {
            Timber.tag(TAG).w(e, "Failed to prepare player for vocal separation")
        }
        refreshStemClockFromMainThread()
        RemoveMusicVocalRemover.startOrActivate(
            context = this,
            songId = currentSongId,
            downloadUtil = downloadUtil,
            songTitle = songTitle,
            songArtist = songArtist,
            songDurationSec = songDurationSec,
        )
    }

    fun toggleVocalInstrumentSeparation() {
        if (RemoveMusicVocalRemover.state.value.active) {
            deactivateVocalInstrumentSeparation()
        } else {
            startVocalInstrumentSeparation()
        }
    }

    fun deactivateVocalInstrumentSeparation() {
        RemoveMusicVocalRemover.deactivate()
        stopExternalStemPlayers()
        equalizerService.setStemMixer(false, 1.0f, 1.0f)
    }

    fun isVocalSeparationCached(): Boolean {
        val currentSongId = currentMediaMetadata.value?.id
            ?: (if (::player.isInitialized) player.currentMediaItem?.mediaId else null)
            ?: "current_track"
        return RemoveMusicVocalRemover.isSessionCached(currentSongId)
    }

    fun setVocalStemVolume(volume: Float) {
        RemoveMusicVocalRemover.setVocalVolume(volume)
    }

    fun setInstrumentStemVolume(volume: Float) {
        RemoveMusicVocalRemover.setInstrumentVolume(volume)
    }

    fun saveVocalStemToDevice() {
        val meta = currentMediaMetadata.value
        val currentSongId = meta?.id
            ?: (if (::player.isInitialized) player.currentMediaItem?.mediaId else null)
        RemoveMusicVocalRemover.downloadAndSaveStemToDevice(
            context = this,
            songId = currentSongId,
            songTitle = meta?.title,
            songArtist = meta?.artists?.joinToString(", ") { it.name },
            songDurationSec = meta?.duration ?: 0,
            downloadUtil = downloadUtil,
            isVocal = true,
        )
    }

    fun saveInstrumentStemToDevice() {
        val meta = currentMediaMetadata.value
        val currentSongId = meta?.id
            ?: (if (::player.isInitialized) player.currentMediaItem?.mediaId else null)
        RemoveMusicVocalRemover.downloadAndSaveStemToDevice(
            context = this,
            songId = currentSongId,
            songTitle = meta?.title,
            songArtist = meta?.artists?.joinToString(", ") { it.name },
            songDurationSec = meta?.duration ?: 0,
            downloadUtil = downloadUtil,
            isVocal = false,
        )
    }

    private fun stopExternalStemPlayers() {
        stemSyncJob?.cancel()
        stemSyncJob = null
        loadedStemSongId = null
        dualStemAudioEngine.stop { mute ->
            equalizerService.setMuteMainForExternalStems(mute)
        }
        equalizerService.setMuteMainForExternalStems(false)
    }

    private fun releaseExternalStemPlayers() {
        stopExternalStemPlayers()
    }

    private fun ensureExternalStemPlayersLoaded(
        songId: String,
        vocalPcmFile: File,
        instrumentPcmFile: File,
        sampleRate: Int,
    ) {
        refreshStemClockFromMainThread()

        if (stemSyncJob?.isActive != true) {
            stemSyncJob = scope.launch {
                while (isActive) {
                    val vrState = RemoveMusicVocalRemover.state.value
                    if (!vrState.active ||
                        vrState.status != VocalSeparationStatus.READY_CACHED ||
                        !vrState.hasCloudStems
                    ) {
                        equalizerService.setMuteMainForExternalStems(false)
                        break
                    }
                    refreshStemClockFromMainThread()
                    delay(120)
                }
            }
        }

        if (!dualStemAudioEngine.isRunningFor(songId) || loadedStemSongId != songId) {
            loadedStemSongId = songId
            dualStemAudioEngine.start(
                songId = songId,
                vocalPcmFile = vocalPcmFile,
                instrumentPcmFile = instrumentPcmFile,
                sampleRate = sampleRate,
                isMainPlayingProvider = {
                    stemMainIsPlaying && !isMuted.value
                },
                mainPositionMsProvider = {
                    if (stemMainIsPlaying) {
                        val elapsed = (android.os.SystemClock.elapsedRealtime() - stemRefElapsedRealtimeMs)
                            .coerceIn(0L, 500L)
                        stemRefPositionMs + elapsed
                    } else {
                        stemRefPositionMs
                    }
                },
                vocalGainProvider = {
                    val sleepMult = sleepTimer.fadeVolumeMultiplier.coerceIn(0f, 1f)
                    if (isMuted.value) 0f else (RemoveMusicVocalRemover.state.value.vocalVolume * sleepMult).coerceIn(0f, 1.5f)
                },
                instrumentGainProvider = {
                    val sleepMult = sleepTimer.fadeVolumeMultiplier.coerceIn(0f, 1f)
                    if (isMuted.value) 0f else (RemoveMusicVocalRemover.state.value.instrumentVolume * sleepMult).coerceIn(0f, 1.5f)
                },
                onMuteMainPlayer = { mute ->
                    equalizerService.setMuteMainForExternalStems(mute)
                },
            )
        }
    }

    fun setAudioStyleMode(mode: AudioStyleMode) {
        // Switching to any Gaya Suara resets the Vocal & Instrument separation mode and clears session cache
        RemoveMusicVocalRemover.onAudioStyleChanged()
        stopExternalStemPlayers()
        equalizerService.setStemMixer(false, 1.0f, 1.0f)

        audioStyleMode.value = mode
        playerReverbProcessors.values.forEach {
            it.setAudioStyleMode(mode)
        }
        try {
            if (::player.isInitialized) {
                if (mode != AudioStyleMode.NORMAL) {
                    player.setOffloadEnabled(false)
                }
                player.playbackParameters = PlaybackParameters(mode.speed, mode.pitch)
            }
            secondaryPlayer?.let { sec ->
                if (mode != AudioStyleMode.NORMAL) {
                    sec.setOffloadEnabled(false)
                }
                sec.playbackParameters = PlaybackParameters(mode.speed, mode.pitch)
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to apply audio style mode: $mode")
        }
        scope.launch {
            dataStore.edit { settings ->
                settings[AudioStyleModeKey] = mode.name
            }
        }
    }


    private val instantSilenceSkipEnabled = MutableStateFlow(false)

    private var isAudioEffectSessionOpened = false
    private var audioEffectSessionId = C.AUDIO_SESSION_ID_UNSET
    private var loudnessEnhancer: LoudnessEnhancer? = null

    @Volatile private var discordRpcEnabled = false
    private var lastPlaybackSpeed = 1.0f
    private var discordUpdateJob: kotlinx.coroutines.Job? = null

    private var scrobbleManager: ScrobbleManager? = null

    val automixItems = MutableStateFlow<List<MediaItem>>(emptyList())

    // Tracks the original queue size to distinguish original items from auto-added ones
    private var originalQueueSize: Int = 0

    private var consecutivePlaybackErr = 0
    private var retryJob: Job? = null
    private var retryCount = 0
    private var silenceSkipJob: Job? = null
    
    // URL cache for stream URLs - class-level so it can be invalidated on errors
    /** Cached stream URL + expiry + the headers required when fetching it. */
    private data class StreamUrlEntry(
        val url: String,
        val expiresAtMs: Long,
        val headers: Map<String, String> = emptyMap(),
    )

    private val songUrlCache = HashMap<String, StreamUrlEntry>()
    
    // Enhanced error tracking for strict retry management
    private var currentMediaIdRetryCount = mutableMapOf<String, Int>()
    private val MAX_RETRY_PER_SONG = 3
    private val RETRY_DELAY_MS = 1000L
    
    // Track failed songs to prevent infinite retry loops
    private val recentlyFailedSongs = mutableSetOf<String>()
    private var failedSongsClearJob: Job? = null
    
    // Google Cast support
    var castConnectionHandler: CastConnectionHandler? = null
        private set

    private val screenStateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    if (!player.isPlaying && DiscordRpcManager.isReady()) {
                        DiscordRpcManager.disconnect()
                    }
                }
                Intent.ACTION_SCREEN_ON -> {
                    if (player.isPlaying) {
                        syncDiscordState()
                    }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true

        setListener(
            object : MediaSessionService.Listener {
                override fun onForegroundServiceStartNotAllowedException() {
                    Timber.tag(TAG).w("onForegroundServiceStartNotAllowedException: re-promoting to foreground")
                    promoteToForegroundWithLatestNotification()
                }
            },
        )

        // Player rediness reset to false
        playerInitialized.value = false
        
        // 3. Connect the processor to the service
        // handled in createExoPlayer

        val isTv = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)

        try {
            val nm = getSystemService(NotificationManager::class.java)
            // Default channel for phone (low importance, minimally intrusive)
            nm?.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    getString(R.string.music_player),
                    NotificationManager.IMPORTANCE_LOW
                )
            )
            // TV-specific channel: higher importance so the notification shows
            // prominently on the Android TV launcher as a Now Playing indicator
            if (isTv) {
                nm?.createNotificationChannel(
                    NotificationChannel(
                        TV_CHANNEL_ID,
                        "Sedang Diputar",
                        NotificationManager.IMPORTANCE_DEFAULT
                    ).apply {
                        description = "Menampilkan musik yang sedang diputar di peluncur TV"
                        setShowBadge(false)
                    }
                )
            }
            val pendingIntentClass = if (isTv) {
                try { Class.forName("com.sanmusic.app.TvMainActivity") } catch (_: Exception) { null }
            } else null
            val pending = PendingIntent.getActivity(
                this,
                0,
                Intent(this, pendingIntentClass ?: MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notificationChannelId = if (isTv) TV_CHANNEL_ID else CHANNEL_ID
            val notification: Notification = NotificationCompat.Builder(this, notificationChannelId)
                .setContentTitle(getString(R.string.music_player))
                .setContentText("")
                .setSmallIcon(R.drawable.ic_notification_icon)
                .setContentIntent(pending)
                .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .build()
            foregroundNotification = notification
            latestMediaNotification = notification
            startForegroundSafely(notification)
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to create foreground notification")
            reportException(e)
        }

        val defaultMediaNotificationProvider =
            DefaultMediaNotificationProvider(
                this,
                { NOTIFICATION_ID },
                if (isTv) TV_CHANNEL_ID else CHANNEL_ID,
                R.string.music_player
            )
                .apply {
                    setSmallIcon(R.drawable.ic_notification_icon)
                }

        setMediaNotificationProvider(
            object : MediaNotification.Provider {
                override fun createNotification(
                    mediaSession: MediaSession,
                    mediaButtonPreferences: ImmutableList<CommandButton>,
                    actionFactory: MediaNotification.ActionFactory,
                    onNotificationChangedCallback: MediaNotification.Provider.Callback,
                ): MediaNotification {
                    val trackingCallback =
                        MediaNotification.Provider.Callback { notification ->
                            latestMediaNotification = notification.notification
                            onNotificationChangedCallback.onNotificationChanged(notification)
                        }

                    return defaultMediaNotificationProvider
                        .createNotification(
                            mediaSession,
                            mediaButtonPreferences,
                            actionFactory,
                            trackingCallback,
                        ).also { mediaNotification ->
                            latestMediaNotification = mediaNotification.notification
                        }
                }

                override fun handleCustomCommand(
                    session: MediaSession,
                    action: String,
                    extras: Bundle,
                ): Boolean = defaultMediaNotificationProvider.handleCustomCommand(session, action, extras)

                override fun getNotificationChannelInfo(): MediaNotification.Provider.NotificationChannelInfo {
                    val info = defaultMediaNotificationProvider.notificationChannelInfo
                    // On TV, the media notification must surface prominently in the
                    // notification shade / home control panel. The default provider
                    // returns IMPORTANCE_LOW which can keep it hidden on Google TV,
                    // so bump it to DEFAULT for TV.
                    return if (isTv) {
                        MediaNotification.Provider.NotificationChannelInfo(
                            TV_CHANNEL_ID,
                            getString(R.string.music_player),
                        )
                    } else {
                        info
                    }
                }
            },
        )

        player = createExoPlayer()
        player.addListener(this@MusicService)

        // Add video error listener for automatic fallback
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // Don't auto-fallback - let user see error and manually toggle
                // Log all errors for debugging
                Timber.w("Video error listener: errorCode=${error.errorCode}, message=${error.message}")
                android.util.Log.w("MusicService", ">>> Video error listener: ${error.errorCode}")
            }
        })
        sleepTimer = SleepTimer(scope, player)
        player.addListener(sleepTimer)
        player.addAnalyticsListener(PlaybackStatsListener(false, this@MusicService))

        // SponsorBlock
        sponsorBlockManager = SponsorBlockManager(this@MusicService, scope)
        scope.launch { sponsorBlockManager.loadPreferences() }

        // SponsorBlock periodic skip check
        scope.launch {
            while (true) {
                // Same behaviour as always: when inside a segment, seek to its end.
                // The only difference is we don't seek while a video-mode switch or
                // an automix crossfade is mid-flight: seeking there races the media-item
                // replacement/swap and can crash or stall the next song on TV. The next
                // 250ms tick re-checks, so the segment is still skipped right after the
                // switch completes.
                if (sponsorBlockManager.enabled.value && player.isPlaying &&
                    !_isVideoSwitching.value && !isCrossfading && secondaryPlayer == null
                ) {
                    val skipTo = sponsorBlockManager.findSkipTarget(player.currentPosition)
                    if (skipTo != null && skipTo > player.currentPosition) {
                        runCatching { player.seekTo(skipTo) }
                            .onFailure { Timber.e(it, "periodic SponsorBlock skip failed") }
                    }
                }
                delay(250)
            }
        }

        // Mark player as initialized after successful creation
        playerInitialized.value = true
        Timber.tag(TAG).d("Player successfully initialized")

        // AutoMix must be consumed by the service rather than a particular UI.
        // This keeps TV and background playback queues populated as soon as
        // candidates arrive, and timeline changes then update every queue UI.
        scope.launch {
            automixItems.collect {
                enqueueNextAutomixItemIfNeeded()
            }
        }

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        setupAudioFocusRequest()

        mediaLibrarySessionCallback.apply {
            toggleLike = ::toggleLike
            toggleStartRadio = ::toggleStartRadio
            toggleLibrary = ::toggleLibrary
        }
        mediaSession =
            MediaLibrarySession
                .Builder(this, player, mediaLibrarySessionCallback)
                .setSessionActivity(
                    PendingIntent.getActivity(
                        this,
                        0,
                        Intent(
                            this,
                            if (isTv) {
                                try {
                                    Class.forName("com.sanmusic.app.TvMainActivity")
                                } catch (_: Exception) {
                                    MainActivity::class.java
                                }
                            } else {
                                MainActivity::class.java
                            },
                        ),
                        PendingIntent.FLAG_IMMUTABLE,
                    ),
                ).setBitmapLoader(CoilBitmapLoader(this, scope))
                .build()
        player.repeatMode = dataStore.get(RepeatModeKey, REPEAT_MODE_OFF)
        
        // Restore shuffle mode if remember option is enabled
        if (dataStore.get(RememberShuffleAndRepeatKey, true)) {
            player.shuffleModeEnabled = dataStore.get(ShuffleModeKey, false)
        }

        // Keep a connected controller so that notification works
        val sessionToken = SessionToken(this, ComponentName(this, MusicService::class.java))
        val controllerFuture = MediaController.Builder(this, sessionToken).buildAsync()
        controllerFuture.addListener({ controllerFuture.get() }, MoreExecutors.directExecutor())

        connectivityManager = getSystemService()!!
        connectivityObserver = NetworkConnectivityObserver(this)
        
        val screenStateFilter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
        }
        registerReceiver(screenStateReceiver, screenStateFilter)
        
        audioQuality = dataStore.get(AudioQualityKey).toEnum(com.sanmusic.app.constants.AudioQuality.AUTO)
        playerVolume = MutableStateFlow(dataStore.get(PlayerVolumeKey, 1f).coerceIn(0f, 1f))

        // Initialize video quality preference from settings
        val savedVideoQuality = dataStore.get(VideoQualityKey, "QUALITY_720P")
        val auraVideoQuality = when (savedVideoQuality) {
            "QUALITY_1080P" -> com.sanmusic.auravideo.SanMusicVideo.VideoQuality.QUALITY_1080P
            "QUALITY_720P" -> com.sanmusic.auravideo.SanMusicVideo.VideoQuality.QUALITY_720P
            "QUALITY_480P" -> com.sanmusic.auravideo.SanMusicVideo.VideoQuality.QUALITY_480P
            "QUALITY_360P" -> com.sanmusic.auravideo.SanMusicVideo.VideoQuality.QUALITY_360P
            else -> com.sanmusic.auravideo.SanMusicVideo.VideoQuality.QUALITY_720P
        }
        com.sanmusic.auravideo.SanMusicVideo.setPreferredVideoQuality(auraVideoQuality)
        Timber.d("Initialized video quality preference: $savedVideoQuality")

        // Initialize Google Cast
        initializeCast()

        // Initialize system-wide floating Dynamic Island overlay for outside-app display
        dynamicIslandSystemOverlayManager =
            com.sanmusic.app.ui.component.DynamicIslandSystemOverlayManager(this).also {
                it.start()
            }

        // 4. Watch for EQ profile changes
        scope.launch {
            eqProfileRepository.activeProfile.collect { profile ->
                if (profile != null) {
                    if (::player.isInitialized) {
                        player.setOffloadEnabled(false)
                    }
                    secondaryPlayer?.setOffloadEnabled(false)
                    equalizerService.applyProfile(profile)
                } else {
                    equalizerService.disable()
                }
            }
        }

        scope.launch {
            connectivityObserver.networkStatus.collect { isConnected ->
                isNetworkConnected.value = isConnected
                if (isConnected && waitingForNetworkConnection.value) {
                    triggerRetry()
                }
                // Update Discord RPC when network becomes available
                if (isConnected && discordRpcEnabled && player.isPlaying) {
                    syncDiscordState()
                }
            }
        }

        dataStore.data
            .map {
                (it[com.sanmusic.app.constants.SleepTimerFadeOutEnabledKey] ?: true) to
                    (it[com.sanmusic.app.constants.SleepTimerFadeOutDurationKey] ?: 30f).toInt()
            }
            .distinctUntilChanged()
            .collectLatest(scope) { (fadeEnabled, fadeDurationSec) ->
                sleepTimer.updateFadeSettings(fadeEnabled, fadeDurationSec)
            }

        combine(playerVolume, isMuted, sleepTimer.fadeVolumeMultiplierFlow) { volume, muted, fadeMultiplier ->
            if (muted) 0f else (volume * fadeMultiplier).coerceIn(0f, 1f)
        }.collectLatest(scope) {
            player.volume = it
        }

        playerVolume.debounce(1000).collect(scope) { volume ->
            dataStore.edit { settings ->
                settings[PlayerVolumeKey] = volume
            }
        }

        currentSong.debounce(1000).collect(scope) { song ->
            updateNotification()
            updateWidgetUI(player.isPlaying)
        }

        combine(
            currentMediaMetadata.distinctUntilChangedBy { it?.id },
            dataStore.data.map { it[ShowLyricsKey] ?: false }.distinctUntilChanged(),
            dataStore.data.map {
                it[com.sanmusic.app.constants.PreferredLyricsProviderKey]
                    .toEnum(com.sanmusic.app.constants.PreferredLyricsProvider.SIMPMUSIC)
            }.distinctUntilChanged(),
        ) { mediaMetadata, showLyrics, preferredProvider ->
            Triple(mediaMetadata, showLyrics, preferredProvider)
        }.collectLatest(scope) { (mediaMetadata, showLyrics, preferredProvider) ->
            val isTv = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
            if (!isTv && showLyrics && mediaMetadata != null && database.lyrics(mediaMetadata.id)
                    .first() == null
            ) {
                val lyricsWithProvider = lyricsHelper.getLyricsFromProvider(mediaMetadata, preferredProvider)
                // Only upsert if no lyrics were written while we were fetching (avoid race with Player.kt)
                val existingLyrics = database.lyrics(mediaMetadata.id).first()
                if (existingLyrics == null) {
                    database.query {
                        upsert(
                            LyricsEntity(
                                id = mediaMetadata.id,
                                lyrics = lyricsWithProvider.lyrics,
                                provider = lyricsWithProvider.provider,
                            ),
                        )
                    }
                }
            }
        }

        dataStore.data
            .map { (it[SkipSilenceKey] ?: false) to (it[SkipSilenceInstantKey] ?: false) }
            .distinctUntilChanged()
            .collectLatest(scope) { (skipSilence, instantSkip) ->
                player.skipSilenceEnabled = skipSilence
                secondaryPlayer?.skipSilenceEnabled = skipSilence

                val enableInstant = skipSilence && instantSkip
                instantSilenceSkipEnabled.value = enableInstant
                
                playerSilenceProcessors.values.forEach { processor ->
                    processor.instantModeEnabled = enableInstant
                    if (!enableInstant) {
                        processor.resetTracking()
                    }
                }

                if (!enableInstant) {
                    silenceSkipJob?.cancel()
                }
            }

        combine(
            currentFormat,
            dataStore.data
                .map { it[AudioNormalizationKey] ?: true }
                .distinctUntilChanged(),
        ) { format, normalizeAudio ->
            format to normalizeAudio
        }.collectLatest(scope) { (format, normalizeAudio) -> setupLoudnessEnhancer()}

        combine(
            dataStore.data.map { it[AudioOffload] ?: false },
            dataStore.data.map {
                (it[CrossfadeEnabledKey] ?: false) ||
                    (it[AutomixEnabledKey] ?: false) ||
                    ((it[AudioStyleModeKey] ?: AudioStyleMode.NORMAL.name) != AudioStyleMode.NORMAL.name)
            }
        ) { offloadPref, forceDisableOffload ->
             // Force disable offload if crossfade or an audio style DSP mode is enabled
             if (forceDisableOffload) false else offloadPref
        }.distinctUntilChanged()
        .collectLatest(scope) { useOffload ->
             player.setOffloadEnabled(useOffload)
             secondaryPlayer?.setOffloadEnabled(useOffload)
        }

        // Discord Rich Presence via OAuth2. The manager owns the token (persisted,
        // encrypted) and the gateway connection; here we only react to the enable
        // toggle and drive presence updates from playback state.
        if (!DiscordRpcManager.isInitialized()) {
            DiscordRpcManager.init(this@MusicService)
        }

        dataStore.data
            .map { it[EnableDiscordRPCKey] ?: true }
            .distinctUntilChanged()
            .collect(scope) { enabled ->
                discordRpcEnabled = enabled
                if (enabled) {
                    if (DiscordRpcManager.isReady()) {
                        syncDiscordState()
                    } else {
                        val token = DiscordRpcManager.getAccessToken()
                        if (token != null) {
                            if (!DiscordRpcManager.isInitialized()) DiscordRpcManager.init(this@MusicService)
                            DiscordRpcManager.reconnectWithToken(token)
                        }
                    }
                } else if (DiscordRpcManager.isReady()) {
                    DiscordRpcManager.disconnect()
                }
            }

        DiscordRpcManager.accessTokenFlow.collect(scope) { token ->
            if (token.isNullOrEmpty()) {
                if (DiscordRpcManager.isReady()) DiscordRpcManager.disconnect()
                return@collect
            }
            if (!discordRpcEnabled) return@collect
            if (!DiscordRpcManager.isInitialized()) DiscordRpcManager.init(this@MusicService)
            if (!DiscordRpcManager.isAuthorized()) {
                DiscordRpcManager.reconnectWithToken(token)
            }
        }

        DiscordRpcManager.connectionStatus.collect(scope) { status ->
            if (status == DiscordRpcManager.Status.Connected && discordRpcEnabled) {
                syncDiscordState()
            }
        }

        DiscordRpcManager.settingsChanged.collect(scope) {
            if (discordRpcEnabled && DiscordRpcManager.isReady()) {
                syncDiscordState()
            }
        }

        dataStore.data
            .map { it[LateNightModeKey] ?: false }
            .distinctUntilChanged()
            .collectLatest(scope) { enabled ->
                dynamicRangeCompressionProcessor?.enabled = enabled
            }

        dataStore.data
            .map { (it[AudioStyleModeKey] ?: AudioStyleMode.NORMAL.name).toEnum(AudioStyleMode.NORMAL) }
            .distinctUntilChanged()
            .collectLatest(scope) { mode ->
                audioStyleMode.value = mode
                if (!RemoveMusicVocalRemover.state.value.active) {
                    equalizerService.disableVocalSuppression()
                }
                playerReverbProcessors.values.forEach { processor ->
                    processor.setAudioStyleMode(mode)
                }
            }

        RemoveMusicVocalRemover.state.collect(scope) { vrState ->
            if (!vrState.active || vrState.status != VocalSeparationStatus.READY_CACHED) {
                stopExternalStemPlayers()
                equalizerService.setStemMixer(false, 1.0f, 1.0f)
            } else {
                if (::player.isInitialized) {
                    runCatching { player.setOffloadEnabled(false) }
                }
                val vPcm = vrState.vocalPcmFile
                val iPcm = vrState.instrumentPcmFile
                val sId = vrState.songId
                if (vrState.hasCloudStems && vPcm != null && iPcm != null && !sId.isNullOrBlank()) {
                    // Use sample-accurate single-AudioTrack DualStemAudioEngine (turn off mid/side DSP filter)
                    equalizerService.setStemMixer(false, 1.0f, 1.0f)
                    ensureExternalStemPlayersLoaded(sId, vPcm, iPcm, vrState.pcmSampleRate)
                } else {
                    stopExternalStemPlayers()
                    equalizerService.setStemMixer(
                        enabled = true,
                        vocalVolume = vrState.vocalVolume,
                        instrumentVolume = vrState.instrumentVolume,
                    )
                }
            }
        }

        // Re-sync presence when the "use details" preference changes.
        dataStore.data
            .map { it[DiscordUseDetailsKey] ?: false }
            .debounce(1000)
            .distinctUntilChanged()
            .collect(scope) {
                DiscordRpcManager.notifySettingsChanged()
            }

        // Periodic Discord presence refresh — keeps the progress bar accurate and
        // ensures presence stays visible even if a send fails or the connection blips.
        scope.launch {
            while (true) {
                delay(5000)
                if (discordRpcEnabled && player.isPlaying &&
                    player.playbackState == Player.STATE_READY) {
                    syncDiscordState()
                }
            }
        }

        dataStore.data
            .map { it[EnableLastFMScrobblingKey] ?: false }
            .debounce(300)
            .distinctUntilChanged()
            .collect(scope) { enabled ->
                if (enabled && scrobbleManager == null) {
                    val delayPercent = dataStore.get(ScrobbleDelayPercentKey, LastFM.DEFAULT_SCROBBLE_DELAY_PERCENT)
                    val minSongDuration = dataStore.get(ScrobbleMinSongDurationKey, LastFM.DEFAULT_SCROBBLE_MIN_SONG_DURATION)
                    val delaySeconds = dataStore.get(ScrobbleDelaySecondsKey, LastFM.DEFAULT_SCROBBLE_DELAY_SECONDS)
                    scrobbleManager = ScrobbleManager(
                        scope,
                        minSongDuration = minSongDuration,
                        scrobbleDelayPercent = delayPercent,
                        scrobbleDelaySeconds = delaySeconds
                    )
                    scrobbleManager?.useNowPlaying = dataStore.get(LastFMUseNowPlaying, false)
                } else if (!enabled && scrobbleManager != null) {
                    scrobbleManager?.destroy()
                    scrobbleManager = null
                }
            }

        dataStore.data
            .map { it[LastFMUseNowPlaying] ?: false }
            .distinctUntilChanged()
            .collectLatest(scope) {
                scrobbleManager?.useNowPlaying = it
            }

        dataStore.data
            .map { prefs ->
                Triple(
                    prefs[ScrobbleDelayPercentKey] ?: LastFM.DEFAULT_SCROBBLE_DELAY_PERCENT,
                    prefs[ScrobbleMinSongDurationKey] ?: LastFM.DEFAULT_SCROBBLE_MIN_SONG_DURATION,
                    prefs[ScrobbleDelaySecondsKey] ?: LastFM.DEFAULT_SCROBBLE_DELAY_SECONDS
                )
            }
            .distinctUntilChanged()
            .collect(scope) { (delayPercent, minSongDuration, delaySeconds) ->
                scrobbleManager?.let {
                    it.scrobbleDelayPercent = delayPercent
                    it.minSongDuration = minSongDuration
                    it.scrobbleDelaySeconds = delaySeconds
                }
            }

        // Crossfade & Automix settings observer
        dataStore.data
            .map { prefs ->
                val cfEnabled = prefs[CrossfadeEnabledKey] ?: false
                val cfDuration = prefs[CrossfadeDurationKey] ?: 5f
                val cfGapless = prefs[CrossfadeGaplessKey] ?: true
                val cfCurve = prefs[CrossfadeCurveKey]?.let {
                    runCatching { CrossfadeCurve.valueOf(it) }.getOrNull()
                } ?: CrossfadeCurve.EQUAL_POWER
                val amEnabled = prefs[AutomixEnabledKey] ?: false
                val amBlend = prefs[AutomixBlendPercentKey] ?: 90f
                listOf(cfEnabled, cfDuration, cfGapless, cfCurve, amEnabled, amBlend)
            }
            .distinctUntilChanged()
            .collect(scope) { values ->
                val cfEnabled = values[0] as Boolean
                val cfDuration = values[1] as Float
                val cfGapless = values[2] as Boolean
                val cfCurve = values[3] as CrossfadeCurve
                val amEnabled = values[4] as Boolean
                val amBlend = values[5] as Float

                automixEnabled = amEnabled
                automixBlendPercent = amBlend.coerceIn(10f, 100f)
                crossfadeCurve = cfCurve
                if (amEnabled) {
                    crossfadeEnabled = true
                    crossfadeDuration = 4000f // 4 second DJ-style crossfade
                    crossfadeGapless = false  // Always crossfade in automix mode
                    Timber.tag(TAG).i("Automix enabled: crossfade=4s, gapless=false, blend=$automixBlendPercent%")
                } else {
                    crossfadeEnabled = cfEnabled
                    crossfadeDuration = cfDuration.coerceIn(1f, 15f) * 1000f
                    crossfadeGapless = cfGapless
                }
                scheduleCrossfade()
            }

        dataStore.data
            .map { prefs ->
                SponsorBlockPreferences(
                    enabled = prefs[SponsorBlockEnabledKey] ?: false,
                    skipSponsor = prefs[SponsorBlockSkipSponsorKey] != false,
                    skipSelfPromo = prefs[SponsorBlockSkipSelfPromoKey] != false,
                    skipInteraction = prefs[SponsorBlockSkipInteractionKey] != false,
                    skipIntro = prefs[SponsorBlockSkipIntroKey] != false,
                    skipOutro = prefs[SponsorBlockSkipOutroKey] != false,
                    skipPreview = prefs[SponsorBlockSkipPreviewKey] != false,
                    skipMusicOffTopic = prefs[SponsorBlockSkipMusicOffTopicKey] != false,
                    skipFiller = prefs[SponsorBlockSkipFillerKey] != false,
                )
            }
            .distinctUntilChanged()
            .collect(scope) { sponsorBlockPrefs ->
                sponsorBlockManager.updateEnabled(sponsorBlockPrefs.enabled)
                if (sponsorBlockPrefs.enabled) {
                    currentSponsorBlockVideoId()?.let { videoId ->
                        sponsorBlockManager.forceReload(videoId, currentPlaybackDurationMs())
                    }
                }
            }

        if (dataStore.get(PersistentQueueKey, true)) {
            val queueFile = filesDir.resolve(PERSISTENT_QUEUE_FILE)
            if (queueFile.exists()) {
                runCatching {
                    queueFile.inputStream().use { fis ->
                        ObjectInputStream(fis).use { oos ->
                            oos.readObject() as PersistQueue
                        }
                    }
                }.onSuccess { queue ->
                    runCatching {
                        // Convert back to proper queue type
                        val restoredQueue = queue.toQueue()
                        // Wait for player initialization before playing
                        scope.launch {
                            playerInitialized.first { it }
                            if (isActive) {
                                playQueue(
                                    queue = restoredQueue,
                                    playWhenReady = false,
                                )
                            }
                        }
                    }.onFailure { error ->
                        Timber.tag(TAG).w(error, "Failed to restore persisted queue, clearing data")
                        clearPersistedQueueFiles()
                    }
                }.onFailure { error ->
                    Timber.tag(TAG).w(error, "Failed to read persisted queue, clearing data")
                    clearPersistedQueueFiles()
                }
            }

            val automixFile = filesDir.resolve(PERSISTENT_AUTOMIX_FILE)
            if (automixFile.exists()) {
                runCatching {
                    automixFile.inputStream().use { fis ->
                        ObjectInputStream(fis).use { oos ->
                            oos.readObject() as PersistQueue
                        }
                    }
                }.onSuccess { queue ->
                    runCatching {
                        automixItems.value = queue.items.map { it.toMediaItem() }
                    }.onFailure { error ->
                        Timber.tag(TAG).w(error, "Failed to restore automix queue, clearing data")
                        clearPersistedQueueFiles()
                    }
                }.onFailure { error ->
                    Timber.tag(TAG).w(error, "Failed to read automix queue, clearing data")
                    clearPersistedQueueFiles()
                }
            }

            // Restore player state
            val playerStateFile = filesDir.resolve(PERSISTENT_PLAYER_STATE_FILE)
            if (playerStateFile.exists()) {
                runCatching {
                    playerStateFile.inputStream().use { fis ->
                        ObjectInputStream(fis).use { oos ->
                            oos.readObject() as PersistPlayerState
                        }
                    }
                }.onSuccess { playerState ->
                    // Restore player settings after queue is loaded
                    scope.launch {
                        delay(1000) // Wait for queue to be loaded
                        player.repeatMode = playerState.repeatMode
                        player.shuffleModeEnabled = playerState.shuffleModeEnabled
                        playerVolume.value = playerState.volume

                        // Restore position if it's still valid
                        if (playerState.currentMediaItemIndex < player.mediaItemCount) {
                            player.seekTo(playerState.currentMediaItemIndex, playerState.currentPosition)
                        }
                    }
                }.onFailure { error ->
                    Timber.tag(TAG).w(error, "Failed to read player state, clearing data")
                    clearPersistedQueueFiles()
                }
            }
        }

        // Save queue periodically to prevent queue loss from crash or force kill
        scope.launch {
            while (isActive) {
                delay(30.seconds)
                if (dataStore.get(PersistentQueueKey, true)) {
                    saveQueueToDisk()
                }
            }
        }

        // Save queue more frequently when playing to ensure state is preserved
        scope.launch {
            while (isActive) {
                delay(10.seconds)
                if (dataStore.get(PersistentQueueKey, true) && player.isPlaying) {
                    saveQueueToDisk()
                }
                saveAudiobookResumePosition()
            }
        }
    }

    private suspend fun saveAudiobookResumePosition() {
        val metadata = player.currentMetadata ?: return
        val mediaId = metadata.id
        val durationMs = if (player.duration != C.TIME_UNSET) {
            player.duration
        } else {
            metadata.duration.takeIf { it > 0 }?.times(1000L) ?: 0L
        }
        if (durationMs <= 0L) return

        val preferences = dataStore.data.first()
        val audiobookIds = decodeAudiobookIds(preferences[AudiobookIdsKey])
        val isAudiobook = mediaId in audiobookIds || metadata.duration >= AUDIOBOOK_MIN_DURATION_SECONDS
        if (!isAudiobook) return

        val position = player.currentPosition.coerceIn(0L, durationMs)
        val shouldKeepPosition = position >= AUDIOBOOK_RESUME_THRESHOLD_MS && position < durationMs - AUDIOBOOK_RESUME_THRESHOLD_MS

        dataStore.edit { settings ->
            val positions = decodeAudiobookPositions(settings[AudiobookPositionsKey]).toMutableMap()
            if (shouldKeepPosition) {
                positions[mediaId] = position
            } else {
                positions -= mediaId
            }
            settings[AudiobookPositionsKey] = encodeAudiobookPositions(positions)
        }
    }

    private fun createExoPlayer(publishPlayer: Boolean = true): ExoPlayer {
        val eqProcessor = CustomEqualizerAudioProcessor()
        equalizerService.addAudioProcessor(eqProcessor)

        val vocalSuppressionProcessor = VocalSuppressionAudioProcessor()
        equalizerService.addVocalSuppressionProcessor(vocalSuppressionProcessor)

        val dynamicRangeCompressionProcessor = DynamicRangeCompressionAudioProcessor().also {
            this.dynamicRangeCompressionProcessor = it
        }

        val silenceProcessor = SilenceDetectorAudioProcessor { handleLongSilenceDetected() }
        val reverbProcessor = ReverbAudioProcessor()
        var initialAudioStyle = AudioStyleMode.NORMAL

        // Set initial state
        runBlocking {
            val skipSilence = dataStore.get(SkipSilenceKey, false)
            val instantSkip = dataStore.get(SkipSilenceInstantKey, false)
            silenceProcessor.instantModeEnabled = skipSilence && instantSkip
            dynamicRangeCompressionProcessor.enabled = dataStore.get(LateNightModeKey, false)
            initialAudioStyle = dataStore.get(AudioStyleModeKey, AudioStyleMode.NORMAL.name)
                .toEnum(AudioStyleMode.NORMAL)
            audioStyleMode.value = initialAudioStyle
            reverbProcessor.setAudioStyleMode(initialAudioStyle)

            equalizerService.disableVocalSuppression()
        }

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(createMediaSourceFactory())
            .setRenderersFactory(
                createRenderersFactory(
                    eqProcessor,
                    vocalSuppressionProcessor,
                    dynamicRangeCompressionProcessor,
                    silenceProcessor,
                    reverbProcessor,
                )
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                false,
            )
            .setSeekBackIncrementMs(5000)
            .setSeekForwardIncrementMs(5000)
            .setDeviceVolumeControlEnabled(true)
            .build()

        playerSilenceProcessors[player] = silenceProcessor
        playerReverbProcessors[player] = reverbProcessor

        // Set default track selection to enable subtitles by default like SmartTube
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setPreferredTextLanguage("en")
            .build()

        player.apply {
                runBlocking {
                    val offload = dataStore.get(AudioOffload, false)
                    val crossfade = dataStore.get(CrossfadeEnabledKey, false) ||
                        dataStore.get(AutomixEnabledKey, false)
                    val disableOffload = crossfade || initialAudioStyle != AudioStyleMode.NORMAL
                    setOffloadEnabled(if (disableOffload) false else offload)
                    skipSilenceEnabled = dataStore.get(SkipSilenceKey, false)
                    if (initialAudioStyle != AudioStyleMode.NORMAL) {
                        playbackParameters = PlaybackParameters(initialAudioStyle.speed, initialAudioStyle.pitch)
                    }
                }
                
                // Cleanup handled manually in onDestroy/release
            }
        // Secondary players must remain private until their streamed media has resolved and is
        // ready. Publishing here made controllers attach to a silent/buffering player.
        if (publishPlayer) _playerFlow.value = player
        return player
    }

    private fun setupAudioFocusRequest() {
        audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(
                android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setOnAudioFocusChangeListener { focusChange ->
                handleAudioFocusChange(focusChange)
            }
            .setAcceptsDelayedFocusGain(true)
            .build()
    }

    private fun handleAudioFocusChange(focusChange: Int) {
        when (focusChange) {

            AudioManager.AUDIOFOCUS_GAIN,
            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT -> {
                hasAudioFocus = true

                if (wasPlayingBeforeAudioFocusLoss && !player.isPlaying && !reentrantFocusGain) {
                    reentrantFocusGain = true
                    scope.launch {
                        delay(300)
                        if (hasAudioFocus && wasPlayingBeforeAudioFocusLoss && !player.isPlaying) {
                            // Don't start local playback if casting
                            if (castConnectionHandler?.isCasting?.value != true) {
                                player.play()
                            }
                            wasPlayingBeforeAudioFocusLoss = false
                        }
                        reentrantFocusGain = false
                    }
                }

                val fadeMult = sleepTimer.fadeVolumeMultiplierFlow.value
                player.volume = if (isMuted.value) 0f else (playerVolume.value * fadeMult).coerceIn(0f, 1f)
                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_LOSS -> {
                hasAudioFocus = false
                wasPlayingBeforeAudioFocusLoss = player.isPlaying
                if (player.isPlaying) {
                    player.pause()
                }
                abandonAudioFocus()
                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                hasAudioFocus = false
                wasPlayingBeforeAudioFocusLoss = player.isPlaying
                if (player.isPlaying) {
                    player.pause()
                }
                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                hasAudioFocus = false
                wasPlayingBeforeAudioFocusLoss = player.isPlaying
                if (player.isPlaying) {
                    val fadeMult = sleepTimer.fadeVolumeMultiplierFlow.value
                    player.volume = if (isMuted.value) 0f else (playerVolume.value * 0.2f * fadeMult).coerceIn(0f, 1f)
                }
                lastAudioFocusState = focusChange
            }

            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK -> {
                hasAudioFocus = true
                val fadeMult = sleepTimer.fadeVolumeMultiplierFlow.value
                player.volume = if (isMuted.value) 0f else (playerVolume.value * fadeMult).coerceIn(0f, 1f)
                lastAudioFocusState = focusChange
            }
        }
    }

    private fun requestAudioFocus(): Boolean {
        if (hasAudioFocus) return true

        audioFocusRequest?.let { request ->
            val result = audioManager.requestAudioFocus(request)
            hasAudioFocus = result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
            return hasAudioFocus
        }
        return false
    }

    private fun abandonAudioFocus() {
        if (hasAudioFocus) {
            audioFocusRequest?.let { request ->
                audioManager.abandonAudioFocusRequest(request)
                hasAudioFocus = false
            }
        }
    }

    private fun clearPersistedQueueFiles() {
        runCatching { filesDir.resolve(PERSISTENT_QUEUE_FILE).delete() }
        runCatching { filesDir.resolve(PERSISTENT_AUTOMIX_FILE).delete() }
        runCatching { filesDir.resolve(PERSISTENT_PLAYER_STATE_FILE).delete() }
    }

    fun hasAudioFocusForPlayback(): Boolean {
        return hasAudioFocus
    }

    private fun waitOnNetworkError() {
        if (waitingForNetworkConnection.value) return
        
        // Check if we've exceeded max retry attempts
        if (retryCount >= MAX_RETRY_COUNT) {
            Timber.tag(TAG).w("Max retry count ($MAX_RETRY_COUNT) reached, stopping playback")
            stopOnError()
            retryCount = 0
            return
        }
        
        waitingForNetworkConnection.value = true
        
        // Start a retry timer with exponential backoff
        retryJob?.cancel()
        retryJob = scope.launch {
            // Exponential backoff: 3s, 6s, 12s, 24s... max 30s
            val delayMs = minOf(3000L * (1 shl retryCount), 30000L)
            Timber.tag(TAG).d("Waiting ${delayMs}ms before retry attempt ${retryCount + 1}/$MAX_RETRY_COUNT")
            delay(delayMs)
            
            if (isNetworkConnected.value && waitingForNetworkConnection.value) {
                retryCount++
                triggerRetry()
            }
        }
    }

    private fun triggerRetry() {
        waitingForNetworkConnection.value = false
        retryJob?.cancel()
        
        if (player.currentMediaItem != null) {
            // After 3+ failed retries, try to refresh the stream URL by seeking to current position
            // This forces ExoPlayer to re-resolve the data source and get a fresh URL
            if (retryCount > 3) {
                Timber.tag(TAG).d("Retry count > 3, attempting to refresh stream URL")
                val currentPosition = player.currentPosition
                player.seekTo(player.currentMediaItemIndex, currentPosition)
            }
            player.prepare()
            // Don't call play() here - let the player auto-resume via playWhenReady
            // This avoids stealing audio focus during retry attempts
        }
    }

    private fun skipOnError() {
        /**
         * Auto skip to the next media item on error.
         *
         * To prevent a "runaway diesel engine" scenario, force the user to take action after
         * too many errors come up too quickly. Pause to show player "stopped" state
         */
        consecutivePlaybackErr += 2
        val nextWindowIndex = player.nextMediaItemIndex

        if (consecutivePlaybackErr <= MAX_CONSECUTIVE_ERR && nextWindowIndex != C.INDEX_UNSET) {
            try {
                // The timeline may have changed (e.g. video-mode source replacement) between
                // reading nextMediaItemIndex and seeking, which throws IllegalSeekPositionException.
                player.seekTo(nextWindowIndex, C.TIME_UNSET)
                player.prepare()
                // Don't start local playback if casting
                if (castConnectionHandler?.isCasting?.value != true) {
                    player.play()
                }
                return
            } catch (e: Exception) {
                Timber.e(e, "skipOnError: Failed to skip to next item")
            }
        }

        player.pause()
        consecutivePlaybackErr = 0
    }

    private fun stopOnError() {
        player.pause()
    }

    private fun updateNotification() {
        mediaSession.setCustomLayout(
            listOf(
                CommandButton
                    .Builder()
                    .setDisplayName(
                        getString(
                            if (currentSong.value?.song?.liked ==
                                true
                            ) {
                                R.string.action_remove_like
                            } else {
                                R.string.action_like
                            },
                        ),
                    )
                    .setIconResId(if (currentSong.value?.song?.liked == true) R.drawable.ic_heart else R.drawable.ic_heart_outline)
                    .setSessionCommand(CommandToggleLike)
                    .setEnabled(currentSong.value != null)
                    .build(),
                CommandButton
                    .Builder()
                    .setDisplayName(
                        getString(
                            when (player.repeatMode) {
                                REPEAT_MODE_OFF -> R.string.repeat_mode_off
                                REPEAT_MODE_ONE -> R.string.repeat_mode_one
                                REPEAT_MODE_ALL -> R.string.repeat_mode_all
                                else -> throw IllegalStateException()
                            },
                        ),
                    ).setIconResId(
                        when (player.repeatMode) {
                            REPEAT_MODE_OFF -> R.drawable.repeat
                            REPEAT_MODE_ONE -> R.drawable.repeat_one_on
                            REPEAT_MODE_ALL -> R.drawable.repeat_on
                            else -> throw IllegalStateException()
                        },
                    ).setSessionCommand(CommandToggleRepeatMode)
                    .build(),
                CommandButton
                    .Builder()
                    .setDisplayName(getString(if (player.shuffleModeEnabled) R.string.action_shuffle_off else R.string.action_shuffle_on))
                    .setIconResId(if (player.shuffleModeEnabled) R.drawable.shuffle_on else R.drawable.shuffle)
                    .setSessionCommand(CommandToggleShuffle)
                    .build(),
                CommandButton.Builder()
                    .setDisplayName(getString(R.string.start_radio))
                    .setIconResId(R.drawable.radio)
                    .setSessionCommand(CommandToggleStartRadio)
                    .setEnabled(currentSong.value != null)
                    .build(),
            ),
        )
    }

    private suspend fun recoverSong(
        mediaId: String,
        playbackData: YTPlayerUtils.PlaybackData? = null
    ) {
        val song = database.song(mediaId).first()
        val mediaMetadata = withContext(Dispatchers.Main) {
            player.findNextMediaItemById(mediaId)?.metadata
        } ?: return
        val duration = song?.song?.duration?.takeIf { it != -1 }
            ?: mediaMetadata.duration.takeIf { it != -1 }
            ?: (playbackData?.videoDetails ?: YTPlayerUtils.playerResponseForMetadata(mediaId)
                .getOrNull()?.videoDetails)?.lengthSeconds?.toInt()
            ?: -1
        database.query {
            if (song == null) insert(mediaMetadata.copy(duration = duration))
            else {
                var updatedSong = song.song
                if (song.song.duration == -1) {
                    updatedSong = updatedSong.copy(duration = duration)
                }
                // Update isVideo flag if it's different from the current value
                if (song.song.isVideo != mediaMetadata.isVideoSong) {
                    updatedSong = updatedSong.copy(isVideo = mediaMetadata.isVideoSong)
                }
                if (updatedSong != song.song) {
                    update(updatedSong)
                }
            }
        }
        if (!database.hasRelatedSongs(mediaId)) {
            val relatedEndpoint =
                YouTube.next(WatchEndpoint(videoId = mediaId)).getOrNull()?.relatedEndpoint
                    ?: return
            val relatedPage = YouTube.related(relatedEndpoint).getOrNull() ?: return
            database.query {
                relatedPage.songs
                    .map(SongItem::toMediaMetadata)
                    .onEach(::insert)
                    .map {
                        RelatedSongMap(
                            songId = mediaId,
                            relatedSongId = it.id
                        )
                    }
                    .forEach(::insert)
            }
        }
    }

    fun playQueue(
        queue: Queue,
        playWhenReady: Boolean = true,
    ) {
        if (!scope.isActive) scope = CoroutineScope(Dispatchers.Main) + Job()
        
        // Safety Check : Ensuring player is initilized
        if (!playerInitialized.value) {
            Timber.tag(TAG).w("playQueue called before player initialization, queuing request")
            scope.launch {
                playerInitialized.first { it }
                playQueue(queue, playWhenReady)
            }
            return
        }
        
        currentQueue = queue
        val queueGeneration = ++currentQueueGeneration
        queueTitle = null
        val persistShuffleAcrossQueues = dataStore.get(PersistentShuffleAcrossQueuesKey, false)
        val previousShuffleEnabled = player.shuffleModeEnabled
        if (!persistShuffleAcrossQueues) {
            player.shuffleModeEnabled = false
        }
        // Reset original queue size when starting a new queue
        originalQueueSize = 0
        if (queue.preloadItem != null) {
            player.setMediaItem(queue.preloadItem!!.toMediaItem())
            player.prepare()
            player.playWhenReady = playWhenReady
        }
        scope.launch(SilentHandler) {
            val initialStatus =
                withContext(Dispatchers.IO) {
                    queue.getInitialStatus()
                        .filterExplicit(dataStore.get(HideExplicitKey, false))
                        .filterVideoSongs(dataStore.get(HideVideoSongsKey, false))
                }
            if (queueGeneration != currentQueueGeneration) return@launch
            if (queue.preloadItem != null && player.playbackState == STATE_IDLE) return@launch
            if (initialStatus.title != null) {
                queueTitle = initialStatus.title
            }
            if (initialStatus.items.isEmpty()) return@launch
            if (queue.preloadItem != null) {
                val preloadId = queue.preloadItem!!.id
                val preloadIndex = initialStatus.items.indexOfFirst {
                    it.mediaId == preloadId || it.metadata?.id == preloadId
                }
                val itemsBeforePreload = if (preloadIndex > 0) {
                    initialStatus.items.subList(0, preloadIndex)
                } else {
                    emptyList()
                }
                val itemsAfterPreload = if (preloadIndex >= 0) {
                    initialStatus.items.subList(preloadIndex + 1, initialStatus.items.size)
                } else {
                    initialStatus.items.filterNot { it.mediaId == preloadId || it.metadata?.id == preloadId }
                }
                // Track original queue size for shuffle playlist first feature. Include the preloaded
                // item even when YouTube does not return it in the hydrated queue.
                originalQueueSize = itemsBeforePreload.size + 1 + itemsAfterPreload.size
                if (itemsBeforePreload.isNotEmpty()) {
                    player.addMediaItems(0, itemsBeforePreload)
                }
                if (itemsAfterPreload.isNotEmpty()) {
                    player.addMediaItems(itemsAfterPreload)
                }
                // Only replace the preloaded item when the hydrated queue contains the same song.
                // Some YouTube responses resolve a radio/endpoint request with the next item as the
                // current item; replacing unconditionally makes the tapped song appear to skip.
                if (preloadIndex >= 0) {
                    player.replaceMediaItem(player.currentMediaItemIndex, initialStatus.items[preloadIndex])
                }
            } else {
                // Track original queue size for shuffle playlist first feature
                originalQueueSize = initialStatus.items.size
                player.setMediaItems(
                    initialStatus.items,
                    if (initialStatus.mediaItemIndex >
                        0
                    ) {
                        initialStatus.mediaItemIndex
                    } else {
                        0
                    },
                    initialStatus.position,
                )
                player.prepare()
                player.playWhenReady = playWhenReady
            }

            // Rebuild shuffle order if shuffle is enabled
            if (player.shuffleModeEnabled) {
                val shufflePlaylistFirst = dataStore.get(ShufflePlaylistFirstKey, false)
                applyShuffleOrder(player.currentMediaItemIndex, player.mediaItemCount, shufflePlaylistFirst)
            }
        }
    }

    fun startRadioSeamlessly() {
        // Safety Check: Ensure Player is initilized
        if (!playerInitialized.value) {
            Timber.tag(TAG).w("startRadioSeamlessly called before player initialization")
            return
        }
        
        val currentMediaMetadata = player.currentMetadata ?: return

        val currentIndex = player.currentMediaItemIndex
        val currentMediaId = currentMediaMetadata.id

        scope.launch(SilentHandler) {
            // Use radio playlist format for better compatibility
            val radioQueue = YouTubeQueue(
                endpoint = WatchEndpoint(
                    videoId = currentMediaId,
                    playlistId = "RDAMVM$currentMediaId",
                    params = "wAEB"
                )
            )
            
            try {
                val initialStatus = withContext(Dispatchers.IO) {
                    radioQueue.getInitialStatus()
                        .filterExplicit(dataStore.get(HideExplicitKey, false))
                        .filterVideoSongs(dataStore.get(HideVideoSongsKey, false))
                }

                if (initialStatus.title != null) {
                    queueTitle = initialStatus.title
                }

                // Keep recommendations fresh: YouTube radio can repeat the seed, queue history,
                // and even duplicate entries within the same response.
                val existingMediaIds = (0 until player.mediaItemCount)
                    .map { player.getMediaItemAt(it).mediaId }
                    .toSet()
                val radioItems = initialStatus.items
                    .distinctBy { it.mediaId }
                    .filterNot { it.mediaId in existingMediaIds }

                // Do not apply an async result after the user has changed songs/queues.
                if (player.currentMediaItem?.mediaId != currentMediaId) return@launch
                if (radioItems.isEmpty()) {
                    throw IllegalStateException("Radio returned no new recommendations")
                }
                if (radioItems.isNotEmpty()) {
                    val itemCount = player.mediaItemCount

                    if (itemCount > currentIndex + 1) {
                        player.removeMediaItems(currentIndex + 1, itemCount)
                    }

                    player.addMediaItems(currentIndex + 1, radioItems)
                    if (player.shuffleModeEnabled) {
                        val shufflePlaylistFirst = dataStore.get(ShufflePlaylistFirstKey, false)
                        applyShuffleOrder(player.currentMediaItemIndex, player.mediaItemCount, shufflePlaylistFirst)
                    }
                }

                currentQueue = radioQueue
            } catch (e: Exception) {
                // Fallback: try with related endpoint
                try {
                    val nextResult = withContext(Dispatchers.IO) {
                        YouTube.next(WatchEndpoint(videoId = currentMediaId)).getOrNull()
                    }
                    nextResult?.relatedEndpoint?.let { relatedEndpoint ->
                        val relatedPage = withContext(Dispatchers.IO) {
                            YouTube.related(relatedEndpoint).getOrNull()
                        }
                        relatedPage?.songs?.let { songs ->
                            val existingMediaIds = (0 until player.mediaItemCount)
                                .map { player.getMediaItemAt(it).mediaId }
                                .toSet()
                            val radioItems = songs
                                .distinctBy { it.id }
                                .filterNot { it.id in existingMediaIds }
                                .map { it.toMediaItem() }
                                .filterExplicit(dataStore.get(HideExplicitKey, false))
                                .filterVideoSongs(dataStore.get(HideVideoSongsKey, false))
                            
                            if (radioItems.isNotEmpty() && player.currentMediaItem?.mediaId == currentMediaId) {
                                val itemCount = player.mediaItemCount
                                if (itemCount > currentIndex + 1) {
                                    player.removeMediaItems(currentIndex + 1, itemCount)
                                }
                                player.addMediaItems(currentIndex + 1, radioItems)
                                if (player.shuffleModeEnabled) {
                                    val shufflePlaylistFirst = dataStore.get(ShufflePlaylistFirstKey, false)
                                    applyShuffleOrder(player.currentMediaItemIndex, player.mediaItemCount, shufflePlaylistFirst)
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                    // Silent fail
                }
            }
        }
    }

    fun getAutomixAlbum(albumId: String) {
        scope.launch(SilentHandler) {
            YouTube
                .album(albumId)
                .onSuccess {
                    getAutomix(it.album.playlistId)
                }
        }
    }

    fun getAutomix(playlistId: String) {
        if (dataStore.get(SimilarContent, true) &&
            !(dataStore.get(DisableLoadMoreWhenRepeatAllKey, false) && player.repeatMode == REPEAT_MODE_ALL)) {
            scope.launch(SilentHandler) {
                try {
                    // Try primary method
                    YouTube.next(WatchEndpoint(playlistId = playlistId))
                        .onSuccess { firstResult ->
                            YouTube.next(WatchEndpoint(playlistId = firstResult.endpoint.playlistId))
                                .onSuccess { secondResult ->
                                    val queuedIds = (0 until player.mediaItemCount)
                                        .map { player.getMediaItemAt(it).mediaId }
                                        .toSet()
                                    automixItems.value = secondResult.items
                                        .distinctBy { it.id }
                                        .filterNot { it.id in queuedIds }
                                        .map { it.toMediaItem() }
                                }
                                .onFailure {
                                    // Fallback: use first result items
                                    if (firstResult.items.isNotEmpty()) {
                                        val queuedIds = (0 until player.mediaItemCount)
                                            .map { player.getMediaItemAt(it).mediaId }
                                            .toSet()
                                        automixItems.value = firstResult.items
                                            .distinctBy { it.id }
                                            .filterNot { it.id in queuedIds }
                                            .map { it.toMediaItem() }
                                    }
                                }
                        }
                        .onFailure {
                            // Fallback: try with radio format
                            val currentSong = player.currentMetadata
                            if (currentSong != null) {
                                YouTube.next(WatchEndpoint(
                                    videoId = currentSong.id,
                                    playlistId = "RDAMVM${currentSong.id}",
                                    params = "wAEB"
                                )).onSuccess { radioResult ->
                                    val filteredItems = radioResult.items
                                        .filter { it.id != currentSong.id }
                                        .map { it.toMediaItem() }
                                    if (filteredItems.isNotEmpty()) {
                                        automixItems.value = filteredItems
                                    }
                                }.onFailure {
                                    // Final fallback: try related endpoint
                                    YouTube.next(WatchEndpoint(videoId = currentSong.id)).getOrNull()?.relatedEndpoint?.let { relatedEndpoint ->
                                        YouTube.related(relatedEndpoint).onSuccess { relatedPage ->
                                            val relatedItems = relatedPage.songs
                                                .filter { it.id != currentSong.id }
                                                .map { it.toMediaItem() }
                                            if (relatedItems.isNotEmpty()) {
                                                automixItems.value = relatedItems

                                            }
                                        }
                                    }
                                }
                            }
                        }
                } catch (_: Exception) {
                    // Silent fail
                }
            }
        }
    }

    fun addToQueueAutomix(
        item: MediaItem,
        position: Int,
    ) {
        automixItems.value =
            automixItems.value.toMutableList().apply {
                removeAt(position)
            }
        addToQueue(listOf(item))
    }

    fun playNextAutomix(
        item: MediaItem,
        position: Int,
    ) {
        automixItems.value =
            automixItems.value.toMutableList().apply {
                removeAt(position)
            }
        playNext(listOf(item))
    }

    fun clearAutomix() {
        automixItems.value = emptyList()
    }

    private fun enqueueNextAutomixItemIfNeeded() {
        if (automixItems.value.isEmpty() || player.mediaItemCount == 0) return
        if (player.repeatMode != REPEAT_MODE_OFF || player.currentTimeline.isEmpty) return
        // On TV, automix only applies to normal (audio) songs. While a video-backed
        // song is playing it is disabled so SponsorBlock and the video queue behave
        // normally; the next video song is picked up via onMediaItemTransition instead.
        if (isTvDevice && isVideoMode) return

        val nextIndex = player.currentTimeline.getNextWindowIndex(
            player.currentMediaItemIndex,
            REPEAT_MODE_OFF,
            player.shuffleModeEnabled,
        )
        if (nextIndex == C.INDEX_UNSET) {
            // Automix must only insert regular (audio) songs. Video songs are left to
            // play natively and transition via onMediaItemTransition, where SponsorBlock
            // loads correctly. Picking the first non-video item also removes it from the
            // pool at its actual index.
            val nextItem = automixItems.value.firstOrNull { it.metadata?.isVideoSong != true }
            if (nextItem != null) {
                val index = automixItems.value.indexOf(nextItem)
                addToQueueAutomix(nextItem, index)
            }
        }
    }

    fun playNext(items: List<MediaItem>) {
        // If queue is empty or player is idle, play immediately instead
        if (player.mediaItemCount == 0 || player.playbackState == STATE_IDLE) {
            player.setMediaItems(items)
            player.prepare()
            // Don't start local playback if casting
            if (castConnectionHandler?.isCasting?.value != true) {
                player.play()
            }
            return
        }

        val insertIndex = player.currentMediaItemIndex + 1
        val shuffleEnabled = player.shuffleModeEnabled

        // Insert items immediately after the current item in the window/index space
        player.addMediaItems(insertIndex, items)
        player.prepare()

        if (shuffleEnabled) {
            // Rebuild shuffle order so that newly inserted items are played next
            val timeline = player.currentTimeline
            if (!timeline.isEmpty) {
                val size = timeline.windowCount
                val currentIndex = player.currentMediaItemIndex

                // Newly inserted indices are a contiguous range [insertIndex, insertIndex + items.size)
                val newIndices = (insertIndex until (insertIndex + items.size)).toSet()

                // Collect existing shuffle traversal order excluding current index
                val orderAfter = mutableListOf<Int>()
                var idx = currentIndex
                while (true) {
                    idx = timeline.getNextWindowIndex(idx, Player.REPEAT_MODE_OFF, /*shuffleModeEnabled=*/true)
                    if (idx == C.INDEX_UNSET) break
                    if (idx != currentIndex) orderAfter.add(idx)
                }

                val prevList = mutableListOf<Int>()
                var pIdx = currentIndex
                while (true) {
                    pIdx = timeline.getPreviousWindowIndex(pIdx, Player.REPEAT_MODE_OFF, /*shuffleModeEnabled=*/true)
                    if (pIdx == C.INDEX_UNSET) break
                    if (pIdx != currentIndex) prevList.add(pIdx)
                }
                prevList.reverse() // preserve original forward order

                val existingOrder = (prevList + orderAfter).filter { it != currentIndex && it !in newIndices }

                // Build new shuffle order: current -> newly inserted (in insertion order) -> rest
                val nextBlock = (insertIndex until (insertIndex + items.size)).toList()
                val finalOrder = IntArray(size)
                var pos = 0
                finalOrder[pos++] = currentIndex
                nextBlock.forEach { if (it in 0 until size) finalOrder[pos++] = it }
                existingOrder.forEach { if (pos < size) finalOrder[pos++] = it }

                // Fill any missing indices (safety) to ensure a full permutation
                if (pos < size) {
                    for (i in 0 until size) {
                        if (!finalOrder.contains(i)) {
                            finalOrder[pos++] = i
                            if (pos == size) break
                        }
                    }
                }

                player.setShuffleOrder(DefaultShuffleOrder(finalOrder, System.currentTimeMillis()))
            }
        }
    }

    fun addToQueue(items: List<MediaItem>) {
        player.addMediaItems(items)
        if (player.shuffleModeEnabled) {
            val shufflePlaylistFirst = dataStore.get(ShufflePlaylistFirstKey, false)
            applyShuffleOrder(player.currentMediaItemIndex, player.mediaItemCount, shufflePlaylistFirst)
        }
        player.prepare()
    }

    fun toggleLibrary() {
        scope.launch {
            val songToToggle = currentSong.first()
            songToToggle?.let {
                val isInLibrary = it.song.inLibrary != null
                val token = if (isInLibrary) it.song.libraryRemoveToken else it.song.libraryAddToken
                
                // Call YouTube API with feedback token if available
                token?.let { feedbackToken ->
                    YouTube.feedback(listOf(feedbackToken))
                }
                
                // Update local database
                database.query {
                    update(it.song.toggleLibrary())
                }
                currentMediaMetadata.value = player.currentMetadata
            }
        }
    }

    fun toggleLike() {
        scope.launch {
            val songToToggle = currentSong.first()
            songToToggle?.let {
                val song = it.song.toggleLike()
                database.query {
                    update(song)
                    syncUtils.likeSong(song)

                    // Check if auto-download on like is enabled and the song is now liked
                    if (dataStore.get(AutoDownloadOnLikeKey, false) && song.liked) {
                        // Trigger download for the liked song
                        val downloadRequest =
                            androidx.media3.exoplayer.offline.DownloadRequest
                                .Builder(song.id, song.id.toUri())
                                .setCustomCacheKey(song.id)
                                .setData(song.title.toByteArray())
                                .build()
                        androidx.media3.exoplayer.offline.DownloadService.sendAddDownload(
                            this@MusicService,
                            ExoDownloadService::class.java,
                            downloadRequest,
                            false
                        )
                    }
                }
                currentMediaMetadata.value = player.currentMetadata
            }
        }
    }

    fun toggleStartRadio() {
        startRadioSeamlessly()
    }

    private fun setupLoudnessEnhancer() {
        val audioSessionId = player.audioSessionId

        if (audioSessionId == C.AUDIO_SESSION_ID_UNSET || audioSessionId <= 0) {
            Timber.tag(TAG).w("setupLoudnessEnhancer: invalid audioSessionId ($audioSessionId), cannot create effect yet")
            return
        }

        // Create or recreate enhancer if needed
        if (loudnessEnhancer == null) {
            try {
                loudnessEnhancer = LoudnessEnhancer(audioSessionId)
                Timber.tag(TAG).d("LoudnessEnhancer created for sessionId=$audioSessionId")
            } catch (e: Exception) {
                reportException(e)
                loudnessEnhancer = null
                return
            }
        }

        scope.launch {
            try {
                val currentMediaId = withContext(Dispatchers.Main) {
                    player.currentMediaItem?.mediaId
                }

                val normalizeAudio = withContext(Dispatchers.IO) {
                    dataStore.data.map { it[AudioNormalizationKey] ?: true }.first()
                }

                if (normalizeAudio && currentMediaId != null) {
                    val format = withContext(Dispatchers.IO) {
                        database.format(currentMediaId).first()
                    }

                    Timber.tag(TAG).d("Audio normalization enabled: $normalizeAudio")
                    Timber.tag(TAG).d("Format loudnessDb: ${format?.loudnessDb}, perceptualLoudnessDb: ${format?.perceptualLoudnessDb}")

                    // Use loudnessDb if available, otherwise fall back to perceptualLoudnessDb
                    val loudness = format?.loudnessDb ?: format?.perceptualLoudnessDb

                    withContext(Dispatchers.Main) {
                        if (loudness != null) {
                            val loudnessDb = loudness.toFloat()
                            val targetGain = (-loudnessDb * 100).toInt()
                            val clampedGain = targetGain.coerceIn(MIN_GAIN_MB, MAX_GAIN_MB)

                            Timber.tag(TAG).d("Calculated raw normalization gain: $targetGain mB (from loudness: $loudnessDb)")
                            
                            try {
                                loudnessEnhancer?.setTargetGain(clampedGain)
                                loudnessEnhancer?.enabled = true
                                Timber.tag(TAG).i("LoudnessEnhancer gain applied: $clampedGain mB")
                            } catch (e: Exception) {
                                Timber.tag(TAG).e(e, "Failed to apply loudness enhancement")
                                reportException(e)
                                releaseLoudnessEnhancer()
                            }
                        } else {
                            loudnessEnhancer?.enabled = false
                            Timber.tag(TAG).w("Normalization enabled but no loudness data available - no normalization applied")
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        loudnessEnhancer?.enabled = false
                        Timber.tag(TAG).d("setupLoudnessEnhancer: normalization disabled or mediaId unavailable")
                    }
                }
            } catch (e: Exception) {
                reportException(e)
                releaseLoudnessEnhancer()
            }
        }
    }

    private fun releaseLoudnessEnhancer() {
        try {
            loudnessEnhancer?.release()
            Timber.tag(TAG).d("LoudnessEnhancer released")
        } catch (e: Exception) {
            reportException(e)
            Timber.tag(TAG).e(e, "Error releasing LoudnessEnhancer: ${e.message}")
        } finally {
            loudnessEnhancer = null
        }
    }

    private fun openAudioEffectSession() {
        if (isAudioEffectSessionOpened) return
        val sessionId = player.audioSessionId
        if (sessionId == C.AUDIO_SESSION_ID_UNSET || sessionId <= 0) return
        isAudioEffectSessionOpened = true
        audioEffectSessionId = sessionId
        setupLoudnessEnhancer()
        sendBroadcast(
            Intent(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION).apply {
                putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
                putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
                putExtra(AudioEffect.EXTRA_CONTENT_TYPE, AudioEffect.CONTENT_TYPE_MUSIC)
            },
        )
    }

    private fun closeAudioEffectSession() {
        if (!isAudioEffectSessionOpened) return
        val sessionId = audioEffectSessionId
        isAudioEffectSessionOpened = false
        audioEffectSessionId = C.AUDIO_SESSION_ID_UNSET
        releaseLoudnessEnhancer()
        sendBroadcast(
            Intent(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION).apply {
                putExtra(AudioEffect.EXTRA_AUDIO_SESSION, sessionId)
                putExtra(AudioEffect.EXTRA_PACKAGE_NAME, packageName)
            },
        )
    }

    override fun onMediaItemTransition(
        mediaItem: MediaItem?,
        reason: Int,
    ) {
        // Skip transitions triggered by our own MergingMediaSource injection.
        // The merged source has MediaItem.EMPTY which would cause false "new
        // song" detection and resetVideoMode(), destroying ongoing video switch
        // state (originalAudioMediaItem, currentMediaMetadata, etc.)
        if (isInjectingVideoSource) {
            Timber.d("onMediaItemTransition: Skipping - video source injection in progress")
            return
        }
        // Update immediately for queue transitions. Waiting for the later
        // batched onEvents update can leave TV video mode resolving streams
        // against the previous item while the next item's audio is already
        // playing, which shows a black video surface.
        currentMediaMetadata.value = mediaItem?.metadata
        runCatching { enqueueNextAutomixItemIfNeeded() }

        // Load SponsorBlock for audio-only playback here. In video mode the
        // actual YouTube video id is resolved later by setVideoMode(), so using
        // mediaItem.mediaId during transitions can query the wrong SponsorBlock id.
        if (sponsorBlockManager.enabled.value && !isVideoMode && !_isVideoSwitching.value && mediaItem?.mediaId != null) {
            val mediaId = mediaItem.mediaId
            scope.launch {
                try {
                    sponsorBlockManager.loadSegments(mediaId, currentPlaybackDurationMs())
                } catch (e: Exception) {
                    Timber.e(e, "onMediaItemTransition: SponsorBlock load failed")
                }
            }
        }

        val newMediaId = mediaItem?.mediaId

        // currentMediaMetadata was just overwritten with the incoming item's metadata,
        // whose .id is never set by our MediaItem builders — so comparing it against
        // mediaId can never detect a change. Compare against the previously-seen
        // mediaId instead. Transitions fired by our own video-mode source replacement
        // carry the SAME mediaId and are ignored, breaking the infinite re-fetch loop
        // that showed a black video surface on the next song and eventually crashed.
        val isNewSong = newMediaId != null && newMediaId != lastTransitionMediaId
        lastTransitionMediaId = newMediaId

        if (isNewSong) {
            if (RemoveMusicVocalRemover.state.value.active) {
                stopExternalStemPlayers()
                RemoveMusicVocalRemover.onSongChanged(this, newMediaId, downloadUtil)
            }
            // If we were in video mode, just clear the source tracking without
            // resetting the full video state — this avoids the black screen gap
            // where video surface has no content while we re-fetch for the new song.
            if (isVideoMode) {
                videoSwitchJob?.cancel()
                _isVideoSwitching.value = false
                sponsorBlockManager.reset()
                currentVideoUrl = null
                currentVideoSourceMediaId = null
                _currentVideoId.value = null
                _videoFetchError.value = null
                _videoModeMessage.value = null
                // Keep isVideoMode = true so the video surface stays visible
                // during the transition to the next song
            } else {
                resetVideoMode()
            }

            // Video songs in the music path always play as audio. Never
            // auto-fetch/switch to a matching video. Drop any lingering video
            // mode so playback continues as audio on every transition.
            if (isVideoMode) {
                Timber.d("onMediaItemTransition: Dropping video mode (music path plays audio)")
                resetVideoMode()
            } else {
                _isVideoSwitching.value = false
            }
        } else {
            Timber.d("onMediaItemTransition: Skipping video mode reset - currently switching")
        }

        lastPlaybackSpeed = -1.0f // force update song

        setupLoudnessEnhancer()

        discordUpdateJob?.cancel()

        scrobbleManager?.onSongStop()
        if (player.playWhenReady && player.playbackState == Player.STATE_READY) {
            scrobbleManager?.onSongStart(player.currentMetadata, duration = player.duration)
        }

        // Ensure playback continues when transitioning to new media item (including in background)
        // This fixes autoplay not starting until app is reopened
        if (player.playWhenReady && !player.isPlaying && player.playbackState == Player.STATE_READY) {
            player.play()
        }

        // Sync Cast when media changes and Cast is connected
        // Skip if this change was triggered by Cast sync (to prevent loops)
        if (castConnectionHandler?.isCasting?.value == true && 
            castConnectionHandler?.isSyncingFromCast != true && 
            mediaItem != null) {
            val metadata = mediaItem.metadata
            if (metadata != null) {
                // Try to navigate to the item if it's already in Cast queue
                // This avoids a full reload which causes the widget to refresh
                val navigated = castConnectionHandler?.navigateToMediaIfInQueue(metadata.id) ?: false
                if (!navigated) {
                    // Item not in Cast queue, need to reload
                    castConnectionHandler?.loadMedia(metadata)
                }
            }
        }

        // Auto load more songs from queue
        if (dataStore.get(AutoLoadMoreKey, true) &&
            reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT &&
            player.mediaItemCount - player.currentMediaItemIndex <= 5 &&
            currentQueue.hasNextPage() &&
            !(dataStore.get(DisableLoadMoreWhenRepeatAllKey, false) && player.repeatMode == REPEAT_MODE_ALL)
        ) {
            scope.launch(SilentHandler) {
                val mediaItems = withContext(Dispatchers.IO) {
                    currentQueue.nextPage()
                        .filterExplicit(dataStore.get(HideExplicitKey, false))
                        .filterVideoSongs(dataStore.get(HideVideoSongsKey, false))
                }
                if (player.playbackState != STATE_IDLE && mediaItems.isNotEmpty()) {
                    val queuedIds = (0 until player.mediaItemCount)
                        .map { player.getMediaItemAt(it).mediaId }
                        .toSet()
                    val newMediaItems = mediaItems
                        .distinctBy { it.mediaId }
                        .filterNot { it.mediaId in queuedIds }
                    player.addMediaItems(newMediaItems)
                    if (player.shuffleModeEnabled) {
                        val shufflePlaylistFirst = dataStore.get(ShufflePlaylistFirstKey, false)
                        applyShuffleOrder(player.currentMediaItemIndex, player.mediaItemCount, shufflePlaylistFirst)
                    }
                }
            }
        }

        // Save state when media item changes
        if (dataStore.get(PersistentQueueKey, true)) {
            saveQueueToDisk()
        }

        // Update TV home screen recommendations when song changes
        val isTv = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
        if (isTv) {
            try {
                val helperClass = Class.forName("com.sanmusic.app.tv.TvRecommendationHelper")
                val method = helperClass.getMethod("scheduleUpdate", android.content.Context::class.java)
                method.invoke(null, this)
            } catch (_: ClassNotFoundException) {
                // TV variant not available in this build
            } catch (e: Exception) {
                Timber.tag(TAG).w(e, "Failed to update TV recommendations")
            }
        }
    }

    override fun onPlaybackStateChanged(
        @Player.State playbackState: Int,
    ) {
        // If we're in video mode and playback fails, show an error but don't auto-switch
        // Let the user manually toggle back to audio
        if (isVideoMode && playbackState == Player.STATE_IDLE) {
            // Player went idle while in video mode - check if this is due to an error
            // We'll rely on onPlayerError to handle this
            Timber.d("onPlaybackStateChanged: Video mode, player went to STATE_IDLE")
        }

        // Save state when playback state changes (but not during silence skipping)
        if (dataStore.get(PersistentQueueKey, true) && !isSilenceSkipping) {
            saveQueueToDisk()
        }

        if (playbackState == Player.STATE_READY) {
            consecutivePlaybackErr = 0
            retryCount = 0
            waitingForNetworkConnection.value = false
            retryJob?.cancel()
            if (::sponsorBlockManager.isInitialized) {
                sponsorBlockManager.updateDuration(currentPlaybackDurationMs())
            }
            
            // Reset retry count for current song on successful playback
            player.currentMediaItem?.mediaId?.let { mediaId ->
                resetRetryCount(mediaId)
                Timber.tag(TAG).d("Playback successful for $mediaId, reset retry count")
            }
            scheduleCrossfade()
        }

        if (playbackState == Player.STATE_IDLE || playbackState == Player.STATE_ENDED) {
            scrobbleManager?.onSongStop()

            // Update TV recommendations when playback stops (saves position for "Continue Watching")
            val isTv = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
            if (isTv) {
                try {
                    val helperClass = Class.forName("com.sanmusic.app.tv.TvRecommendationHelper")
                    val method = helperClass.getMethod("scheduleUpdate", android.content.Context::class.java)
                    method.invoke(null, this@MusicService)
                } catch (_: ClassNotFoundException) {
                    // TV variant not available in this build
                } catch (e: Exception) {
                    Timber.tag(TAG).w(e, "Failed to update TV recommendations on stop")
                }
            }
        }
        if (playbackState == Player.STATE_ENDED && RemoveMusicVocalRemover.state.value.active) {
            deactivateVocalInstrumentSeparation()
        }
        refreshStemClockFromMainThread()
    }

    override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
        // Safety net: if local player tries to start while casting, immediately pause it
        if (playWhenReady && castConnectionHandler?.isCasting?.value == true) {
            player.pause()
            return
        }

        if (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_USER_REQUEST) {
            if (playWhenReady) {
                isPausedByVolumeMute = false
            }

            if (!playWhenReady && !isPausedByVolumeMute) {
                wasPlayingBeforeVolumeMute = false
            }
        }

        if (playWhenReady) {
            setupLoudnessEnhancer()
        }
        refreshStemClockFromMainThread()
    }

    override fun onEvents(
        player: Player,
        events: Player.Events,
    ) {
        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_PLAY_WHEN_READY_CHANGED,
                Player.EVENT_IS_PLAYING_CHANGED,
                EVENT_TIMELINE_CHANGED,
                Player.EVENT_MEDIA_ITEM_TRANSITION,
            )
        ) {
            scheduleCrossfade()
        }
        if (events.containsAny(
                Player.EVENT_PLAYBACK_STATE_CHANGED,
                Player.EVENT_PLAY_WHEN_READY_CHANGED
            )
        ) {
            val isBufferingOrReady =
                player.playbackState == Player.STATE_BUFFERING || player.playbackState == Player.STATE_READY
            if (isBufferingOrReady && player.playWhenReady) {
                val focusGranted = requestAudioFocus()
                if (focusGranted) {
                    openAudioEffectSession()
                }
            } else {
                closeAudioEffectSession()
            }
        }
        if (events.containsAny(EVENT_TIMELINE_CHANGED, EVENT_POSITION_DISCONTINUITY)) {
            if (!isInjectingVideoSource) {
                currentMediaMetadata.value = player.currentMetadata
            }
        }

        // Widget, Daily Streak, and Discord RPC updates
        if (events.containsAny(Player.EVENT_IS_PLAYING_CHANGED)) {
            updateWidgetUI(player.isPlaying)
            if (player.isPlaying) {
                startWidgetUpdates()
                if (player.currentMetadata != null) {
                    StreakManager.onMusicPlayed(applicationContext)
                }
            } else {
                stopWidgetUpdates()
            }
            if (!player.isPlaying && !events.containsAny(Player.EVENT_POSITION_DISCONTINUITY, Player.EVENT_MEDIA_ITEM_TRANSITION)) {
                if (DiscordRpcManager.isReady()) DiscordRpcManager.clear()
            }
        }

        // Update Discord RPC when media item changes or playback starts.
        // Trigger on MEDIA_ITEM_TRANSITION unconditionally: during an automatic
        // transition the player is frequently still buffering (not yet "playing"),
        // so gating on player.isPlaying would skip the update and leave the
        // previous song's text/thumbnail showing. The play-state change handler
        // (below) re-syncs once playback actually resumes.
        if (events.containsAny(Player.EVENT_MEDIA_ITEM_TRANSITION) ||
            (events.containsAny(Player.EVENT_IS_PLAYING_CHANGED) && player.isPlaying)
        ) {
            syncDiscordState()
        }

        // Scrobbling
        if (events.containsAny(Player.EVENT_IS_PLAYING_CHANGED)) {
            scrobbleManager?.onPlayerStateChanged(player.isPlaying, player.currentMetadata, duration = player.duration)
        }

    }

    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
        updateNotification()
        if (shuffleModeEnabled) {
            // If queue is empty, don't shuffle
            if (player.mediaItemCount == 0) return

            val shufflePlaylistFirst = dataStore.get(ShufflePlaylistFirstKey, false)
            val currentIndex = player.currentMediaItemIndex
            val totalCount = player.mediaItemCount

            applyShuffleOrder(currentIndex, totalCount, shufflePlaylistFirst)
        }
        scheduleCrossfade()

        // Save shuffle mode to preferences
        if (dataStore.get(RememberShuffleAndRepeatKey, true)) {
            scope.launch {
                dataStore.edit { settings ->
                    settings[ShuffleModeKey] = shuffleModeEnabled
                }
            }
        }

        // Save state when shuffle mode changes
        if (dataStore.get(PersistentQueueKey, true)) {
            saveQueueToDisk()
        }
    }

    override fun onRepeatModeChanged(repeatMode: Int) {
        updateNotification()
        scheduleCrossfade()
        scope.launch {
            dataStore.edit { settings ->
                settings[RepeatModeKey] = repeatMode
            }
        }

        // Save state when repeat mode changes
        if (dataStore.get(PersistentQueueKey, true)) {
            saveQueueToDisk()
        }
    }

    /**
     * Applies a new shuffle order to the player, maintaining the current item's position.
     * If `shufflePlaylistFirst` is true, it attempts to shuffle original items separately from added items.
     */
    private fun applyShuffleOrder(
        currentIndex: Int,
        totalCount: Int,
        shufflePlaylistFirst: Boolean
    ) {
        if (totalCount == 0) return

        if (shufflePlaylistFirst && originalQueueSize > 0 && originalQueueSize < totalCount) {
            // Shuffle original items and added items separately
            val originalIndices = (0 until originalQueueSize).filter { it != currentIndex }.toMutableList()
            val addedIndices = (originalQueueSize until totalCount).filter { it != currentIndex }.toMutableList()
            
            originalIndices.shuffle()
            addedIndices.shuffle()
            
            val shuffledIndices = IntArray(totalCount)
            var pos = 0
            shuffledIndices[pos++] = currentIndex
            
            if (currentIndex < originalQueueSize) {
                originalIndices.forEach { shuffledIndices[pos++] = it }
                addedIndices.forEach { shuffledIndices[pos++] = it }
            } else {
                (0 until originalQueueSize).shuffled().forEach { shuffledIndices[pos++] = it }
                addedIndices.forEach { shuffledIndices[pos++] = it }
            }
            player.setShuffleOrder(DefaultShuffleOrder(shuffledIndices, System.currentTimeMillis()))
        } else {
            val shuffledIndices = IntArray(totalCount) { it }
            shuffledIndices.shuffle()
            // Ensure current item is first in the shuffle order
            val currentItemIndexInShuffled = shuffledIndices.indexOf(currentIndex)
            if (currentItemIndexInShuffled != -1) { // Should always be true if totalCount > 0
                val temp = shuffledIndices[0]
                shuffledIndices[0] = shuffledIndices[currentItemIndexInShuffled]
                shuffledIndices[currentItemIndexInShuffled] = temp
            }
            player.setShuffleOrder(DefaultShuffleOrder(shuffledIndices, System.currentTimeMillis()))
        }
    }

    override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
        super.onPlaybackParametersChanged(playbackParameters)
        if (playbackParameters.speed != lastPlaybackSpeed) {
            lastPlaybackSpeed = playbackParameters.speed
            discordUpdateJob?.cancel()

            // Playback speed changes the presence timestamps; re-sync after it settles.
            DiscordRpcManager.notifySettingsChanged()
            discordUpdateJob = scope.launch {
                delay(1000)
                if (player.playWhenReady && player.playbackState == Player.STATE_READY) {
                    syncDiscordState()
                }
            }
        }
    }

    /**
     * Extracts the HTTP response code from an error's cause chain.
     * Returns null if no HTTP response code is found.
     */
    private fun getHttpResponseCode(error: PlaybackException): Int? {
        var cause: Throwable? = error.cause
        while (cause != null) {
            if (cause is HttpDataSource.InvalidResponseCodeException) {
                return cause.responseCode
            }
            cause = cause.cause
        }
        return null
    }
    
    /**
     * Checks if the error is caused by an expired/forbidden URL (HTTP 403).
     * This typically happens when a YouTube stream URL expires.
     */
    private fun isExpiredUrlError(error: PlaybackException): Boolean {
        val responseCode = getHttpResponseCode(error)
        return responseCode == 403
    }

    /**
     * Checks if the error is YouTube/GVS throttling us (HTTP 429/503).
     * Retrying these quickly makes the block worse — they need long backoff.
     */
    private fun isRateLimitError(error: PlaybackException): Boolean {
        val responseCode = getHttpResponseCode(error)
        return responseCode == 429 || responseCode == 503
    }

    /**
     * Checks if the error is a Range Not Satisfiable error (HTTP 416).
     * This happens when cached data doesn't match the actual stream size.
     */
    private fun isRangeNotSatisfiableError(error: PlaybackException): Boolean {
        val responseCode = getHttpResponseCode(error)
        return responseCode == 416
    }
    
    /**
     * Checks if the error is a "page needs to be reloaded" error.
     * This is a YouTube-specific error that requires refreshing the stream.
     */
    private fun isPageReloadError(error: PlaybackException): Boolean {
        val errorMessage = error.message?.lowercase() ?: ""
        val causeMessage = error.cause?.message?.lowercase() ?: ""
        val innerCauseMessage = error.cause?.cause?.message?.lowercase() ?: ""
        
        val reloadKeywords = listOf(
            "page needs to be reloaded",
            "pagina deve essere ricaricata",
            "la pagina deve essere ricaricata",
            "page must be reloaded",
            "reload",
            "ricaricata"
        )
        
        return reloadKeywords.any { keyword ->
            errorMessage.contains(keyword) || 
            causeMessage.contains(keyword) || 
            innerCauseMessage.contains(keyword)
        }
    }

    private fun isNetworkRelatedError(error: PlaybackException): Boolean {
        // Don't treat specific errors as network errors - they need special handling
        if (isExpiredUrlError(error) || isRangeNotSatisfiableError(error) || isPageReloadError(error)) {
            return false
        }
        return error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ||
                error.errorCode == PlaybackException.ERROR_CODE_IO_INVALID_HTTP_CONTENT_TYPE ||
                error.cause is java.net.ConnectException ||
                error.cause is java.net.UnknownHostException ||
                (error.cause as? PlaybackException)?.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
    }

    /**
     * Checks if the error is caused by AudioTrack write or initialization failures.
     * These errors indicate the audio renderer is in a corrupted/invalid state.
     */
    // Check if this is a stream/audio decoding error (usually indicates corrupted stream)
    private fun isStreamDecodingError(error: PlaybackException): Boolean {
        val message = error.message ?: ""
        val causeMessage = error.cause?.message ?: ""
        return message.contains("srcPos=") ||
                message.contains("src.length") ||
                message.contains("AudioTrack") ||
                causeMessage.contains("srcPos=") ||
                causeMessage.contains("src.length") ||
                causeMessage.contains("AudioTrack")
    }

    private fun isAudioRendererError(error: PlaybackException): Boolean {
        return error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED ||
                error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
                (error.cause as? PlaybackException)?.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED ||
                (error.cause as? PlaybackException)?.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED
    }

    override fun onPlayerError(error: PlaybackException) {
        super.onPlayerError(error)
        
        // Safety check : ensuring player is still initialized
        if (!playerInitialized.value) {
            Timber.tag(TAG).e(error, "Player error occurred but player not initialized")
            return
        }
        
        val mediaId = player.currentMediaItem?.mediaId
        Timber.tag(TAG).w(error, "Player error occurred for $mediaId: errorCode=${error.errorCode}, message=${error.message}, isVideoMode=$isVideoMode")
        
        if (isVideoMode && mediaId != null) {
            Timber.tag(TAG).d("Video mode error - switching back to audio")
            currentVideoSourceMediaId?.let { videoSearchCache.remove(it) }
            _videoModeMessage.value = if (error.message?.contains("inappropriate", ignoreCase = true) == true) {
                "Video dibatasi, memutar audio saja"
            } else {
                "Video gagal dimuat, memutar audio saja"
            }
            scope.launch {
                switchToAudioMode()
            }
            return
        }
        
        reportException(error)

        // Check if this song has failed too many times
        if (mediaId != null && hasExceededRetryLimit(mediaId)) {
            Timber.tag(TAG).w("Song $mediaId has exceeded retry limit, skipping")
            markSongAsFailed(mediaId)
            handleFinalFailure()
            return
        }

        // Aggressive cache clearing for all playback errors
        if (mediaId != null) {
            performAggressiveCacheClear(mediaId)
        }

        // Handle specific error types with strict strategies
        when {
            isStreamDecodingError(error) -> {
                Timber.tag(TAG).d("Stream decoding error detected, skipping to next track")
                skipOnError()
                return
            }
            isAudioRendererError(error) -> {
                Timber.tag(TAG).d("AudioTrack error detected (${error.errorCode}), performing safe recovery")
                handleAudioRendererError(mediaId)
                return
            }
            isRangeNotSatisfiableError(error) -> {
                Timber.tag(TAG).d("Range Not Satisfiable (416) detected, performing strict recovery")
                handleRangeNotSatisfiableError(mediaId)
                return
            }
            isPageReloadError(error) -> {
                Timber.tag(TAG).d("Page reload error detected, performing strict recovery")
                handlePageReloadError(mediaId)
                return
            }
            isRateLimitError(error) -> {
                Timber.tag(TAG).d("Rate limit error detected (${getHttpResponseCode(error)}), performing long backoff")
                handleRateLimitError(mediaId)
                return
            }
            isExpiredUrlError(error) -> {
                Timber.tag(TAG).d("Expired URL (403) detected, refreshing stream URL")
                handleExpiredUrlError(mediaId)
                return
            }

            !isNetworkConnected.value || isNetworkRelatedError(error) -> {
                Timber.tag(TAG).d("Network-related error detected, waiting for connection")
                waitOnNetworkError()
                return
            }
        }
        
        // PARSING CONTAINER MALFORMED usually means the stream URL served non-media
        // bytes (expired/invalid URL, bot-check page) rather than a genuinely corrupt
        // file. Re-resolve the URL once with fresh tokens instead of stopping.
        if (error.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED) {
            Timber.tag(TAG).d("Parsing container malformed error detected, refreshing stream URL")
            handleGenericIOError(mediaId)
            return
        }
        
        // For IO_UNSPECIFIED and IO_BAD_HTTP_STATUS, try recovery first
        if (error.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED ||
            error.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) {
            Timber.tag(TAG).d("IO error detected (${error.errorCode}), attempting recovery")
            handleGenericIOError(mediaId)
            return
        }

        // Final fallback
        if (dataStore.get(AutoSkipNextOnErrorKey, true)) {
            Timber.tag(TAG).d("Auto-skipping to next track due to unrecoverable error")
            skipOnError()
        } else {
            Timber.tag(TAG).d("Stopping playback due to unrecoverable error")
            stopOnError()
        }
    }

    /**
     * Performs aggressive cache clearing for a media item.
     * Clears both player cache and download cache, plus URL cache.
     */
    private fun performAggressiveCacheClear(mediaId: String) {
        Timber.tag(TAG).d("Performing aggressive cache clear for $mediaId")
        
        // Clear URL cache
        songUrlCache.remove(mediaId)
        
        // Clear player cache
        try {
            playerCache.removeResource(mediaId)
            Timber.tag(TAG).d("Cleared player cache for $mediaId")
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to clear player cache for $mediaId")
        }
        
        // Clear decryption caches
        try {
            YTPlayerUtils.forceRefreshForVideo(mediaId)
            Timber.tag(TAG).d("Cleared decryption caches for $mediaId")
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to clear decryption caches for $mediaId")
        }
    }
    
    /**
     * Checks if a song has exceeded the retry limit.
     */
    private fun hasExceededRetryLimit(mediaId: String): Boolean {
        val currentRetries = currentMediaIdRetryCount[mediaId] ?: 0
        return currentRetries >= MAX_RETRY_PER_SONG
    }
    
    /**
     * Increments the retry count for a song.
     */
    private fun incrementRetryCount(mediaId: String) {
        val currentRetries = currentMediaIdRetryCount[mediaId] ?: 0
        currentMediaIdRetryCount[mediaId] = currentRetries + 1
        Timber.tag(TAG).d("Retry count for $mediaId: ${currentRetries + 1}/$MAX_RETRY_PER_SONG")
    }
    
    /**
     * Resets the retry count for a song (called on successful playback).
     */
    private fun resetRetryCount(mediaId: String) {
        currentMediaIdRetryCount.remove(mediaId)
        recentlyFailedSongs.remove(mediaId)
    }
    
    /**
     * Marks a song as failed to prevent further retry attempts.
     */
    private fun markSongAsFailed(mediaId: String) {
        recentlyFailedSongs.add(mediaId)
        currentMediaIdRetryCount.remove(mediaId)
        
        // Schedule cleanup of failed songs list after 5 minutes
        failedSongsClearJob?.cancel()
        failedSongsClearJob = scope.launch {
            delay(5 * 60 * 1000L) // 5 minutes
            recentlyFailedSongs.clear()
            Timber.tag(TAG).d("Cleared recently failed songs list")
        }
    }
    
    /**
     * Handles AudioTrack errors (write failed, init failed) with safe recovery.
     * These errors indicate the audio renderer is corrupted and needs careful reset.
     */
    private fun handleAudioRendererError(mediaId: String?) {
        if (mediaId == null) {
            handleFinalFailure()
            return
        }
        
        incrementRetryCount(mediaId)
        
        retryJob?.cancel()
        retryJob = scope.launch {
            try {
                // Pause playback immediately to stop the renderer
                player.pause()
                Timber.tag(TAG).d("Paused playback due to AudioTrack error")
                
                // Wait longer for audio renderer to settle before retry
                // This prevents the renderer from continuing to fail in a loop
                delay(RETRY_DELAY_MS * 3) // 3 seconds instead of 1 second
                
                // Check if player is still initialized before attempting recovery
                if (!playerInitialized.value) {
                    Timber.tag(TAG).w("Player no longer initialized, aborting AudioTrack recovery")
                    return@launch
                }
                
                val currentIndex = player.currentMediaItemIndex
                if (currentIndex != C.INDEX_UNSET) {
                    // Seek to current position to force a clean audio renderer reinit
                    val currentPosition = player.currentPosition
                    player.seekTo(currentIndex, currentPosition)
                    player.prepare()
                    
                    Timber.tag(TAG).d("Retrying playback for $mediaId after AudioTrack error")
                    
                    // Resume playback if it wasn't paused by user
                    if (wasPlayingBeforeAudioFocusLoss) {
                        delay(500) // Brief delay to allow renderer to be ready
                        if (hasAudioFocus && playerInitialized.value) {
                            if (castConnectionHandler?.isCasting?.value != true) {
                                player.play()
                            }
                        }
                    }
                } else {
                    Timber.tag(TAG).w("Invalid media item index during AudioTrack recovery")
                    handleFinalFailure()
                }
            } catch (e: Exception) {
                Timber.tag(TAG).e(e, "Error during AudioTrack error recovery")
                handleFinalFailure()
            }
        }
    }
    
    /**
     * Handles Range Not Satisfiable (416) errors with strict recovery.
     * This error occurs when cached data doesn't match the actual stream size.
     */
    private fun handleRangeNotSatisfiableError(mediaId: String?) {
        if (mediaId == null) {
            handleFinalFailure()
            return
        }
        
        incrementRetryCount(mediaId)
        
        retryJob?.cancel()
        retryJob = scope.launch {
            // Clear all caches aggressively
            performAggressiveCacheClear(mediaId)
            
            // Wait before retry
            delay(RETRY_DELAY_MS)

            // Force re-prepare from position 0 to avoid range issues
            val currentIndex = player.currentMediaItemIndex
            player.seekTo(currentIndex, 0)
            player.prepare()
            
            Timber.tag(TAG).d("Retrying playback for $mediaId after 416 error (from position 0)")
        }
    }
    
    /**
     * Handles "page needs to be reloaded" errors with strict recovery.
     * This requires clearing decryption caches and getting fresh stream URLs.
     */
    private fun handlePageReloadError(mediaId: String?) {
        if (mediaId == null) {
            handleFinalFailure()
            return
        }

        poTokenProvider.invalidatePoTokens(mediaId)
        
        incrementRetryCount(mediaId)
        val retryAttempt = currentMediaIdRetryCount[mediaId] ?: 1
        
        retryJob?.cancel()
        retryJob = scope.launch {
            Timber.tag(TAG).d("Handling page reload error for $mediaId")
            
            // Clear all caches including decryption caches
            performAggressiveCacheClear(mediaId)
            
            // Exponential backoff: 4s, 8s, 16s — page reload errors are often rate-limited
            val delayMs = RETRY_DELAY_MS * (1L shl (retryAttempt + 1))
            delay(delayMs)
            
            // Re-prepare the player
            val currentPosition = player.currentPosition
            val currentIndex = player.currentMediaItemIndex
            player.seekTo(currentIndex, currentPosition)
            player.prepare()
            
            Timber.tag(TAG).d("Retrying playback for $mediaId after page reload error (attempt $retryAttempt, delay ${delayMs}ms)")
        }
    }
    
    /**
     * Handles rate-limit (429/503) errors with a long backoff. Hammering
     * googlevideo/innertube while throttled extends the block, so wait
     * 15s -> 30s -> 60s before one careful retry; after MAX_RETRY_PER_SONG
     * failures the normal skip/stop path takes over.
     */
    private fun handleRateLimitError(mediaId: String?) {
        if (mediaId == null) {
            handleFinalFailure()
            return
        }

        poTokenProvider.invalidatePoTokens(mediaId)
        incrementRetryCount(mediaId)
        val retryAttempt = currentMediaIdRetryCount[mediaId] ?: 1

        songUrlCache.remove(mediaId)

        // 15s, 30s, 60s — generous on purpose.
        val delayMs = minOf(15_000L shl (retryAttempt - 1), 60_000L)

        retryJob?.cancel()
        retryJob = scope.launch {
            delay(delayMs)

            if (!playerInitialized.value) return@launch
            val currentPosition = player.currentPosition
            val currentIndex = player.currentMediaItemIndex
            player.seekTo(currentIndex, currentPosition)
            player.prepare()

            Timber.tag(TAG).d("Retrying playback for $mediaId after rate-limit backoff (attempt $retryAttempt, delay ${delayMs}ms)")
        }
    }

    /**
     * Handles expired URL (403) errors by clearing caches and retrying.
     */
    private fun handleExpiredUrlError(mediaId: String?) {
        if (mediaId == null) {
            handleFinalFailure()
            return
        }

        poTokenProvider.invalidatePoTokens(mediaId)
        
        incrementRetryCount(mediaId)
        val retryAttempt = currentMediaIdRetryCount[mediaId] ?: 1
        
        // Clear the cached URL
        songUrlCache.remove(mediaId)
        Timber.tag(TAG).d("Cleared cached URL for $mediaId")
        
        // Clear decryption caches
        try {
            YTPlayerUtils.forceRefreshForVideo(mediaId)
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to clear decryption caches")
        }
        
        // Exponential backoff: 2s, 4s, 8s — YouTube rate-limit windows are 2-5s
        val delayMs = RETRY_DELAY_MS * (1L shl retryAttempt)
        
        retryJob?.cancel()
        retryJob = scope.launch {
            delay(delayMs)
            
            // Seek to current position to force URL re-resolution
            val currentPosition = player.currentPosition
            val currentIndex = player.currentMediaItemIndex
            player.seekTo(currentIndex, currentPosition)
            player.prepare()
            
            Timber.tag(TAG).d("Retrying playback for $mediaId after 403 error (attempt $retryAttempt, delay ${delayMs}ms)")
        }
    }
    
    /**
     * Handles generic IO errors with recovery attempt.
     */
    private fun handleGenericIOError(mediaId: String?) {
        if (mediaId == null) {
            handleFinalFailure()
            return
        }

        // Invalidate any cached PO tokens — very often the cause of IO_UNSPECIFIED
        // and IO_BAD_HTTP_STATUS when using WEB_REMIX / clients that require attestation.
        poTokenProvider.invalidatePoTokens(mediaId)
        
        incrementRetryCount(mediaId)
        val retryAttempt = currentMediaIdRetryCount[mediaId] ?: 1
        
        // Exponential backoff: 2s, 4s, 8s — YouTube rate-limit windows are 2-5s
        val delayMs = RETRY_DELAY_MS * (1L shl retryAttempt)
        
        retryJob?.cancel()
        retryJob = scope.launch {
            performAggressiveCacheClear(mediaId)
            delay(delayMs)

            val currentPosition = player.currentPosition
            val currentIndex = player.currentMediaItemIndex
            player.seekTo(currentIndex, currentPosition)
            player.prepare()
            
            Timber.tag(TAG).d("Retrying playback for $mediaId after generic IO error (attempt $retryAttempt, delay ${delayMs}ms)")
        }
    }

    /**
     * Handles final failure when all recovery attempts have been exhausted.
     */
    private fun handleFinalFailure() {
        if (dataStore.get(AutoSkipNextOnErrorKey, true)) {
            Timber.tag(TAG).d("All recovery attempts exhausted, auto-skipping to next track")
            skipOnError()
        } else {
            Timber.tag(TAG).d("All recovery attempts exhausted, stopping playback")
            stopOnError()
        }
    }

    override fun onDeviceVolumeChanged(volume: Int, muted: Boolean) {
        super.onDeviceVolumeChanged(volume, muted)
        val pauseOnMute = dataStore.get(PauseOnMute, false)

        if ((volume == 0 || muted) && pauseOnMute) {
            if (player.isPlaying) {
                wasPlayingBeforeVolumeMute = true
                isPausedByVolumeMute = true
                player.pause()
            }
        } else if (volume > 0 && !muted && pauseOnMute) {
            if (wasPlayingBeforeVolumeMute && !player.isPlaying && castConnectionHandler?.isCasting?.value != true) {
                wasPlayingBeforeVolumeMute = false
                isPausedByVolumeMute = false
                player.play()
            }
        }
    }

    private fun createCacheDataSource(): CacheDataSource.Factory {
        // On TV (Leanback) we behave like Spotify TV – never write to the
        // player cache. Combined with the bounded provider in AppModule this
        // gives a true streaming-only experience with zero disk accumulation
        // beyond the small in-flight buffer required for ExoPlayer chunking.
        val isTv = packageManager.hasSystemFeature(
            android.content.pm.PackageManager.FEATURE_LEANBACK
        )
        val playerCacheBuilder = CacheDataSource
            .Factory()
            .setCache(playerCache)
            .setUpstreamDataSourceFactory(
                DefaultDataSource.Factory(
                    this,
                    OkHttpDataSource.Factory(
                        OkHttpClient
                            .Builder()
                            .proxy(YouTube.proxy)
                            .proxyAuthenticator { _, response ->
                                YouTube.proxyAuth?.let { auth ->
                                    response.request.newBuilder()
                                        .header("Proxy-Authorization", auth)
                                        .build()
                                } ?: response.request
                            }
                            .build(),
                    ),
                ),
            )
        if (isTv) {
            playerCacheBuilder.setCacheWriteDataSinkFactory(null)
        }
        return CacheDataSource
            .Factory()
            .setCache(downloadCache)
            .setUpstreamDataSourceFactory(playerCacheBuilder)
            .setCacheWriteDataSinkFactory(null)
            .setFlags(FLAG_IGNORE_CACHE_ON_ERROR)
    }

    // Flag to prevent queue saving during silence skip operations
    private var isSilenceSkipping = false

    private fun handleLongSilenceDetected() {
        if (!instantSilenceSkipEnabled.value) return
        if (silenceSkipJob?.isActive == true) return

        silenceSkipJob = scope.launch {
            // Debounce so short fades or transitions do not trigger a jump.
            delay(200)
            performInstantSilenceSkip()
        }
    }

    private suspend fun performInstantSilenceSkip() {
        val duration = player.duration.takeIf { it != C.TIME_UNSET && it > 0 } ?: return
        if (duration <= INSTANT_SILENCE_SKIP_STEP_MS) return

        isSilenceSkipping = true
        try {
            var hops = 0
            val silenceProcessor = playerSilenceProcessors[player] ?: return
            while (coroutineContext.isActive && instantSilenceSkipEnabled.value && silenceProcessor.isCurrentlySilent()) {
                val current = player.currentPosition
                val target = (current + INSTANT_SILENCE_SKIP_STEP_MS).coerceAtMost(duration - 500)

                if (target <= current) break

                // Reset silence tracking before seeking to prevent immediate re-trigger
                silenceProcessor.resetTracking()
                try {
                    // seekTo can throw if the timeline changed concurrently (video-mode
                    // source replacement or auto-advance). Swallow it so a race on the
                    // next song's start never kills the app.
                    player.seekTo(target)
                } catch (e: Exception) {
                    Timber.e(e, "performInstantSilenceSkip: seekTo failed")
                    break
                }
                hops++

                if (hops >= 80 || target >= duration - 500) break

                delay(INSTANT_SILENCE_SKIP_SETTLE_MS)
            }
            if (hops > 0) {
                Timber.tag(TAG).d("Silence skip: jumped $hops times")
            }
        } finally {
            isSilenceSkipping = false
        }
    }

    private fun createDataSourceFactory(): DataSource.Factory {
        return ResolvingDataSource.Factory(createCacheDataSource()) { dataSpec ->
            val mediaId = (dataSpec.key ?: error("No media id")).removeSuffix("_video")

            val requestedChunkLength = if (dataSpec.length == C.LENGTH_UNSET.toLong()) {
                CHUNK_LENGTH
            } else {
                minOf(CHUNK_LENGTH, dataSpec.length)
            }

            // If the URI is already a resolved HTTP/HTTPS or local loopback URL, pass through
            val uri = dataSpec.uri.toString()
            if (uri.startsWith("https://") && (uri.contains("googlevideo.com") || uri.contains("youtube.com/videoplayback"))) {
                return@Factory dataSpec.subrange(0, requestedChunkLength)
            }
            if (uri.startsWith("https://") || uri.startsWith("http://") || uri.startsWith("file://")) {
                return@Factory dataSpec
            }

            if (downloadCache.isCached(
                    mediaId,
                    dataSpec.position,
                    requestedChunkLength
                ) ||
                playerCache.isCached(mediaId, dataSpec.position, requestedChunkLength)
            ) {
                scope.launch(Dispatchers.IO) { recoverSong(mediaId) }
                // Must bound length to the verified cached chunk so CacheDataSource does not
                // read past the cached region into OkHttpDataSource with an unresolved mediaId URI.
                return@Factory dataSpec.subrange(0, requestedChunkLength)
            }

            songUrlCache[mediaId]?.takeIf { it.expiresAtMs > System.currentTimeMillis() }?.let { entry ->
                scope.launch(Dispatchers.IO) { recoverSong(mediaId) }
                val cachedUri = entry.url.toUri()
                if (cachedUri.host == "127.0.0.1" || cachedUri.host == "localhost" || cachedUri.scheme == "file") {
                    return@Factory dataSpec
                        .withUri(cachedUri)
                        .withRequestHeaders(entry.headers)
                }
                return@Factory dataSpec
                    .withUri(cachedUri)
                    .withRequestHeaders(entry.headers)
                    .subrange(0, requestedChunkLength)
            }

            val playbackData = runBlocking(Dispatchers.IO) {
                YTPlayerUtils.playerResponseForPlayback(
                    mediaId,
                    audioQuality = audioQuality,
                    connectivityManager = connectivityManager,
                    poTokenProvider = poTokenProvider,
                )
            }.getOrElse { throwable ->
                when (throwable) {
                    is PlaybackException -> throw throwable

                    is java.net.ConnectException, is java.net.UnknownHostException -> {
                        throw PlaybackException(
                            getString(R.string.error_no_internet),
                            throwable,
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
                        )
                    }

                    is java.net.SocketTimeoutException -> {
                        throw PlaybackException(
                            getString(R.string.error_timeout),
                            throwable,
                            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
                        )
                    }

                    else -> throw PlaybackException(
                        getString(R.string.error_unknown),
                        throwable,
                        PlaybackException.ERROR_CODE_REMOTE_ERROR
                    )
                }
            }

            val nonNullPlayback = requireNotNull(playbackData) {
                getString(R.string.error_unknown)
            }
            val streamUrl = nonNullPlayback.streamUrl
            val streamUri = streamUrl.toUri()
            val urlExpiresAt = streamUri.getQueryParameter("expire")
                ?.toLongOrNull()
                ?.times(1000L)
            val responseExpiresAt = System.currentTimeMillis() + (nonNullPlayback.streamExpiresInSeconds * 1000L)
            val expiresAt = minOf(urlExpiresAt ?: Long.MAX_VALUE, responseExpiresAt) - 5 * 60_000L
            songUrlCache[mediaId] = StreamUrlEntry(
                url = streamUrl,
                expiresAtMs = expiresAt,
                headers = nonNullPlayback.streamHeaders,
            )

            scope.launch(Dispatchers.IO) {
                val format = nonNullPlayback.format
                val loudnessDb = nonNullPlayback.audioConfig?.loudnessDb
                val perceptualLoudnessDb = nonNullPlayback.audioConfig?.perceptualLoudnessDb

                Timber.tag(TAG).d("Storing format for $mediaId with loudnessDb: $loudnessDb, perceptualLoudnessDb: $perceptualLoudnessDb")
                if (loudnessDb == null && perceptualLoudnessDb == null) {
                    Timber.tag(TAG).w("No loudness data available from YouTube for video: $mediaId")
                }

                database.query {
                    upsert(
                        FormatEntity(
                            id = mediaId,
                            itag = format.itag,
                            mimeType = format.mimeType.substringBefore(";"),
                            codecs = format.mimeType.substringAfter("codecs=", "").removeSurrounding("\""),
                            bitrate = format.bitrate,
                            sampleRate = format.audioSampleRate,
                            contentLength = format.contentLength ?: 0L,
                            loudnessDb = loudnessDb,
                            perceptualLoudnessDb = perceptualLoudnessDb,
                            playbackUrl = nonNullPlayback.playbackTracking?.videostatsPlaybackUrl?.baseUrl
                        )
                    )
                }
                recoverSong(mediaId, nonNullPlayback)
            }

            if (streamUri.host == "127.0.0.1" || streamUri.host == "localhost" || streamUri.scheme == "file") {
                return@Factory dataSpec
                    .withUri(streamUri)
                    .withRequestHeaders(nonNullPlayback.streamHeaders)
            }

            // DataSpec.subrange(offset, length) adds `offset` to `dataSpec.position`.
            // Pass offset = 0 so the starting position is preserved and only length is capped.
            return@Factory dataSpec
                .withUri(streamUri)
                .withRequestHeaders(nonNullPlayback.streamHeaders)
                .subrange(0, requestedChunkLength)
        }
    }

    private fun createMediaSourceFactory() =
        DefaultMediaSourceFactory(
            createDataSourceFactory(),
            ExtractorsFactory {
                arrayOf(MatroskaExtractor(), FragmentedMp4Extractor(), Mp4Extractor(), Mp3Extractor())
            },
        )

    private fun createRenderersFactory(
        eqProcessor: CustomEqualizerAudioProcessor,
        vocalSuppressionProcessor: VocalSuppressionAudioProcessor,
        dynamicRangeCompressionProcessor: DynamicRangeCompressionAudioProcessor,
        silenceProcessor: SilenceDetectorAudioProcessor,
        reverbProcessor: ReverbAudioProcessor,
    ) =
        object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean,
            ) = DefaultAudioSink
                .Builder(this@MusicService)
                .setAudioCapabilities(AudioCapabilities.getCapabilities(context))
                .setEnableFloatOutput(false)
                .setEnableAudioTrackPlaybackParams(false)
                .setAudioProcessorChain(
                    StudioAudioProcessorChain(
                        eqProcessor,
                        vocalSuppressionProcessor,
                        dynamicRangeCompressionProcessor,
                        silenceProcessor,
                        reverbProcessor = reverbProcessor,
                    ),
                ).build()

            /**
             * Override to disable Media3's [LoudnessCodecController] integration
             * (Android 15+). Passing `null` to the 8-arg [MediaCodecAudioRenderer]
             * constructor avoids the "Loudness controller does not contain
             * android.media.MediaCodec@..." FAILED RUNTIME CHECK (1004) crash that
             * happens during fast seeks / track switches on some devices.
             *
             * Extension renderers (Opus / FLAC / FFmpeg) are intentionally not
             * re-added because AuraMusic uses the default
             * `EXTENSION_RENDERER_MODE_OFF`, so the super implementation would
             * not have added any either.
             */
            override fun buildAudioRenderers(
                context: Context,
                extensionRendererMode: Int,
                mediaCodecSelector: MediaCodecSelector,
                enableDecoderFallback: Boolean,
                audioSink: AudioSink,
                eventHandler: android.os.Handler,
                eventListener: AudioRendererEventListener,
                out: ArrayList<Renderer>,
            ) {
                out.add(
                    MediaCodecAudioRenderer(
                        context,
                        codecAdapterFactory,
                        mediaCodecSelector,
                        enableDecoderFallback,
                        eventHandler,
                        eventListener,
                        audioSink,
                        /* loudnessCodecController = */ null,
                    )
                )
            }
        }

    override fun onPlaybackStatsReady(
        eventTime: AnalyticsListener.EventTime,
        playbackStats: PlaybackStats,
    ) {
        val mediaItem = eventTime.timeline.getWindow(eventTime.windowIndex, Timeline.Window()).mediaItem
        val historyDurationMs = dataStore[HistoryDuration]?.times(1000f) ?: 30000f

        if (playbackStats.totalPlayTimeMs >= historyDurationMs &&
            !dataStore.get(PauseListenHistoryKey, false)
        ) {
            val meta = mediaItem.metadata
            com.sanmusic.app.streak.MusicJourneyManager.onSongPlayed(
                context = applicationContext,
                songId = mediaItem.mediaId,
                title = meta?.title ?: mediaItem.mediaMetadata.title?.toString().orEmpty(),
                artist = meta?.artists?.joinToString(", ") { it.name }
                    ?: mediaItem.mediaMetadata.artist?.toString().orEmpty(),
                thumbnailUrl = meta?.thumbnailUrl ?: mediaItem.mediaMetadata.artworkUri?.toString(),
                listenedMs = playbackStats.totalPlayTimeMs,
            )
            database.query {
                incrementTotalPlayTime(mediaItem.mediaId, playbackStats.totalPlayTimeMs)
                try {
                    insert(
                        Event(
                            songId = mediaItem.mediaId,
                            timestamp = LocalDateTime.now(),
                            playTime = playbackStats.totalPlayTimeMs,
                        ),
                    )
                } catch (_: SQLException) {
                }
            }
        }

        if (playbackStats.totalPlayTimeMs >= historyDurationMs) {
            CoroutineScope(Dispatchers.IO).launch {
                val playbackUrl = database.format(mediaItem.mediaId).first()?.playbackUrl
                    ?: YTPlayerUtils.playerResponseForMetadata(mediaItem.mediaId, null)
                        .getOrNull()?.playbackTracking?.videostatsPlaybackUrl?.baseUrl
                playbackUrl?.let {
                    YouTube.registerPlayback(null, playbackUrl)
                        .onFailure {
                            reportException(it)
                        }
                }
            }
        }
    }

    private fun saveQueueToDisk() {
        if (player.mediaItemCount == 0) {
            Timber.tag(TAG).d("Skipping queue save - no media items")
            return
        }

        try {
            // Save current queue with proper type information
            val persistQueue = currentQueue.toPersistQueue(
                title = queueTitle,
                items = player.mediaItems.mapNotNull { it.metadata },
                mediaItemIndex = player.currentMediaItemIndex,
                position = player.currentPosition
            )

            val persistAutomix =
                PersistQueue(
                    title = "automix",
                    items = automixItems.value.mapNotNull { it.metadata },
                    mediaItemIndex = 0,
                    position = 0,
                )

            // Save player state
            val persistPlayerState = PersistPlayerState(
                playWhenReady = player.playWhenReady,
                repeatMode = player.repeatMode,
                shuffleModeEnabled = player.shuffleModeEnabled,
                volume = playerVolume.value,
                currentPosition = player.currentPosition,
                currentMediaItemIndex = player.currentMediaItemIndex,
                playbackState = player.playbackState
            )

            runCatching {
                filesDir.resolve(PERSISTENT_QUEUE_FILE).outputStream().use { fos ->
                    ObjectOutputStream(fos).use { oos ->
                        oos.writeObject(persistQueue)
                    }
                }
                Timber.tag(TAG).d("Queue saved successfully")
            }.onFailure {
                Timber.tag(TAG).e(it, "Failed to save queue")
                reportException(it)
            }

            runCatching {
            filesDir.resolve(PERSISTENT_AUTOMIX_FILE).outputStream().use { fos ->
                ObjectOutputStream(fos).use { oos ->
                        oos.writeObject(persistAutomix)
                    }
                }
                Timber.tag(TAG).d("Automix saved successfully")
            }.onFailure {
                Timber.tag(TAG).e(it, "Failed to save automix")
                reportException(it)
            }

            runCatching {
                filesDir.resolve(PERSISTENT_PLAYER_STATE_FILE).outputStream().use { fos ->
                    ObjectOutputStream(fos).use { oos ->
                        oos.writeObject(persistPlayerState)
                    }
                }
                Timber.tag(TAG).d("Player state saved successfully")
            }.onFailure {
                Timber.tag(TAG).e(it, "Failed to save player state")
                reportException(it)
            }
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Error during queue save operation")
            reportException(e)
        }
    }

    override fun onDestroy() {
        isRunning = false

        try {
            unregisterReceiver(screenStateReceiver)
        } catch (e: Exception) {
            // Ignore
        }
        dynamicIslandSystemOverlayManager?.release()
        dynamicIslandSystemOverlayManager = null
        castConnectionHandler?.release()
        if (dataStore.get(PersistentQueueKey, true)) {
            saveQueueToDisk()
        }
        if (DiscordRpcManager.isReady()) {
            DiscordRpcManager.disconnect()
        }
        DiscordRpcManager.destroy()
        connectivityObserver.unregister()
        abandonAudioFocus()
        releaseLoudnessEnhancer()
        playerInitialized.value = false
        _playerFlow.value = null
        crossfadeTriggerJob?.cancel()
        crossfadeJob?.cancel()
        retryJob?.cancel()
        videoSwitchJob?.cancel()
        widgetUpdateJob?.cancel()
        discordUpdateJob?.cancel()
        scope.cancel()
        mediaSession.release()
        listOfNotNull(secondaryPlayer, fadingPlayer, player).distinct().forEach { playerToRelease ->
            playerToRelease.removeListener(this)
            playerToRelease.removeListener(sleepTimer)
            playerSilenceProcessors.remove(playerToRelease)
            playerToRelease.stop()
            playerToRelease.release()
        }
        releaseExternalStemPlayers()
        secondaryPlayer = null
        fadingPlayer = null
        isCrossfading = false
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = super.onBind(intent) ?: binder

    override fun onTaskRemoved(rootIntent: Intent?) {
        com.sanmusic.app.ui.component.DynamicIslandOverlayState.resetOnAppExit(this)
        if (!player.playWhenReady || !player.isPlaying) {
            player.pause()
            if (isVideoMode) {
                player.stop()
            }
        }
        super.onTaskRemoved(rootIntent)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = mediaSession

    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        try {
            super.onUpdateNotification(session, startInForegroundRequired)
        } catch (e: ForegroundServiceStartNotAllowedException) {
            handleForegroundServiceStartNotAllowed(e)
        } catch (e: IllegalStateException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                e.javaClass.name == ForegroundServiceStartNotAllowedException::class.java.name
            ) {
                handleForegroundServiceStartNotAllowed(e)
            } else {
                throw e
            }
        } catch (e: SecurityException) {
            Timber.tag(TAG).w(e, "onUpdateNotification: suppressed SecurityException from FGS path")
        }
    }

    private fun handleForegroundServiceStartNotAllowed(error: Throwable?) {
        Timber.tag(TAG).w(error, "Foreground service start denied during notification update")
        promoteToForegroundWithLatestNotification()
    }

    private fun promoteToForegroundWithLatestNotification() {
        val notification = latestMediaNotification ?: foregroundNotification
        startForegroundSafely(notification)
    }

    private fun startForegroundSafely(notification: Notification): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK,
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
            true
        } catch (e: ForegroundServiceStartNotAllowedException) {
            Timber.tag(TAG).w(e, "startForeground: FGS start not allowed")
            false
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "startForeground: failed")
            false
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        promoteToForegroundWithLatestNotification()

        when (intent?.action) {
            ACTION_PLAY_ALARM -> {
                handleAlarmPlay()
            }
            MusicWidgetReceiver.ACTION_PLAY_PAUSE -> {
                if (player.isPlaying) player.pause() else player.play()
                updateWidgetUI(player.isPlaying)
            }
            MusicWidgetReceiver.ACTION_LIKE -> {
                toggleLike()
            }
            MusicWidgetReceiver.ACTION_NEXT -> {
                player.seekToNext()
                updateWidgetUI(player.isPlaying)
            }
            MusicWidgetReceiver.ACTION_PREVIOUS -> {
                player.seekToPrevious()
                updateWidgetUI(player.isPlaying)
            }
            MusicWidgetReceiver.ACTION_UPDATE_WIDGET -> {
                updateWidgetUI(player.isPlaying)
            }
            // Compact Square Widget
            CompactSquareWidgetReceiver.ACTION_COMPACT_SQUARE_UPDATE -> {
                updateWidgetUI(player.isPlaying)
            }
            CompactSquareWidgetReceiver.ACTION_COMPACT_SQUARE_PLAY_PAUSE -> {
                if (player.isPlaying) player.pause() else player.play()
                updateWidgetUI(player.isPlaying)
            }
            CompactSquareWidgetReceiver.ACTION_COMPACT_SQUARE_PREVIOUS -> {
                player.seekToPrevious()
                updateWidgetUI(player.isPlaying)
            }
            CompactSquareWidgetReceiver.ACTION_COMPACT_SQUARE_NEXT -> {
                player.seekToNext()
                updateWidgetUI(player.isPlaying)
            }
            // Compact Wide Widget
            CompactWideWidgetReceiver.ACTION_COMPACT_WIDE_UPDATE -> {
                updateWidgetUI(player.isPlaying)
            }
            CompactWideWidgetReceiver.ACTION_COMPACT_WIDE_PLAY_PAUSE -> {
                if (player.isPlaying) player.pause() else player.play()
                updateWidgetUI(player.isPlaying)
            }
            CompactWideWidgetReceiver.ACTION_COMPACT_WIDE_LIKE -> {
                toggleLike()
            }
            // Liquid Glass Widgets
            LiquidGlassWidgetReceiver.ACTION_LIQUID_GLASS_UPDATE,
            LiquidGlassWideWidgetReceiver.ACTION_LIQUID_GLASS_WIDE_UPDATE -> {
                updateWidgetUI(player.isPlaying)
            }
            }

        return super.onStartCommand(intent, flags, startId)
    }

    /**
     * Updates all app widgets with current playback state.
     *
     * Serialized through [widgetUpdateMutex] so concurrent invocations (the
     * periodic 200ms loop, song changes and widget button actions) never run
     * `updateWidgets` in parallel. Without this, out-of-order album-art loads
     * could leave the widget showing a previous song's title/artwork.
     */
    private fun updateWidgetUI(isPlaying: Boolean) {
        scope.launch {
            widgetUpdateMutex.withLock {
                try {
                    val songData = currentSong.value
                    val song = songData?.song
                    val songTitle = song?.title ?: getString(R.string.no_song_playing)
                    val artistName = songData?.artists?.joinToString(", ") { it.name } ?: getString(R.string.tap_to_open)
                    val isLiked = songData?.song?.liked == true

                    widgetManager.updateWidgets(
                        title = songTitle,
                        artist = artistName,
                        artworkUri = song?.thumbnailUrl,
                        isPlaying = isPlaying,
                        isLiked = isLiked,
                        duration = if (player.duration != C.TIME_UNSET) player.duration else 0,
                        currentPosition = player.currentPosition
                    )
                } catch (e: Exception) {
                    // Widget not added to home screen or other error
                }
            }
        }
    }

    private val widgetUpdateMutex = Mutex()

    private var widgetUpdateJob: Job? = null

    private fun startWidgetUpdates() {
        widgetUpdateJob?.cancel()
        widgetUpdateJob = scope.launch {
            while (isActive) {
                if (player.isPlaying) {
                    updateWidgetUI(true)
                }
                delay(200)
            }
        }
    }

    private fun stopWidgetUpdates() {
        widgetUpdateJob?.cancel()
        widgetUpdateJob = null
    }

    private fun shareSong() {
        val songData = currentSong.value
        val songId = songData?.song?.id ?: return
        
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "https://music.youtube.com/watch?v=$songId")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(Intent.createChooser(shareIntent, null).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    /**
     * Get the stream URL for a given media ID.
     * This is used for Google Cast to send the audio URL to Chromecast.
     */
    suspend fun getStreamUrl(mediaId: String): String? {
        return withContext(Dispatchers.IO) {
            try {
                val playbackData = YTPlayerUtils.playerResponseForPlayback(
                    videoId = mediaId,
                    audioQuality = audioQuality,
                    connectivityManager = connectivityManager,
                    poTokenProvider = poTokenProvider,
                ).getOrNull()
                playbackData?.streamUrl
            } catch (e: Exception) {
                timber.log.Timber.e(e, "Failed to get stream URL for Cast")
                null
            }
        }
    }

    private var isVideoMode = false
    private var currentVideoUrl: String? = null
    private var currentVideoSourceMediaId: String? = null
    private var originalAudioMediaItem: MediaItem? = null
    private var videoSwitchJob: Job? = null
    private var isInjectingVideoSource = false
    val isInjectingVideoSourcePublic: Boolean get() = isInjectingVideoSource
    // TV builds hold playback until the video's first frame is rendered so the
    // next song's audio never starts before its video is visible. Cleared by the
    // first-frame callback, its 8s safety timeout, or resetVideoMode().
    private var videoFirstFrameListener: AnalyticsListener? = null

    private val isTvDevice: Boolean by lazy {
        packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
    }
    // Tracks the last mediaId reported by onMediaItemTransition. Used to detect a
    // REAL song change: replacing the current item with its video version (or the
    // merged source swap) fires a transition with the SAME mediaId, which must not
    // be treated as a new song (that caused an infinite video re-fetch loop).
    private var lastTransitionMediaId: String? = null
    private val _videoModeEnabled = MutableStateFlow(false)
    val videoModeEnabled: StateFlow<Boolean> = _videoModeEnabled.asStateFlow()
    private val _isVideoSwitching = MutableStateFlow(false)
    val isVideoSwitching: StateFlow<Boolean> = _isVideoSwitching.asStateFlow()
    private val _videoFetchError = MutableStateFlow<String?>(null)
    val videoFetchError: StateFlow<String?> = _videoFetchError.asStateFlow()
    private val _videoModeMessage = MutableStateFlow<String?>(null)
    val videoModeMessage: StateFlow<String?> = _videoModeMessage.asStateFlow()
    private val _isVideoAvailable = MutableStateFlow(false)
    val isVideoAvailable: StateFlow<Boolean> = _isVideoAvailable.asStateFlow()
    private val _currentVideoId = MutableStateFlow<String?>(null)
    val currentVideoId: StateFlow<String?> = _currentVideoId.asStateFlow()
    // Cache for resolved video search results to avoid re-fetching
    private val videoSearchCache = java.util.concurrent.ConcurrentHashMap<String, com.sanmusic.auravideo.SanMusicVideo.VideoSearchResult>()
    // Cache for video captions to avoid re-fetching on player collapse/expand
    val captionCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    val captionAttemptedIds = java.util.Collections.synchronizedSet(mutableSetOf<String>())
    private val _availableSubtitles = MutableStateFlow<List<com.sanmusic.app.subtitles.SubtitleInfo>>(emptyList())
    val availableSubtitles: StateFlow<List<com.sanmusic.app.subtitles.SubtitleInfo>> = _availableSubtitles.asStateFlow()
    private val _selectedSubtitleIndex = MutableStateFlow(-1)
    val selectedSubtitleIndex: StateFlow<Int> = _selectedSubtitleIndex.asStateFlow()

    private val _currentPositionFlow = MutableStateFlow(0L)
    val currentPositionFlow: StateFlow<Long> = _currentPositionFlow.asStateFlow()


    private fun currentPlaybackDurationMs(): Long = if (player.duration > 0) player.duration else 0L

    private fun currentSponsorBlockVideoId(): String? {
        if (_isVideoSwitching.value) return null
        currentVideoId.value?.let { return it }
        if (isVideoMode) return null
        return player.currentMediaItem?.mediaId
    }



    fun selectSubtitle(index: Int) {
        _selectedSubtitleIndex.value = index
    }

    private fun resetVideoMode() {
        videoSwitchJob?.cancel()
        videoFirstFrameListener?.let { matchingListener ->
            runCatching { player.removeAnalyticsListener(matchingListener) }
        }
        videoFirstFrameListener = null
        _videoModeEnabled.value = false
        _isVideoSwitching.value = false
        isVideoMode = false
        currentVideoUrl = null
        currentVideoSourceMediaId = null
        _currentVideoId.value = null
        originalAudioMediaItem = null
        _videoFetchError.value = null
        _videoModeMessage.value = null
        _availableSubtitles.value = emptyList()
        _selectedSubtitleIndex.value = -1
    }

    /**
     * On TV builds, once a video source has been injected and prepared, we wait
     * for its first frame to be rendered before resuming playback. This prevents
     * the "audio plays / black video" gap when starting the next video song.
     */
    private suspend fun waitForFirstVideoFrameThenResume(wasPlaying: Boolean) {
        val firstFrame = CompletableDeferred<Unit>()
        val listener = object : AnalyticsListener {
            override fun onRenderedFirstFrame(
                eventTime: AnalyticsListener.EventTime,
                surface: Any,
                renderTimeMs: Long,
            ) {
                if (!firstFrame.isCompleted) {
                    firstFrame.complete(Unit)
                }
            }
        }
        videoFirstFrameListener = listener
        runCatching { player.addAnalyticsListener(listener) }
        try {
            withTimeout(10_000L) {
                firstFrame.await()
            }
            Timber.d("waitForFirstVideoFrameThenResume: video first frame rendered, resuming playback")
        } catch (e: TimeoutCancellationException) {
            Timber.w("waitForFirstVideoFrameThenResume: timed out waiting for first frame")
        } finally {
            runCatching { player.removeAnalyticsListener(listener) }
            if (videoFirstFrameListener === listener) {
                videoFirstFrameListener = null
            }
        }
        player.playWhenReady = wasPlaying
    }

    /**
     * If TV video mode paused playback (pause-until-first-frame behaviour) and it
     * turns out no video can be shown, resume the audio so the user isn't stuck silent.
     */
    private fun restoreTvPlaybackIfPaused(wasPlaying: Boolean) {
        if (isTvDevice && wasPlaying && !player.playWhenReady) {
            player.playWhenReady = true
            Timber.d("restoreTvPlaybackIfPaused: Video failed, resuming audio playback")
        }
    }

    /**
     * Safely switch to audio mode, restoring original audio stream
     */
    private suspend fun switchToAudioMode() {
        if (!isVideoMode) return

        try {
            val index = player.currentMediaItemIndex
            val position = player.currentPosition
            val wasPlaying = player.playWhenReady

            val original = originalAudioMediaItem
            if (original != null) {
                player.replaceMediaItem(index, original)
                player.prepare()
                if (position > 0) {
                    player.seekTo(index, position)
                }
                player.playWhenReady = wasPlaying
                Timber.d("switchToAudioMode: Successfully switched back to audio")
            } else {
                Timber.w("switchToAudioMode: No original audio item to restore")
            }
        } catch (e: Exception) {
            Timber.e(e, "switchToAudioMode: Failed to switch to audio")
        } finally {
            resetVideoMode()
        }
    }

    /**
     * Enable or disable video mode for current playback
     */
    fun setVideoMode(enabled: Boolean) {
        Timber.d("setVideoMode: Called with enabled = $enabled, current isVideoMode = $isVideoMode")
        android.util.Log.d("MusicService", ">>> setVideoMode called: enabled=$enabled, current isVideoMode=$isVideoMode")

        val mediaId = currentMediaMetadata.value?.id
            ?: player.currentMediaItem?.mediaId
            ?: run {
            Timber.d("setVideoMode: No current media, skipping")
            android.util.Log.d("MusicService", ">>> No current media, skipping")
            return
        }

        if (enabled == isVideoMode && (!enabled || currentVideoSourceMediaId == mediaId)) {
            Timber.d("setVideoMode: Already in requested mode for current media, skipping")
            android.util.Log.d("MusicService", ">>> Already in requested mode for current media, skipping")
            return
        }

        Timber.d("setVideoMode: Current mediaId: $mediaId")
        android.util.Log.d("MusicService", ">>> Current mediaId: $mediaId")

        videoSwitchJob?.cancel()
        _isVideoSwitching.value = true

        videoSwitchJob = scope.launch {
            try {
                val index = player.currentMediaItemIndex
                val position = player.currentPosition
                val wasPlaying = player.playWhenReady

                if (enabled) {
                    // Don't pause audio — let it keep playing while we load video
                    // This prevents the audio stutter/gap during video mode switch
                    // (EXCEPT on TV: there we pause immediately so the audio-only item
                    // never plays while the video is still being fetched.)
                    if (isTvDevice && wasPlaying) {
                        player.playWhenReady = false
                        _isVideoSwitching.value = true
                    }
                    
                    // Save original item before switching
                    originalAudioMediaItem = player.getMediaItemAt(index)

                    // Get song info for video search fallback
                    val metadata = currentMediaMetadata.value
                        ?: player.currentMediaItem?.metadata
                    val songTitle = metadata?.title ?: ""
                    val artistName = metadata?.artists?.firstOrNull()?.name ?: ""
                    val isVideoSong = metadata?.isVideoSong == true
                    
                    Timber.d("setVideoMode: Trying video for '$songTitle' by '$artistName', isVideoSong=$isVideoSong")
                    android.util.Log.d("MusicService", ">>> Searching video for: $songTitle - $artistName, isVideoSong=$isVideoSong")
                    
                    // For video songs: try direct lookup first (they have real video content)
                    // For regular songs: skip direct lookup and search for official music video
                    // Check cache first for faster video loading
                    val cachedSearchResult = videoSearchCache[mediaId]
                    val searchResult = if (cachedSearchResult != null) {
                        Timber.d("setVideoMode: Using cached video search result for $mediaId")
                        Result.success(cachedSearchResult)
                    } else {
                        // Bounded: if the video lookup hangs (slow network, bot
                        // check, extractor stall) we must fall back to audio
                        // instead of leaving the TV paused on a black surface.
                        val timeoutResult = withContext(Dispatchers.IO) {
                            kotlinx.coroutines.withTimeoutOrNull(VIDEO_SEARCH_TIMEOUT_MS) {
                                SanMusicPlayerUtils.getVideoStreamUrlWithFallback(songTitle, artistName, mediaId, isVideoSong)
                            }
                        }
                        timeoutResult ?: run {
                            Timber.w("setVideoMode: Video resolution timed out for $mediaId after ${VIDEO_SEARCH_TIMEOUT_MS}ms")
                            Result.failure(Exception("Video resolution timed out"))
                        }
                    }

                    if (searchResult.isSuccess) {
                        val videoData = searchResult.getOrNull()
                        // Cache the search result for future use
                        if (videoData != null && cachedSearchResult == null) {
                            videoSearchCache[mediaId] = videoData
                        }
                        Timber.d("setVideoMode: Fallback search result: ${videoData?.videoId}")
                        android.util.Log.d("MusicService", ">>> Found video via search: ${videoData?.videoId}")
                        
                        if (videoData != null) {
                            var videoId = videoData.videoId
                            val ccEnabled = dataStore.get(com.sanmusic.app.constants.SubtitlesEnabledKey, true)
                            
                            // Run stream URL fetch and caption fetching in PARALLEL
                            val subtitleConfigs = mutableListOf<MediaItem.SubtitleConfiguration>()
                            val subtitleInfos = mutableListOf<SubtitleInfo>()
                            val subtitleVideoId = videoId
                            
                            // Launch subtitle fetching in parallel with stream URL
                            val subtitleJob = if (ccEnabled) {
                                scope.launch {
                                    try {
                                        val captionResult = withContext(Dispatchers.IO) {
                                            YouTube.getCaptionTracksWithDuration(subtitleVideoId).getOrNull()
                                        }
                                        val captionTracks = captionResult?.first
                                        val videoDurationMs = captionResult?.second
                                        if (!captionTracks.isNullOrEmpty()) {
                                            Timber.d("setVideoMode: Found ${captionTracks.size} caption tracks for videoId=$subtitleVideoId")
                                            for (track in captionTracks) {
                                                try {
                                                    val subtitleText = withContext(Dispatchers.IO) {
                                                        YouTube.fetchSubtitleFromCaptionTrack(track.baseUrl).getOrNull()
                                                    }
                                                    if (!subtitleText.isNullOrBlank()) {
                                                        val vttText = YouTube.convertTimedTextToVttWithDuration(subtitleText, videoDurationMs)
                                                        val tempFile = withContext(Dispatchers.IO) {
                                                            File(cacheDir, "subtitle_${track.vssId}.vtt").apply {
                                                                writeText(vttText)
                                                            }
                                                        }
                                                        val uri = android.net.Uri.fromFile(tempFile)
                                                        val subConfig = MediaItem.SubtitleConfiguration.Builder(uri)
                                                            .setMimeType(MimeTypes.TEXT_VTT)
                                                            .setLanguage(track.languageCode)
                                                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                                                            .build()
                                                        synchronized(subtitleConfigs) {
                                                            subtitleConfigs.add(subConfig)
                                                            subtitleInfos.add(SubtitleInfo(
                                                                url = track.baseUrl,
                                                                format = "vtt",
                                                                language = java.util.Locale(track.languageCode).displayLanguage,
                                                                languageCode = track.languageCode,
                                                                isAutoGenerated = track.kind == "asr",
                                                                cachedContent = vttText,
                                                                cachedFilePath = tempFile.absolutePath
                                                            ))
                                                        }
                                                    }
                                                } catch (e: Exception) {
                                                    Timber.e(e, "setVideoMode: Failed to fetch subtitle track")
                                                }
                                            }
                                        }
                                        _availableSubtitles.value = subtitleInfos.toList()
                                        if (subtitleInfos.isNotEmpty()) {
                                            val preferredLang = dataStore.get(com.sanmusic.app.constants.SubtitleLanguageKey, "en")
                                            val preferredIndex = subtitleInfos.indexOfFirst { it.languageCode == preferredLang }
                                            selectSubtitle(if (preferredIndex >= 0) preferredIndex else 0)
                                        }
                                    } catch (e: Exception) {
                                        Timber.e(e, "setVideoMode: Error fetching caption tracks")
                                    }
                                }
                            } else null
                            
                            // Get stream source (runs in parallel with subtitle fetching).
                            // The Merged variant is returned when the preferred quality
                            // exceeds 720p, since YouTube only ships separate video-only
                            // and audio-only streams above that resolution.
                            var sourceResult = withContext(Dispatchers.IO) {
                                SanMusicPlayerUtils.getVideoStreamSource(videoId)
                            }

                            if (sourceResult.isFailure && isVideoSong && videoId == mediaId) {
                                subtitleJob?.cancel()
                                val fallbackVideo = withContext(Dispatchers.IO) {
                                    SanMusicPlayerUtils.getVideoStreamUrlWithFallback(
                                        songTitle,
                                        artistName,
                                        mediaId,
                                        isVideoSong = false
                                    ).getOrNull()
                                }
                                if (fallbackVideo != null && fallbackVideo.videoId != videoId) {
                                    Timber.d("setVideoMode: Direct video failed, trying fallback videoId=${fallbackVideo.videoId}")
                                    videoId = fallbackVideo.videoId
                                    sourceResult = withContext(Dispatchers.IO) {
                                        SanMusicPlayerUtils.getVideoStreamSource(videoId)
                                    }
                                }
                            }

                            if (sourceResult.isSuccess) {
                                val streamSource = sourceResult.getOrNull()
                                val primaryVideoUrl = when (streamSource) {
                                    is com.sanmusic.auravideo.SanMusicVideo.VideoStreamSource.Single -> streamSource.url
                                    is com.sanmusic.auravideo.SanMusicVideo.VideoStreamSource.Merged -> streamSource.videoUrl
                                    null -> ""
                                }
                                val primaryMimeType = when (streamSource) {
                                    is com.sanmusic.auravideo.SanMusicVideo.VideoStreamSource.Single -> streamSource.mimeType
                                    is com.sanmusic.auravideo.SanMusicVideo.VideoStreamSource.Merged -> streamSource.videoMimeType
                                    null -> "video/mp4"
                                }
                                currentVideoUrl = primaryVideoUrl

                                Timber.d("setVideoMode: Video URL: $primaryVideoUrl, MIME type: $primaryMimeType, source=${streamSource?.javaClass?.simpleName}")
                                android.util.Log.d("MusicService", ">>> Got stream URL: $primaryVideoUrl, mimeType: $primaryMimeType, source=${streamSource?.javaClass?.simpleName}")

                                if (primaryVideoUrl.isBlank() || streamSource == null) {
                                    Timber.e("setVideoMode: Video URL is blank after parsing")
                                    _videoFetchError.value = "URL video kosong - Lagu ini mungkin tidak memiliki video"
                                    _videoModeMessage.value = "Tidak ada video yang tersedia untuk lagu ini"
                                    restoreTvPlaybackIfPaused(wasPlaying)
                                    resetVideoMode()
                                    return@launch
                                }

                                val currentItem = player.getMediaItemAt(index)
                                Timber.d("setVideoMode: Current media item URI: ${currentItem.localConfiguration?.uri}")

                                val readySubtitleConfigs = synchronized(subtitleConfigs) {
                                    subtitleConfigs.toList()
                                }

                                val videoMediaItemBuilder = currentItem.buildUpon()
                                    .setUri(primaryVideoUrl)
                                    .setMimeType(primaryMimeType)
                                    .setCustomCacheKey(mediaId + "_video")

                                if (ccEnabled && readySubtitleConfigs.isNotEmpty()) {
                                    videoMediaItemBuilder.setSubtitleConfigurations(readySubtitleConfigs)
                                    Timber.d("setVideoMode: Added ${readySubtitleConfigs.size} subtitle tracks to media item")
                                }

                                val videoMediaItem = videoMediaItemBuilder.build()

                                if (ccEnabled) {
                                    player.trackSelectionParameters = player.trackSelectionParameters
                                        .buildUpon()
                                        .setPreferredTextLanguage("en")
                                        .build()
                                } else {
                                    player.trackSelectionParameters = player.trackSelectionParameters
                                        .buildUpon()
                                        .setPreferredTextLanguage(null)
                                        .build()
                                }

                                // Pause before replacing so we don't briefly play from position 0
                                player.playWhenReady = false

                                when (streamSource) {
                                    is com.sanmusic.auravideo.SanMusicVideo.VideoStreamSource.Single -> {
                                        Timber.d("setVideoMode: Replacing media item at index $index (single source)")
                                        player.replaceMediaItem(index, videoMediaItem)
                                    }
                                    is com.sanmusic.auravideo.SanMusicVideo.VideoStreamSource.Merged -> {
                                        // Build a MergingMediaSource of (video-only + audio-only)
                                        // so we can actually expose 1080p+ — muxed YouTube
                                        // streams cap below that.
                                        val factory = ProgressiveMediaSource.Factory(
                                            createDataSourceFactory(),
                                            ExtractorsFactory {
                                                arrayOf(
                                                    MatroskaExtractor(),
                                                    FragmentedMp4Extractor(),
                                                    Mp4Extractor()
                                                )
                                            }
                                        )
                                        val videoSource = factory.createMediaSource(videoMediaItem)
                                        val audioMediaItem = MediaItem.Builder()
                                            .setUri(streamSource.audioUrl)
                                            .setMimeType(streamSource.audioMimeType)
                                            .setCustomCacheKey(mediaId + "_video_audio")
                                            .build()
                                        val audioSource = factory.createMediaSource(audioMediaItem)
                                        val merged = MergingMediaSource(true, true, videoSource, audioSource)

                                        Timber.d("setVideoMode: Injecting MergingMediaSource at index $index (${streamSource.height}p video + audio)")
                                        // Insert the merged source AFTER the current item, then remove the
                                        // current (audio) item. ExoPlayer advances onto the merged source —
                                        // same mediaId, so NO onMediaItemTransition fires and no re-entrant
                                        // video switch is triggered. Removing the current item FIRST makes
                                        // ExoPlayer auto-advance to the NEXT song, firing a real transition
                                        // that races this job and ends up playing the wrong song or crashing.
                                        val insertIndex = (index + 1).coerceAtMost(player.mediaItemCount)
                                        isInjectingVideoSource = true
                                        try {
                                            player.addMediaSource(insertIndex, merged)
                                            player.removeMediaItem(index)
                                        } finally {
                                            isInjectingVideoSource = false
                                        }
                                    }
                                }
                                player.prepare()
                                Timber.d("setVideoMode: Called prepare(), player state: ${player.playbackState}")

                                // Seek BEFORE restoring playWhenReady to avoid playing from 0
                                if (position > 0) {
                                    player.seekTo(index, position)
                                    Timber.d("setVideoMode: Seeked to position $position")
                                }
                                if (isTvDevice && wasPlaying) {
                                    // TV: hold playback silent until the first frame is actually
                                    // rendered, so we never hear the audio before the video shows.
                                    waitForFirstVideoFrameThenResume(wasPlaying)
                                } else {
                                    player.playWhenReady = wasPlaying
                                }
                                isVideoMode = true
                                _videoModeEnabled.value = true
                                currentVideoSourceMediaId = mediaId
                                _currentVideoId.value = videoId
                                if (sponsorBlockManager.enabled.value) {
                                    sponsorBlockManager.forceReload(videoId, currentPlaybackDurationMs())
                                }
                                Timber.d("setVideoMode: SUCCESS - Video stream prepared with mimeType: $primaryMimeType, player state: ${player.playbackState}, playWhenReady: true")
                                android.util.Log.d("MusicService", ">>> SUCCESS - Video mode enabled for: ${videoData.title}")
                            } else {
                                Timber.e("setVideoMode: Failed to get stream URL from search result")
                                _videoFetchError.value = "Gagal memuat streaming video"
                                _videoModeMessage.value = "Tidak dapat memuat video"
                                restoreTvPlaybackIfPaused(wasPlaying)
                                resetVideoMode()
                            }
                        } else {
                            _videoFetchError.value = "Video tidak ditemukan untuk lagu ini"
                            _videoModeMessage.value = "Tidak ada video yang tersedia untuk lagu ini"
                            restoreTvPlaybackIfPaused(wasPlaying)
                            resetVideoMode()
                        }
                    } else {
                        val errorMsg = searchResult.exceptionOrNull()?.message ?: "Kesalahan tidak diketahui"
                        Timber.e("setVideoMode: Fallback search failed: $errorMsg")
                        _videoFetchError.value = "Tidak ada video yang tersedia: $errorMsg"
                        _videoModeMessage.value = "Video tidak ditemukan untuk lagu ini"
                        restoreTvPlaybackIfPaused(wasPlaying)
                        resetVideoMode()
                    }
                } else {
                    // Switch back to audio
                    val original = originalAudioMediaItem
                    if (original != null) {
                        // Replace current item with original audio item without clearing queue
                        player.replaceMediaItem(index, original)
                        player.seekTo(index, position)
                        player.playWhenReady = wasPlaying
                    }
                    isVideoMode = false
                    _videoModeEnabled.value = false
                    currentVideoUrl = null
                    currentVideoSourceMediaId = null
                    originalAudioMediaItem = null
                    Timber.d("setVideoMode: Switched back to audio")
                }
            } catch (e: Exception) {
                Timber.e(e, "setVideoMode: Failed")
                isVideoMode = false
                _videoModeEnabled.value = false
                originalAudioMediaItem = null
                if (isTvDevice && !player.playWhenReady) {
                    player.playWhenReady = true
                }
            } finally {
                _isVideoSwitching.value = false
            }
        }
    }

    /**
     * Check if video stream is available for current media
     */
    suspend fun checkVideoAvailability(mediaId: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val available = SanMusicPlayerUtils.hasVideoPlayback(mediaId)
                _isVideoAvailable.value = available
                Timber.d("checkVideoAvailability: Video available for $mediaId = $available")
                available
            } catch (e: Exception) {
                Timber.e(e, "checkVideoAvailability: Error checking availability for $mediaId")
                _isVideoAvailable.value = false
                false
            }
        }
    }

    fun clearVideoError() {
        _videoFetchError.value = null
    }

    fun clearVideoModeMessage() {
        _videoModeMessage.value = null
    }

    /**
     * Initialize Google Cast support
     */
    private fun initializeCast() {
        if (dataStore.get(com.sanmusic.app.constants.EnableGoogleCastKey, true)) {
            try {
                castConnectionHandler = CastConnectionHandler(this, scope, this)
                castConnectionHandler?.initialize()
                timber.log.Timber.d("Google Cast initialized")
            } catch (e: Exception) {
                timber.log.Timber.e(e, "Failed to initialize Google Cast")
            }
        }
    }


    override fun onPositionDiscontinuity(
        oldPosition: Player.PositionInfo,
        newPosition: Player.PositionInfo,
        reason: Int
    ) {
        if (reason == Player.DISCONTINUITY_REASON_SEEK) {
            scheduleCrossfade()
            stemRefPositionMs = newPosition.positionMs.coerceAtLeast(0L)
            stemRefElapsedRealtimeMs = android.os.SystemClock.elapsedRealtime()
        } else if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION && RemoveMusicVocalRemover.state.value.active) {
            // Turn off vocal & instrument separation if song auto-transitions or loops ("hanya menyala sekali di music yang di pilih ga otomatis")
            deactivateVocalInstrumentSeparation()
        }
    }
    
    private fun scheduleCrossfade() {
        crossfadeTriggerJob?.cancel()
        crossfadeTriggerJob = null
        if (!crossfadeEnabled) return
        // Never automix/crossfade into a video-backed song: the secondary player
        // copies the whole queue (including the injected video sources), which
        // tears down video mode and can crash the app or leave a black video
        // surface on the phone. Video songs finish naturally and let
        // onMediaItemTransition handle the switch so SponsorBlock keeps working.
        if (isVideoMode) {
            Timber.d("scheduleCrossfade: Skipping crossfade while in video mode")
            return
        }
        // Repeat-one must finish naturally and restart the same item; blending into another
        // item would violate the user's explicit repeat command.
        if (player.repeatMode == REPEAT_MODE_ONE) return
        if (player.duration == C.TIME_UNSET || player.duration <= crossfadeDuration) {
            // Duration not yet known — retry after a short delay for both Crossfade and Automix
            if (player.duration == C.TIME_UNSET && player.playWhenReady) {
                crossfadeTriggerJob = scope.launch {
                    delay(500)
                    if (player.playWhenReady && player.currentMediaItem != null) {
                        scheduleCrossfade()
                    }
                }
            }
            return
        }
        if (crossfadeGapless && isNextItemGapless()) return
        val nextCrossfadeIndex = nextCrossfadeMediaItemIndex()
        if (nextCrossfadeIndex == C.INDEX_UNSET) return
        // Never crossfade/automix into a video-backed song: it must play natively so
        // onMediaItemTransition routes it through video mode and SponsorBlock works.
        if (player.getMediaItemAt(nextCrossfadeIndex).metadata?.isVideoSong == true) {
            Timber.d("scheduleCrossfade: Skipping crossfade into video song")
            return
        }
        
        // Automix starts the blend once the configured % of the current song has
        // played (default 90%). Uses a linear fade for a DJ-style mix.
        val triggerPercent = if (automixEnabled) automixBlendPercent / 100f else 0f
        val triggerOffset = if (automixEnabled) {
            (player.duration * triggerPercent).toLong()
        } else {
            player.duration - crossfadeDuration.toLong()
        }
        val triggerTime = if (automixEnabled) {
            // Leave enough time for the full fade even on short tracks.
            minOf(triggerOffset, player.duration - crossfadeDuration.toLong())
        } else {
            triggerOffset
        }
        val remainingTrackMs = player.duration - player.currentPosition
        if (remainingTrackMs <= 1200L) return
        val delayMs = (triggerTime - player.currentPosition).coerceAtLeast(0L)
        // Pre-warm the secondary player up to 1500ms before triggerTime so stream resolution
        // does not delay the start of the crossfade transition.
        val preWarmLeadMs = 1500L
        val preWarmDelayMs = (delayMs - preWarmLeadMs).coerceAtLeast(0L)
        
        val targetMediaId = player.currentMediaItem?.mediaId
        
        crossfadeTriggerJob = scope.launch {
            delay(preWarmDelayMs)
            if (isActive && player.isPlaying && player.currentMediaItem?.mediaId == targetMediaId) {
                startCrossfade(triggerTimeMs = triggerTime)
            }
        }
    }
    
    private fun isNextItemGapless(): Boolean {
        val current = player.currentMediaItem?.mediaMetadata ?: return false
        val nextIndex = nextCrossfadeMediaItemIndex()
        if (nextIndex == C.INDEX_UNSET) return false
        val next = player.getMediaItemAt(nextIndex).mediaMetadata
        return current.albumTitle != null && current.albumTitle == next.albumTitle
    }

    private fun nextCrossfadeMediaItemIndex(): Int {
        if (player.repeatMode == REPEAT_MODE_ONE || player.mediaItemCount < 2) return C.INDEX_UNSET
        val nextIndex = player.nextMediaItemIndex
        if (nextIndex != C.INDEX_UNSET) return nextIndex
        return if (player.repeatMode == REPEAT_MODE_ALL) 0 else C.INDEX_UNSET
    }
    
    /**
     * Records the current song to history before crossfade completes.
     * This ensures the song is tracked even though playback doesn't end naturally.
     */
    private fun recordCurrentSongToHistory() {
        val mediaItem = player.currentMediaItem ?: return
        val playTimeMs = player.currentPosition
        val historyDurationMs = dataStore[HistoryDuration]?.times(1000f) ?: 30000f
        
        if (playTimeMs >= historyDurationMs && !dataStore.get(PauseListenHistoryKey, false)) {
            database.query {
                incrementTotalPlayTime(mediaItem.mediaId, playTimeMs)
                try {
                    insert(
                        Event(
                            songId = mediaItem.mediaId,
                            timestamp = LocalDateTime.now(),
                            playTime = playTimeMs,
                        ),
                    )
                } catch (_: SQLException) {
                }
            }
        }
        
        // Register playback with YouTube
        if (playTimeMs >= historyDurationMs) {
            CoroutineScope(Dispatchers.IO).launch {
                val playbackUrl = database.format(mediaItem.mediaId).first()?.playbackUrl
                    ?: YTPlayerUtils.playerResponseForMetadata(mediaItem.mediaId, null)
                        .getOrNull()?.playbackTracking?.videostatsPlaybackUrl?.baseUrl
                playbackUrl?.let {
                    YouTube.registerPlayback(null, playbackUrl)
                        .onFailure {
                            reportException(it)
                        }
                }
            }
        }
    }
    
    private fun startCrossfade(triggerTimeMs: Long = 0L) {
        if (isCrossfading) return
        // Same guard as scheduleCrossfade: never crossfade a video-backed song —
        // the swap tears down video mode and leaves a black video surface.
        if (isVideoMode) {
            Timber.d("startCrossfade: Skipping crossfade while in video mode")
            return
        }
        val nextIndex = nextCrossfadeMediaItemIndex()
        if (nextIndex == C.INDEX_UNSET) return
        val outgoingMediaId = player.currentMediaItem?.mediaId ?: return
        
        // Clean up any stale secondaryPlayer before creating a new one
        secondaryPlayer?.let { stale ->
            stale.removeListener(secondaryPlayerListener)
            stale.stop()
            stale.clearMediaItems()
            playerSilenceProcessors.remove(stale)
            stale.release()
        }
        secondaryPlayer = null

        // Record current song to history before crossfade
        recordCurrentSongToHistory()
        
        secondaryPlayer = createExoPlayer(publishPlayer = false)
        val secPlayer = secondaryPlayer!!
        secPlayer.addListener(secondaryPlayerListener)
        
        val itemCount = player.mediaItemCount
        val items = mutableListOf<MediaItem>()
        // Copy entire queue history + future
        for (i in 0 until itemCount) {
            items.add(player.getMediaItemAt(i))
        }
        
        secPlayer.setMediaItems(items)
        // The replacement player defaults repeat to OFF. Preserve the user's command before
        // attaching MusicService as a listener, otherwise the swap persists the wrong mode.
        secPlayer.repeatMode = player.repeatMode
        secPlayer.shuffleModeEnabled = player.shuffleModeEnabled
        // Seek to next track (the one we are fading into)
        secPlayer.seekTo(nextIndex, 0)
        secPlayer.volume = 0f
        val readyListener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState != Player.STATE_READY || secondaryPlayer !== secPlayer) return
                secPlayer.removeListener(this)

                scope.launch {
                    // Wait until we reach triggerTimeMs if pre-warmed early
                    val waitMs = (triggerTimeMs - player.currentPosition).coerceAtLeast(0L)
                    if (waitMs > 0L) {
                        secPlayer.playWhenReady = false
                        delay(waitMs)
                    }

                    // Stream resolution can take longer than a cache hit. If playback moved while
                    // waiting, discard this stale player rather than swapping to the wrong song.
                    if (secondaryPlayer !== secPlayer ||
                        player.currentMediaItem?.mediaId != outgoingMediaId ||
                        player.repeatMode == REPEAT_MODE_ONE || !crossfadeEnabled
                    ) {
                        secPlayer.removeListener(secondaryPlayerListener)
                        secPlayer.stop()
                        secPlayer.clearMediaItems()
                        playerSilenceProcessors.remove(secPlayer)
                        secPlayer.release()
                        if (secondaryPlayer === secPlayer) secondaryPlayer = null
                        scheduleCrossfade()
                        return@launch
                    }
                    secPlayer.playWhenReady = true
                    performCrossfadeSwap()
                }
            }
        }
        secPlayer.addListener(readyListener)
        secPlayer.prepare()
        secPlayer.playWhenReady = true
    }
    
    private fun performCrossfadeSwap() {
        if (sleepTimer.pauseWhenSongEnd) {
            sleepTimer.notifySongTransition()
            secondaryPlayer?.let { pendingPlayer ->
                pendingPlayer.removeListener(secondaryPlayerListener)
                pendingPlayer.stop()
                pendingPlayer.clearMediaItems()
                playerSilenceProcessors.remove(pendingPlayer)
                pendingPlayer.release()
            }
            secondaryPlayer = null
            return
        }

        val nextPlayer = secondaryPlayer ?: return
        val oldPlayer = player
        isCrossfading = true

        nextPlayer.removeListener(secondaryPlayerListener)
        nextPlayer.addListener(this)
        nextPlayer.addListener(sleepTimer)
        nextPlayer.addAnalyticsListener(PlaybackStatsListener(false, this@MusicService))

        // Move MediaSession first. Never publish/release the old player if the session rejects
        // the replacement, otherwise controllers can retain a player that we have destroyed.
        try {
            mediaSession.player = nextPlayer
        } catch (e: Exception) {
            Timber.tag(TAG).e(e, "Failed to swap player in MediaSession")
            nextPlayer.removeListener(this)
            nextPlayer.removeListener(sleepTimer)
            nextPlayer.stop()
            nextPlayer.clearMediaItems()
            playerSilenceProcessors.remove(nextPlayer)
            nextPlayer.release()
            secondaryPlayer = null
            isCrossfading = false
            scheduleCrossfade()
            return
        }

        fadingPlayer = oldPlayer
        player = nextPlayer
        secondaryPlayer = null
        sleepTimer.player = nextPlayer
        currentMediaMetadata.value = nextPlayer.currentMetadata

        oldPlayer.removeListener(this)
        oldPlayer.removeListener(sleepTimer)

        // Add listener to sync play/pause state
        val playbackBridge = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isCrossfading && fadingPlayer === oldPlayer) {
                    if (isPlaying) {
                        oldPlayer.play()
                    } else {
                        oldPlayer.pause()
                    }
                } else {
                    nextPlayer.removeListener(this)
                }
            }
        }
        nextPlayer.addListener(playbackBridge)

        // Publish only after the service, session, and listeners agree on the active player.
        _playerFlow.value = nextPlayer
        
        crossfadeJob = scope.launch {
            val remainingOutgoingMs = (oldPlayer.duration - oldPlayer.currentPosition).takeIf {
                oldPlayer.duration != C.TIME_UNSET && it > 500L
            } ?: crossfadeDuration.toLong()
            val duration = minOf(crossfadeDuration.toLong(), remainingOutgoingMs).coerceAtLeast(500L)
            val steps = 40
            val stepTime = (duration / steps).coerceAtLeast(15L)
            val targetVolume = if (isMuted.value) 0f else (playerVolume.value * sleepTimer.fadeVolumeMultiplierFlow.value).coerceIn(0f, 1f)
            val outgoingStartVolume = oldPlayer.volume
            nextPlayer.volume = 0f
            
            for (i in 1..steps) {
                if (!isActive) break
                // Pause volume ramp if player is paused
                while (!nextPlayer.isPlaying && isActive) {
                    delay(100)
                }
                
                val progress = i / steps.toFloat()
                val fadeIn: Float
                val fadeOut: Float
                when {
                    automixEnabled || crossfadeCurve == CrossfadeCurve.LINEAR -> {
                        // Linear crossfade for DJ-style mixing
                        fadeIn = progress
                        fadeOut = 1.0f - progress
                    }
                    crossfadeCurve == CrossfadeCurve.EQUAL_POWER -> {
                        // Equal-power cosine/sine crossfade (constant perceived loudness)
                        val angle = progress * (PI.toFloat() / 2f)
                        fadeIn = sin(angle)
                        fadeOut = cos(angle)
                    }
                    else -> {
                        // Smooth quadratic crossfade
                        fadeIn = 1.0f - (1.0f - progress) * (1.0f - progress)
                        fadeOut = (1.0f - progress) * (1.0f - progress)
                    }
                }
                
                try {
                    nextPlayer.volume = targetVolume * fadeIn
                    oldPlayer.volume = outgoingStartVolume * fadeOut
                } catch (e: Exception) { break }
                
                delay(stepTime)
            }
            
            try {
                oldPlayer.volume = 0f
                nextPlayer.volume = targetVolume
                nextPlayer.removeListener(playbackBridge)
                // Let the TV AudioTrack drain its final silent buffer before releasing it.
                delay(100)
                closeAudioEffectSession()
                cleanupCrossfade()
                openAudioEffectSession()
                // Schedule the next crossfade for the newly active track
                scheduleCrossfade()
            } catch (e: Exception) {
                cleanupCrossfade()
                scheduleCrossfade()
            }
        }
    }
    
    private fun cleanupCrossfade() {
        fadingPlayer?.let { oldPlayer ->
            oldPlayer.stop()
            oldPlayer.clearMediaItems()
            playerSilenceProcessors.remove(oldPlayer)
            oldPlayer.release()
        }
        fadingPlayer = null
        isCrossfading = false
    }

    /**
     * Handle alarm fire — load the user's selected alarm songs from the
     * database and start playback. This is invoked from [AlarmReceiver] via
     * `startForegroundService`, so playback begins even when the app is
     * not in the foreground.
     */
    private fun handleAlarmPlay() {
        val ds = dataStore
        val csv = ds.get(com.sanmusic.app.constants.AlarmSongIdsKey, "")
        val songIds = csv.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (songIds.isEmpty()) {
            Timber.tag(TAG).w("Alarm fired but no songs selected")
            return
        }
        val shuffle = ds.get(com.sanmusic.app.constants.AlarmShuffleKey, false)
        val volume = ds.get(com.sanmusic.app.constants.AlarmVolumeKey, 0.85f)

        if (!scope.isActive) scope = CoroutineScope(Dispatchers.Main) + Job()
        scope.launch {
            val songs = withContext(Dispatchers.IO) { database.getSongsByIds(songIds) }
            val ordered = if (shuffle) songs.shuffled() else songs
            val mediaItems = ordered.map { it.toMediaItem() }
            if (mediaItems.isEmpty()) {
                Timber.tag(TAG).w("Alarm: requested song ids resolved to empty list")
                return@launch
            }
            // Force-unmute and apply alarm volume.
            setMuted(false)
            if (::playerVolume.isInitialized) {
                playerVolume.value = volume.coerceIn(0.05f, 1f)
            }
            playQueue(
                queue = com.sanmusic.app.playback.queues.ListQueue(
                    title = getString(R.string.alarm_title),
                    items = mediaItems,
                    startIndex = 0,
                    position = 0L,
                ),
                playWhenReady = true,
            )
        }
    }

    companion object {
        val desiredSubtitleLanguages = setOf("en", "sw", "es", "fr", "la")

        /** Action used by AlarmReceiver to start music playback in the background. */
        const val ACTION_PLAY_ALARM = "com.sanmusic.app.playback.ACTION_PLAY_ALARM"

        const val ROOT = "root"
        const val SONG = "song"
        const val ARTIST = "artist"
        const val ALBUM = "album"
        const val PLAYLIST = "playlist"
        const val YOUTUBE_PLAYLIST = "youtube_playlist"
        const val SEARCH = "search"
        const val SHUFFLE_ACTION = "__shuffle__"

        const val CHANNEL_ID = "music_channel_01"
        const val TV_CHANNEL_ID = "tv_now_playing"
        const val NOTIFICATION_ID = 888
        const val ERROR_CODE_NO_STREAM = 1000001
        const val CHUNK_LENGTH = 512 * 1024L
        const val PERSISTENT_QUEUE_FILE = "persistent_queue.data"
        const val PERSISTENT_AUTOMIX_FILE = "persistent_automix.data"
        const val PERSISTENT_PLAYER_STATE_FILE = "persistent_player_state.data"
        const val MAX_CONSECUTIVE_ERR = 5
        const val MAX_RETRY_COUNT = 10
        const val MAX_GAIN_MB = 300 // Maximum gain in millibels (3 dB)

        /** Hard deadline for TV/mobile video-mode stream search before falling back to audio. */
        private const val VIDEO_SEARCH_TIMEOUT_MS = 20_000L
        const val MIN_GAIN_MB = -1500 // Minimum gain in millibels (-15 dB)

        const val TAG = "MusicService"
        
        @Volatile
        var isRunning = false
            private set
    }
}
