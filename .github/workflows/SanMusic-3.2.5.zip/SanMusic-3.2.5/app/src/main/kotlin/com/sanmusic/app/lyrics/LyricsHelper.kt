/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.lyrics

import android.content.Context
import android.util.LruCache
import androidx.datastore.preferences.core.Preferences
import com.sanmusic.app.constants.LyricsProviderOrderKey
import com.sanmusic.app.constants.PreferredLyricsProvider
import com.sanmusic.app.constants.PreferredLyricsProviderKey
import com.sanmusic.app.db.entities.LyricsEntity.Companion.LYRICS_NOT_FOUND
import com.sanmusic.app.extensions.toEnum
import com.sanmusic.app.models.MediaMetadata
import com.sanmusic.app.utils.NetworkConnectivityObserver
import com.sanmusic.app.utils.dataStore
import com.sanmusic.app.utils.reportException
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import timber.log.Timber
import javax.inject.Inject

private const val MAX_LYRICS_FETCH_MS = 30_000L
private const val PER_PROVIDER_TIMEOUT_MS = 6_000L
private const val PROVIDER_NONE = "Unknown"

class LyricsHelper
@Inject
constructor(
    @ApplicationContext private val context: Context,
    private val networkConnectivity: NetworkConnectivityObserver,
) {
    private val cache = LruCache<String, LyricsWithProvider>(MAX_CACHE_SIZE)
    private val allLyricsCache = LruCache<String, List<LyricsResult>>(MAX_CACHE_SIZE)
    private var currentLyricsJob: Job? = null

    /**
     * Fetch lyrics for [mediaMetadata], strictly honouring the user's preferred
     * provider order at the moment of the call.
     *
     * The previous implementation collected the preference flow asynchronously
     * into a member field, which meant that the very first call (and any call
     * made just after the user changed the priority) could iterate over a stale
     * list and return lyrics from the wrong provider.  We now resolve the
     * ordered, enabled provider list synchronously per call.
     */
    suspend fun getLyrics(mediaMetadata: MediaMetadata): LyricsWithProvider {
        currentLyricsJob?.cancel()

        val orderedProviders = resolveOrderedProviders()
        val preferredProviderName = orderedProviders.firstOrNull()?.name ?: PROVIDER_NONE

        // Only honour the in-memory cache when it actually matches the
        // currently-preferred provider, otherwise the user thinks they changed
        // priority but keeps seeing the old result.
        cache.get(mediaMetadata.id)?.let { cached ->
            if (cached.lyrics != LYRICS_NOT_FOUND && cached.provider == preferredProviderName) {
                Timber.tag(TAG).d("Returning cached lyrics from preferred provider ${cached.provider}")
                return cached
            }
        }

        val isNetworkAvailable = try {
            networkConnectivity.isCurrentlyConnected()
        } catch (e: Exception) {
            true
        }
        if (!isNetworkAvailable) {
            Timber.tag(TAG).w("Network not available, returning not found")
            return LyricsWithProvider(LYRICS_NOT_FOUND, PROVIDER_NONE)
        }

        val cleanedTitle = LyricsUtils.cleanTitleForSearch(mediaMetadata.title)
        val artistString = mediaMetadata.artists.joinToString { it.name }
        val durationSeconds = if (mediaMetadata.duration > 0) mediaMetadata.duration / 1000 else mediaMetadata.duration
        val enabledProviders = orderedProviders.filter { it.isEnabled(context) }

        Timber.tag(TAG).d("Searching lyrics for: '$cleanedTitle' by '$artistString'")
        Timber.tag(TAG).d("Enabled providers in order: ${enabledProviders.joinToString { it.name }}")

        val result = withTimeoutOrNull(MAX_LYRICS_FETCH_MS) {
            for (provider in enabledProviders) {
                Timber.tag(TAG).d("Trying provider: ${provider.name}")
                val providerResult = try {
                    withTimeoutOrNull(PER_PROVIDER_TIMEOUT_MS) {
                        provider.getLyrics(
                            mediaMetadata.id,
                            cleanedTitle,
                            artistString,
                            durationSeconds,
                            mediaMetadata.album?.title,
                        )
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Timber.tag(TAG).w("${provider.name} threw: ${e.message}")
                    reportException(e)
                    null
                }

                if (providerResult != null && providerResult.isSuccess) {
                    val lyrics = providerResult.getOrNull()
                    if (isValidLyricsContent(lyrics)) {
                        Timber.tag(TAG).i("Got lyrics from ${provider.name}")
                        return@withTimeoutOrNull LyricsWithProvider(lyrics!!, provider.name)
                    }
                    Timber.tag(TAG).w("${provider.name} returned success with empty/NOT_FOUND body")
                } else {
                    val errorMsg = providerResult?.exceptionOrNull()?.message ?: "timeout or no result"
                    Timber.tag(TAG).w("${provider.name} failed: $errorMsg")
                }
            }
            Timber.tag(TAG).w("All providers failed for '${mediaMetadata.title}'")
            LyricsWithProvider(LYRICS_NOT_FOUND, PROVIDER_NONE)
        } ?: LyricsWithProvider(LYRICS_NOT_FOUND, PROVIDER_NONE)

        if (result.lyrics != LYRICS_NOT_FOUND) {
            cache.put(mediaMetadata.id, result)
        }
        return result
    }

    suspend fun getAllLyrics(
        mediaId: String,
        songTitle: String,
        songArtists: String,
        duration: Int,
        album: String? = null,
        callback: (LyricsResult) -> Unit,
    ) {
        currentLyricsJob?.cancel()

        val cacheKey = "$songArtists-$songTitle".replace(" ", "")
        allLyricsCache.get(cacheKey)?.let { results ->
            results.forEach { callback(it) }
            return
        }

        val isNetworkAvailable = try {
            networkConnectivity.isCurrentlyConnected()
        } catch (e: Exception) {
            true
        }
        if (!isNetworkAvailable) return

        val allResult = mutableListOf<LyricsResult>()
        val orderedProviders = resolveOrderedProviders()
        currentLyricsJob = CoroutineScope(SupervisorJob()).launch {
            val cleanedTitle = LyricsUtils.cleanTitleForSearch(songTitle)
            orderedProviders.forEach { provider ->
                if (provider.isEnabled(context)) {
                    try {
                        provider.getAllLyrics(mediaId, cleanedTitle, songArtists, duration, album) { lyrics ->
                            val result = LyricsResult(provider.name, lyrics)
                            allResult += result
                            callback(result)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        reportException(e)
                    }
                }
            }
            allLyricsCache.put(cacheKey, allResult)
        }
        currentLyricsJob?.join()
    }

    /**
     * Drop any cached lyrics for [mediaId] so the next [getLyrics] call goes
     * back to the network. Called by the refetch / retry path so the user's
     * action actually triggers a fresh request.
     */
    fun invalidateCache(mediaId: String?) {
        if (mediaId == null) {
            cache.evictAll()
            allLyricsCache.evictAll()
        } else {
            cache.remove(mediaId)
        }
    }

    fun cancelCurrentLyricsJob() {
        currentLyricsJob?.cancel()
        currentLyricsJob = null
    }

    /**
     * Immediately fetches lyrics prioritizing [preferred] without requiring the user
     * to clear cache. Always attempts [preferred] first, then falls back to SimpMusic
     * and the remaining enabled providers if [preferred] has no lyrics for this track.
     */
    suspend fun getLyricsFromProvider(
        mediaMetadata: MediaMetadata,
        preferred: PreferredLyricsProvider,
    ): LyricsWithProvider {
        currentLyricsJob?.cancel()
        invalidateCache(mediaMetadata.id)

        val isNetworkAvailable = try {
            networkConnectivity.isCurrentlyConnected()
        } catch (e: Exception) {
            true
        }
        if (!isNetworkAvailable) {
            return LyricsWithProvider(LYRICS_NOT_FOUND, PROVIDER_NONE)
        }

        val cleanedTitle = LyricsUtils.cleanTitleForSearch(mediaMetadata.title)
        val artistString = mediaMetadata.artists.joinToString { it.name }
        val durationSeconds = if (mediaMetadata.duration > 0) mediaMetadata.duration / 1000 else mediaMetadata.duration

        val primaryProvider = providerInstanceOf(preferred)
        val fallbackOrder = listOf(
            primaryProvider,
            SimpMusicLyricsProvider,
            BetterLyricsProvider,
            LrcLibLyricsProvider,
            RushLyricsProvider,
            PaxsenixLyricsProvider,
            MusixmatchLyricsProvider,
            KuGouLyricsProvider,
        ).distinctBy { it.name }

        val providersToTry = fallbackOrder.filter { it.name == primaryProvider.name || it.isEnabled(context) }

        val result = withTimeoutOrNull(MAX_LYRICS_FETCH_MS) {
            for (provider in providersToTry) {
                Timber.tag(TAG).d("Direct provider switch trying: ${provider.name}")
                val providerResult = try {
                    withTimeoutOrNull(PER_PROVIDER_TIMEOUT_MS) {
                        provider.getLyrics(
                            mediaMetadata.id,
                            cleanedTitle,
                            artistString,
                            durationSeconds,
                            mediaMetadata.album?.title,
                        )
                    }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Timber.tag(TAG).w("${provider.name} threw: ${e.message}")
                    reportException(e)
                    null
                }

                if (providerResult != null && providerResult.isSuccess) {
                    val lyrics = providerResult.getOrNull()
                    if (isValidLyricsContent(lyrics)) {
                        Timber.tag(TAG).i("Direct switch got lyrics from ${provider.name}")
                        return@withTimeoutOrNull LyricsWithProvider(lyrics!!, provider.name)
                    }
                }
            }
            LyricsWithProvider(LYRICS_NOT_FOUND, PROVIDER_NONE)
        } ?: LyricsWithProvider(LYRICS_NOT_FOUND, PROVIDER_NONE)

        if (result.lyrics != LYRICS_NOT_FOUND) {
            cache.put(mediaMetadata.id, result)
        }
        return result
    }

    /**
     * Build the ordered, user-preferred provider list straight from DataStore
     * at call time, so changes to "preferred provider" or to the drag-and-drop
     * order take effect immediately on the next fetch.
     */
    private suspend fun resolveOrderedProviders(): List<LyricsProvider> {
        val preferences = context.dataStore.data
            .map { it }
            .first()
        return resolveOrderedProviders(preferences)
    }

    private fun resolveOrderedProviders(preferences: Preferences): List<LyricsProvider> {
        val defaultOrder = LyricsProviderRegistry.serializeProviderOrder(
            LyricsProviderRegistry.getDefaultProviderOrder()
        )
        val providerOrder = preferences[LyricsProviderOrderKey] ?: defaultOrder
        val preferredProvider = preferences[PreferredLyricsProviderKey]
            .toEnum(PreferredLyricsProvider.SIMPMUSIC)

        val preferredInstance = providerInstanceOf(preferredProvider)

        return if (providerOrder != defaultOrder) {
            // The user has reordered the list explicitly — keep their order
            // but always promote their preferred provider to the front so the
            // "first lyrics provider" setting is never overruled.
            val customOrder = LyricsProviderRegistry.getOrderedProviders(providerOrder)
            val rest = customOrder.filter { it.name != preferredInstance.name }
            listOf(preferredInstance) + rest
        } else {
            // No custom order — derive the order from the preferred provider,
            // keeping SimpMusic as the primary provider / first fallback.
            when (preferredProvider) {
                PreferredLyricsProvider.SIMPMUSIC -> listOf(
                    SimpMusicLyricsProvider, BetterLyricsProvider, LrcLibLyricsProvider,
                    RushLyricsProvider, PaxsenixLyricsProvider, MusixmatchLyricsProvider,
                    KuGouLyricsProvider,
                )
                PreferredLyricsProvider.LRCLIB -> listOf(
                    LrcLibLyricsProvider, SimpMusicLyricsProvider, BetterLyricsProvider,
                    RushLyricsProvider, PaxsenixLyricsProvider, MusixmatchLyricsProvider,
                    KuGouLyricsProvider,
                )
                PreferredLyricsProvider.KUGOU -> listOf(
                    KuGouLyricsProvider, SimpMusicLyricsProvider, BetterLyricsProvider,
                    RushLyricsProvider, PaxsenixLyricsProvider, MusixmatchLyricsProvider,
                    LrcLibLyricsProvider,
                )
                PreferredLyricsProvider.BETTER_LYRICS -> listOf(
                    BetterLyricsProvider, SimpMusicLyricsProvider, RushLyricsProvider,
                    PaxsenixLyricsProvider, MusixmatchLyricsProvider, LrcLibLyricsProvider,
                    KuGouLyricsProvider,
                )
                PreferredLyricsProvider.RUSH_LYRICS -> listOf(
                    RushLyricsProvider, SimpMusicLyricsProvider, BetterLyricsProvider,
                    PaxsenixLyricsProvider, MusixmatchLyricsProvider, LrcLibLyricsProvider,
                    KuGouLyricsProvider,
                )
                PreferredLyricsProvider.PAXSENIX -> listOf(
                    PaxsenixLyricsProvider, SimpMusicLyricsProvider, BetterLyricsProvider,
                    RushLyricsProvider, MusixmatchLyricsProvider, LrcLibLyricsProvider,
                    KuGouLyricsProvider,
                )
                PreferredLyricsProvider.MUSIXMATCH -> listOf(
                    MusixmatchLyricsProvider, SimpMusicLyricsProvider, BetterLyricsProvider,
                    RushLyricsProvider, PaxsenixLyricsProvider, LrcLibLyricsProvider,
                    KuGouLyricsProvider,
                )
            }
        }
    }

    private fun providerInstanceOf(preferred: PreferredLyricsProvider): LyricsProvider = when (preferred) {
        PreferredLyricsProvider.SIMPMUSIC -> SimpMusicLyricsProvider
        PreferredLyricsProvider.LRCLIB -> LrcLibLyricsProvider
        PreferredLyricsProvider.KUGOU -> KuGouLyricsProvider
        PreferredLyricsProvider.BETTER_LYRICS -> BetterLyricsProvider
        PreferredLyricsProvider.RUSH_LYRICS -> RushLyricsProvider
        PreferredLyricsProvider.PAXSENIX -> PaxsenixLyricsProvider
        PreferredLyricsProvider.MUSIXMATCH -> MusixmatchLyricsProvider
    }

    companion object {
        private const val TAG = "LyricsHelper"
        private const val MAX_CACHE_SIZE = 3

        fun providerNameOf(preferred: PreferredLyricsProvider): String = when (preferred) {
            PreferredLyricsProvider.SIMPMUSIC -> SimpMusicLyricsProvider.name
            PreferredLyricsProvider.BETTER_LYRICS -> BetterLyricsProvider.name
            PreferredLyricsProvider.LRCLIB -> LrcLibLyricsProvider.name
            PreferredLyricsProvider.RUSH_LYRICS -> RushLyricsProvider.name
            PreferredLyricsProvider.PAXSENIX -> PaxsenixLyricsProvider.name
            PreferredLyricsProvider.MUSIXMATCH -> MusixmatchLyricsProvider.name
            PreferredLyricsProvider.KUGOU -> KuGouLyricsProvider.name
        }

        fun displayNameOf(preferred: PreferredLyricsProvider): String = when (preferred) {
            PreferredLyricsProvider.SIMPMUSIC -> "SimpMusic"
            PreferredLyricsProvider.BETTER_LYRICS -> "Better Lyrics"
            PreferredLyricsProvider.LRCLIB -> "LrcLib"
            PreferredLyricsProvider.RUSH_LYRICS -> "RushLyrics"
            PreferredLyricsProvider.PAXSENIX -> "Paxsenix"
            PreferredLyricsProvider.MUSIXMATCH -> "Musixmatch"
            PreferredLyricsProvider.KUGOU -> "KuGou"
        }

        fun subtitleOf(preferred: PreferredLyricsProvider): String = when (preferred) {
            PreferredLyricsProvider.SIMPMUSIC -> "Penyedia Utama • Akurat & Cepat"
            PreferredLyricsProvider.BETTER_LYRICS -> "Sinkronisasi Per Kata (Apple Music Style)"
            PreferredLyricsProvider.LRCLIB -> "Database LRC Komunitas Terbuka"
            PreferredLyricsProvider.RUSH_LYRICS -> "Lirik Sinkron Cepat"
            PreferredLyricsProvider.PAXSENIX -> "Multi-Source Synced Lyrics"
            PreferredLyricsProvider.MUSIXMATCH -> "Katalog Lirik Musik Global"
            PreferredLyricsProvider.KUGOU -> "Katalog Asia & Internasional"
        }

        fun fromProviderName(name: String?): PreferredLyricsProvider? = when (name?.trim()) {
            SimpMusicLyricsProvider.name, "SimpMusic" -> PreferredLyricsProvider.SIMPMUSIC
            BetterLyricsProvider.name, "BetterLyrics", "Better Lyrics" -> PreferredLyricsProvider.BETTER_LYRICS
            LrcLibLyricsProvider.name, "LrcLib" -> PreferredLyricsProvider.LRCLIB
            RushLyricsProvider.name, "RushLyrics" -> PreferredLyricsProvider.RUSH_LYRICS
            PaxsenixLyricsProvider.name, "Paxsenix" -> PreferredLyricsProvider.PAXSENIX
            MusixmatchLyricsProvider.name, "Musixmatch" -> PreferredLyricsProvider.MUSIXMATCH
            KuGouLyricsProvider.name, "KuGou" -> PreferredLyricsProvider.KUGOU
            else -> null
        }

        fun isValidLyricsContent(lyrics: String?): Boolean {
            if (lyrics.isNullOrBlank() || lyrics == LYRICS_NOT_FOUND) return false
            val lines = lyrics.lines()
            return lines.any { rawLine ->
                val line = rawLine.trim()
                if (line.isBlank()) return@any false
                if (line.startsWith("[ti:", ignoreCase = true) ||
                    line.startsWith("[ar:", ignoreCase = true) ||
                    line.startsWith("[al:", ignoreCase = true) ||
                    line.startsWith("[by:", ignoreCase = true) ||
                    line.startsWith("[offset:", ignoreCase = true) ||
                    line.startsWith("[re:", ignoreCase = true) ||
                    line.startsWith("[ve:", ignoreCase = true) ||
                    line.startsWith("[length:", ignoreCase = true) ||
                    line.startsWith("[kana:", ignoreCase = true) ||
                    line.startsWith("[id:", ignoreCase = true) ||
                    line.startsWith("[au:", ignoreCase = true)) {
                    return@any false
                }
                val withoutTags = line.replace(Regex("\\[[0-9:.]+\\]"), "")
                    .replace(Regex("<[0-9:.]*>"), "")
                    .replace("♪", "")
                    .trim()
                withoutTags.isNotBlank()
            }
        }
    }
}

data class LyricsResult(
    val providerName: String,
    val lyrics: String,
)

data class LyricsWithProvider(
    val lyrics: String,
    val provider: String,
)
