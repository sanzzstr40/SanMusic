/**
 * San Music Project (C) 2026
 */

@file:OptIn(ExperimentalCoroutinesApi::class)

package com.sanmusic.app.viewmodels

import android.content.Context
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sanmusic.innertube.YouTube
import com.sanmusic.app.constants.AlbumFilter
import com.sanmusic.app.constants.AlbumFilterKey
import com.sanmusic.app.constants.AlbumSortDescendingKey
import com.sanmusic.app.constants.AlbumSortType
import com.sanmusic.app.constants.AlbumSortTypeKey
import com.sanmusic.app.constants.ArtistFilter
import com.sanmusic.app.constants.ArtistFilterKey
import com.sanmusic.app.constants.ArtistSongSortDescendingKey
import com.sanmusic.app.constants.ArtistSongSortType
import com.sanmusic.app.constants.ArtistSongSortTypeKey
import com.sanmusic.app.constants.ArtistSortDescendingKey
import com.sanmusic.app.constants.ArtistSortType
import com.sanmusic.app.constants.ArtistSortTypeKey
import com.sanmusic.app.constants.AudiobookIdsKey
import com.sanmusic.app.constants.AudiobookPositionsKey
import com.sanmusic.app.constants.HideExplicitKey
import com.sanmusic.app.constants.HideVideoSongsKey
import com.sanmusic.app.constants.LibraryFilter
import com.sanmusic.app.constants.PlaylistSortDescendingKey
import com.sanmusic.app.constants.PlaylistSortType
import com.sanmusic.app.constants.PlaylistSortTypeKey
import com.sanmusic.app.constants.SongFilter
import com.sanmusic.app.constants.SongFilterKey
import com.sanmusic.app.constants.SongSortDescendingKey
import com.sanmusic.app.constants.SongSortType
import com.sanmusic.app.constants.SongSortTypeKey
import com.sanmusic.app.constants.TopSize
import com.sanmusic.app.db.MusicDatabase
import com.sanmusic.app.db.entities.Song
import com.sanmusic.app.extensions.filterExplicit
import com.sanmusic.app.extensions.filterExplicitAlbums
import com.sanmusic.app.extensions.filterVideoSongs
import com.sanmusic.app.extensions.toEnum
import com.sanmusic.app.playback.DownloadUtil
import com.sanmusic.app.utils.SyncUtils
import com.sanmusic.app.utils.AUDIOBOOK_MIN_DURATION_SECONDS
import com.sanmusic.app.utils.dataStore
import com.sanmusic.app.utils.decodeAudiobookIds
import com.sanmusic.app.utils.decodeAudiobookPositions
import com.sanmusic.app.utils.encodeAudiobookIds
import com.sanmusic.app.utils.encodeAudiobookPositions
import com.sanmusic.app.utils.reportException
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDateTime
import javax.inject.Inject

@HiltViewModel
class LibrarySongsViewModel
@Inject
constructor(
    @ApplicationContext context: Context,
    database: MusicDatabase,
    downloadUtil: DownloadUtil,
    private val syncUtils: SyncUtils,
) : ViewModel() {
    val allSongs =
        context.dataStore.data
            .map {
                Triple(
                    Triple(
                        it[SongFilterKey].toEnum(SongFilter.LIKED),
                        it[SongSortTypeKey].toEnum(SongSortType.CREATE_DATE),
                        (it[SongSortDescendingKey] ?: true),
                    ),
                    it[HideExplicitKey] ?: false,
                    it[HideVideoSongsKey] ?: false
                )
            }.distinctUntilChanged()
            .flatMapLatest { (filterSort, hideExplicit, hideVideoSongs) ->
                val (filter, sortType, descending) = filterSort
                when (filter) {
                    SongFilter.LIBRARY -> database.songs(sortType, descending).map { it.filterExplicit(hideExplicit).filterVideoSongs(hideVideoSongs) }
                    SongFilter.LIKED -> database.likedSongs(sortType, descending).map { it.filterExplicit(hideExplicit).filterVideoSongs(hideVideoSongs) }
                    SongFilter.DOWNLOADED -> database.downloadedSongs(sortType, descending).map { it.filterExplicit(hideExplicit).filterVideoSongs(hideVideoSongs) }
                    // Uploaded feature is temporarily disabled
                    SongFilter.UPLOADED -> kotlinx.coroutines.flow.flowOf(emptyList())
                    // SongFilter.UPLOADED -> database.uploadedSongs(sortType, descending).map { it.filterExplicit(hideExplicit).filterVideoSongs(hideVideoSongs) }
                }
            }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun syncLikedSongs() {
        viewModelScope.launch(Dispatchers.IO) { syncUtils.syncLikedSongs() }
    }

    fun syncLibrarySongs() {
        viewModelScope.launch(Dispatchers.IO) { syncUtils.syncLibrarySongs() }
    }

    // Uploaded feature is temporarily disabled
    fun syncUploadedSongs() {
        // viewModelScope.launch(Dispatchers.IO) { syncUtils.syncUploadedSongs() }
    }
}

data class AudiobookLibraryItem(
    val song: Song,
    val resumePositionMs: Long,
    val pinned: Boolean,
)

@HiltViewModel
class LibraryAudiobooksViewModel
@Inject
constructor(
    @ApplicationContext private val context: Context,
    database: MusicDatabase,
) : ViewModel() {
    val audiobooks =
        combine(
            database.allSongs(),
            context.dataStore.data,
        ) { songs, preferences ->
            val audiobookIds = decodeAudiobookIds(preferences[AudiobookIdsKey])
            val positions = decodeAudiobookPositions(preferences[AudiobookPositionsKey])
            val hideExplicit = preferences[HideExplicitKey] ?: false
            val hideVideoSongs = preferences[HideVideoSongsKey] ?: false

            songs
                .asSequence()
                .filter { it.song.inLibrary != null || it.song.isDownloaded || it.id in audiobookIds }
                .filter { it.id in audiobookIds || it.song.duration >= AUDIOBOOK_MIN_DURATION_SECONDS }
                .filter { !hideExplicit || !it.song.explicit }
                .filter { !hideVideoSongs || !it.song.isVideo }
                .map {
                    AudiobookLibraryItem(
                        song = it,
                        resumePositionMs = positions[it.id]?.coerceIn(0L, (it.song.duration * 1000L).coerceAtLeast(0L)) ?: 0L,
                        pinned = it.id in audiobookIds,
                    )
                }
                .sortedWith(
                    compareByDescending<AudiobookLibraryItem> { it.resumePositionMs > 0L }
                        .thenByDescending { it.pinned }
                        .thenBy { it.song.song.title.lowercase() }
                )
                .toList()
        }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun setPinned(songId: String, pinned: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            context.dataStore.edit { preferences ->
                val ids = decodeAudiobookIds(preferences[AudiobookIdsKey]).toMutableSet()
                if (pinned) ids += songId else ids -= songId
                preferences[AudiobookIdsKey] = encodeAudiobookIds(ids)
            }
        }
    }

    fun clearResumePosition(songId: String) {
        viewModelScope.launch(Dispatchers.IO) {
            context.dataStore.edit { preferences ->
                val positions = decodeAudiobookPositions(preferences[AudiobookPositionsKey]).toMutableMap()
                positions -= songId
                preferences[AudiobookPositionsKey] = encodeAudiobookPositions(positions)
            }
        }
    }
}

@HiltViewModel
class LibraryArtistsViewModel
@Inject
constructor(
    @ApplicationContext context: Context,
    database: MusicDatabase,
    private val syncUtils: SyncUtils,
) : ViewModel() {
    private val artistDetailFetchAttempted = mutableSetOf<String>()

    val allArtists =
        context.dataStore.data
            .map {
                Triple(
                    it[ArtistFilterKey].toEnum(ArtistFilter.LIKED),
                    it[ArtistSortTypeKey].toEnum(ArtistSortType.CREATE_DATE),
                    it[ArtistSortDescendingKey] ?: true,
                )
            }.distinctUntilChanged()
            .flatMapLatest { (filter, sortType, descending) ->
                when (filter) {
                    ArtistFilter.LIKED -> database.artistsBookmarked(sortType, descending)
                    ArtistFilter.LIBRARY -> database.artists(sortType, descending)
                }
            }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun sync() {
        viewModelScope.launch(Dispatchers.IO) { syncUtils.syncArtistsSubscriptions() }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            allArtists.collect { artists ->
                artists
                    .map { it.artist }
                    .filter { artist ->
                        val isStale = Duration.between(
                            artist.lastUpdateTime,
                            LocalDateTime.now()
                        ) > Duration.ofDays(10)
                        val missingSubscriberCount =
                            artist.bookmarkedAt != null &&
                                artist.isYouTubeArtist &&
                                !artist.isPrivatelyOwnedArtist &&
                                artist.subscriberCountText.isNullOrBlank()

                        (artist.thumbnailUrl == null || isStale || missingSubscriberCount) &&
                            artistDetailFetchAttempted.add(artist.id)
                    }.forEach { artist ->
                        YouTube.artist(artist.id).onSuccess { artistPage ->
                            database.query {
                                update(artist, artistPage)
                            }
                        }
                    }
            }
        }
    }
}

@HiltViewModel
class LibraryAlbumsViewModel
@Inject
constructor(
    @ApplicationContext context: Context,
    database: MusicDatabase,
    private val syncUtils: SyncUtils,
) : ViewModel() {
    val allAlbums =
        context.dataStore.data
            .map {
                Pair(
                    Triple(
                        it[AlbumFilterKey].toEnum(AlbumFilter.LIKED),
                        it[AlbumSortTypeKey].toEnum(AlbumSortType.CREATE_DATE),
                        (it[AlbumSortDescendingKey] ?: true),
                    ),
                    it[HideExplicitKey] ?: false
                )
            }.distinctUntilChanged()
            .flatMapLatest { (filterSort, hideExplicit) ->
                val (filter, sortType, descending) = filterSort
                when (filter) {
                    AlbumFilter.LIKED -> database.albumsLiked(sortType, descending).map { it.filterExplicitAlbums(hideExplicit) }
                    AlbumFilter.LIBRARY -> database.albums(sortType, descending).map { it.filterExplicitAlbums(hideExplicit) }
                    // Uploaded feature is temporarily disabled
                    AlbumFilter.UPLOADED -> kotlinx.coroutines.flow.flowOf(emptyList())
                    // AlbumFilter.UPLOADED -> database.albumsUploaded(sortType, descending).map { it.filterExplicitAlbums(hideExplicit) }
                }
            }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun sync() {
        viewModelScope.launch(Dispatchers.IO) { syncUtils.syncLikedAlbums() }
    }

    init {
        viewModelScope.launch(Dispatchers.IO) {
            allAlbums.collect { albums ->
                albums
                    .filter {
                        it.album.songCount == 0
                    }.forEach { album ->
                        YouTube
                            .album(album.id)
                            .onSuccess { albumPage ->
                                database.query {
                                    update(album.album, albumPage, album.artists)
                                }
                            }.onFailure {
                                reportException(it)
                                if (it.message?.contains("NOT_FOUND") == true) {
                                    database.query {
                                        delete(album.album)
                                    }
                                }
                            }
                    }
            }
        }
    }
}
@HiltViewModel
class LibraryPlaylistsViewModel
@Inject
constructor(
    @ApplicationContext context: Context,
    database: MusicDatabase,
    private val syncUtils: SyncUtils,
) : ViewModel() {
    val allPlaylists =
        context.dataStore.data
            .map {
                it[PlaylistSortTypeKey].toEnum(PlaylistSortType.CREATE_DATE) to (it[PlaylistSortDescendingKey]
                    ?: true)
            }.distinctUntilChanged()
            .flatMapLatest { (sortType, descending) ->
                database.playlists(sortType, descending)
            }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun sync() {
        viewModelScope.launch(Dispatchers.IO) { syncUtils.syncSavedPlaylists() }
    }

    val topValue =
        context.dataStore.data
            .map { it[TopSize] ?: "50" }
            .distinctUntilChanged()
}

@HiltViewModel
class ArtistSongsViewModel
@Inject
constructor(
    @ApplicationContext context: Context,
    database: MusicDatabase,
    savedStateHandle: SavedStateHandle,
) : ViewModel() {
    private val artistId = savedStateHandle.get<String>("artistId")!!
    val artist =
        database
            .artist(artistId)
            .stateIn(viewModelScope, SharingStarted.Lazily, null)

    val songs =
        context.dataStore.data
            .map {
                Triple(
                    it[ArtistSongSortTypeKey].toEnum(ArtistSongSortType.CREATE_DATE) to (it[ArtistSongSortDescendingKey]
                        ?: true),
                    it[HideExplicitKey] ?: false,
                    it[HideVideoSongsKey] ?: false
                )
            }.distinctUntilChanged()
            .flatMapLatest { (sortDesc, hideExplicit, hideVideoSongs) ->
                val (sortType, descending) = sortDesc
                database.artistSongs(artistId, sortType, descending).map { it.filterExplicit(hideExplicit).filterVideoSongs(hideVideoSongs) }
            }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
}

@HiltViewModel
class LibraryMixViewModel
@Inject
constructor(
    @ApplicationContext context: Context,
    database: MusicDatabase,
    private val syncUtils: SyncUtils,
) : ViewModel() {
    private val artistDetailFetchAttempted = mutableSetOf<String>()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing = _isRefreshing.asStateFlow()

    val syncAllLibrary = {
         viewModelScope.launch(Dispatchers.IO) {
             syncUtils.tryAutoSync()
         }
    }

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            _isRefreshing.value = true
            syncUtils.performFullSyncSuspend()
            _isRefreshing.value = false
        }
    }

    val topValue =
        context.dataStore.data
            .map { it[TopSize] ?: "50" }
            .distinctUntilChanged()
    var artists =
        database
            .artistsBookmarked(
                ArtistSortType.CREATE_DATE,
                true,
            ).stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    var albums = context.dataStore.data
        .map { it[HideExplicitKey] ?: false }
        .distinctUntilChanged()
        .flatMapLatest { hideExplicit ->
            database.albumsLiked(AlbumSortType.CREATE_DATE, true).map { it.filterExplicitAlbums(hideExplicit) }
        }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    var playlists = database.playlists(PlaylistSortType.CREATE_DATE, true)
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    init {
        viewModelScope.launch(Dispatchers.IO) {
            albums.collect { albums ->
                albums
                    .filter {
                        it.album.songCount == 0
                    }.forEach { album ->
                        YouTube
                            .album(album.id)
                            .onSuccess { albumPage ->
                                database.query {
                                    update(album.album, albumPage, album.artists)
                                }
                            }.onFailure {
                                reportException(it)
                                if (it.message?.contains("NOT_FOUND") == true) {
                                    database.query {
                                        delete(album.album)
                                    }
                                }
                            }
                    }
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            artists.collect { artists ->
                artists
                    .map { it.artist }
                    .filter { artist ->
                        val isStale = Duration.between(
                            artist.lastUpdateTime,
                            LocalDateTime.now(),
                        ) > Duration.ofDays(10)
                        val missingSubscriberCount =
                            artist.bookmarkedAt != null &&
                                artist.isYouTubeArtist &&
                                !artist.isPrivatelyOwnedArtist &&
                                artist.subscriberCountText.isNullOrBlank()

                        (artist.thumbnailUrl == null || isStale || missingSubscriberCount) &&
                            artistDetailFetchAttempted.add(artist.id)
                    }.forEach { artist ->
                        YouTube.artist(artist.id).onSuccess { artistPage ->
                            database.query {
                                update(artist, artistPage)
                            }
                        }
                    }
            }
        }
    }
}

@HiltViewModel
class LibraryViewModel
@Inject
constructor() : ViewModel() {
    private val curScreen = mutableStateOf(LibraryFilter.LIBRARY)
    val filter: MutableState<LibraryFilter> = curScreen
}
