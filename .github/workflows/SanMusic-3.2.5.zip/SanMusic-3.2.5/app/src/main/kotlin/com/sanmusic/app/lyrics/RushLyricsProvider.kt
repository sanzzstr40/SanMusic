/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.lyrics

import android.content.Context
import com.sanmusic.rush.RushLyrics
import com.sanmusic.app.constants.EnableRushLyricsKey
import com.sanmusic.app.utils.dataStore
import com.sanmusic.app.utils.get

object RushLyricsProvider : LyricsProvider {
    override val name = "RushLyrics"

    override fun isEnabled(context: Context): Boolean = context.dataStore[EnableRushLyricsKey] ?: true

    override suspend fun getLyrics(
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
    ): Result<String> = RushLyrics.getLyrics(title, artist, duration, album)

    override suspend fun getAllLyrics(
        id: String,
        title: String,
        artist: String,
        duration: Int,
        album: String?,
        callback: (String) -> Unit,
    ) {
        RushLyrics.getAllLyrics(title, artist, duration, album, callback)
    }
}
