/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.ui.screens

import android.app.Activity
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.compose.dialog
import androidx.navigation.navArgument
import com.sanmusic.app.constants.DarkModeKey
import com.sanmusic.app.constants.PureBlackKey
import com.sanmusic.app.ui.screens.artist.ArtistAlbumsScreen
import com.sanmusic.app.ui.screens.artist.ArtistItemsScreen
import com.sanmusic.app.ui.screens.artist.ArtistScreen
import com.sanmusic.app.ui.screens.artist.ArtistSongsScreen
import com.sanmusic.app.ui.screens.equalizer.EqScreen
import com.sanmusic.app.ui.screens.library.LibraryScreen
import com.sanmusic.app.ui.screens.playlist.AutoPlaylistScreen
import com.sanmusic.app.ui.screens.playlist.CachePlaylistScreen
import com.sanmusic.app.ui.screens.playlist.LocalPlaylistScreen
import com.sanmusic.app.ui.screens.playlist.OnlinePlaylistScreen
import com.sanmusic.app.ui.screens.playlist.TopPlaylistScreen
import com.sanmusic.app.ui.screens.ExploreScreen
import com.sanmusic.app.ui.screens.search.OnlineSearchResult
import com.sanmusic.app.ui.screens.search.SearchScreen
import com.sanmusic.app.ui.screens.settings.AboutScreen
import com.sanmusic.app.ui.screens.settings.AppearanceSettings
import com.sanmusic.app.ui.screens.settings.BackupAndRestore
import com.sanmusic.app.ui.screens.settings.ContentSettings
import com.sanmusic.app.ui.screens.settings.DarkMode
import com.sanmusic.app.ui.screens.settings.PlayerSettings
import com.sanmusic.app.ui.screens.settings.AlarmSettingsScreen
import com.sanmusic.app.ui.screens.settings.PrivacySettings
import com.sanmusic.app.ui.screens.settings.RomanizationSettings
import com.sanmusic.app.ui.screens.settings.SettingsScreen
import com.sanmusic.app.ui.screens.settings.StorageSettings
import com.sanmusic.app.ui.screens.settings.ThemeScreen
import com.sanmusic.app.ui.screens.settings.UpdaterScreen
import com.sanmusic.app.ui.screens.settings.AiSettings
import com.sanmusic.app.ui.screens.settings.integrations.DiscordSettings
import com.sanmusic.app.ui.screens.settings.integrations.IntegrationScreen
import com.sanmusic.app.ui.screens.settings.integrations.LastFMSettings
import com.sanmusic.app.ui.screens.settings.integrations.ListenTogetherSettings
import com.sanmusic.app.ui.screens.recognition.RecognitionScreen
import com.sanmusic.app.ui.screens.recognition.RecognitionHistoryScreen
import com.sanmusic.app.ui.screens.wrapped.WrappedScreen
import com.sanmusic.app.poster.PosterScreen
import com.sanmusic.app.utils.rememberEnumPreference
import com.sanmusic.app.utils.rememberPreference

@OptIn(ExperimentalMaterial3Api::class)
fun NavGraphBuilder.navigationBuilder(
    navController: NavHostController,
    scrollBehavior: TopAppBarScrollBehavior,
    latestVersionName: String,
    activity: Activity,
    snackbarHostState: SnackbarHostState
) {
    composable(Screens.Home.route) {
        HomeScreen(navController = navController, snackbarHostState = snackbarHostState)
    }

    composable("search_input") {
        val pureBlackEnabled by rememberPreference(PureBlackKey, defaultValue = true)
        val darkTheme by rememberEnumPreference(DarkModeKey, defaultValue = DarkMode.ON)
        val isSystemInDarkTheme = isSystemInDarkTheme()
        val useDarkTheme = remember(darkTheme, isSystemInDarkTheme) {
            if (darkTheme == DarkMode.AUTO) isSystemInDarkTheme else darkTheme == DarkMode.ON
        }
        val pureBlack = remember(pureBlackEnabled, useDarkTheme) {
            pureBlackEnabled && useDarkTheme
        }
        SearchScreen(
            navController = navController,
            pureBlack = pureBlack
        )
    }

    composable(Screens.Library.route) {
        LibraryScreen(navController)
    }

    composable(Screens.Profile.route) {
        ProfileScreen(navController)
    }

    composable("listen_together") {
        ListenTogetherScreen(navController)
    }

    composable("history") {
        HistoryScreen(navController)
    }

    composable("new_releases") {
        NewReleasesScreen(navController, snackbarHostState)
    }

    composable("stats") {
        StatsScreen(navController)
    }

    composable("poster") {
        PosterScreen(navController)
    }

    composable("mood_and_genres") {
        MoodAndGenresScreen(navController, scrollBehavior)
    }

    composable("podcasts") {
        PodcastsScreen(navController, scrollBehavior)
    }

    composable("mixes") {
        MixesScreen(navController, scrollBehavior)
    }

    composable("top_charts") {
        TopChartsScreen(navController, scrollBehavior)
    }

    composable("account") {
        AccountScreen(navController, scrollBehavior)
    }

    composable("new_release") {
        NewReleaseScreen(navController, scrollBehavior)
    }

    composable("charts_screen") {
        ChartsScreen(navController)
    }

    composable("explore") {
        ExploreScreen(navController)
    }

    composable(
        route = "browse/{browseId}",
        arguments = listOf(
            navArgument("browseId") {
                type = NavType.StringType
            }
        )
    ) {
        BrowseScreen(
            navController,
            scrollBehavior,
            it.arguments?.getString("browseId")
        )
    }

    composable(
        route = "search/{query}",
        arguments = listOf(
            navArgument("query") {
                type = NavType.StringType
            },
        ),
        enterTransition = {
            fadeIn(tween(250))
        },
        exitTransition = {
            if (targetState.destination.route?.startsWith("search/") == true) {
                fadeOut(tween(200))
            } else {
                fadeOut(tween(200)) + slideOutHorizontally { -it / 2 }
            }
        },
        popEnterTransition = {
            if (initialState.destination.route?.startsWith("search/") == true) {
                fadeIn(tween(250))
            } else {
                fadeIn(tween(250)) + slideInHorizontally { -it / 2 }
            }
        },
        popExitTransition = {
            fadeOut(tween(200))
        },
    ) {
        OnlineSearchResult(navController)
    }

    composable(
        route = "album/{albumId}",
        arguments = listOf(
            navArgument("albumId") {
                type = NavType.StringType
            },
        ),
    ) {
        AlbumScreen(navController, scrollBehavior)
    }

    composable(
        route = "artist/{artistId}",
        arguments = listOf(
            navArgument("artistId") {
                type = NavType.StringType
            },
        ),
    ) {
        ArtistScreen(navController, scrollBehavior)
    }

    composable(
        route = "artist/{artistId}/songs",
        arguments = listOf(
            navArgument("artistId") {
                type = NavType.StringType
            },
        ),
    ) {
        ArtistSongsScreen(navController, scrollBehavior)
    }

    composable(
        route = "artist/{artistId}/albums",
        arguments = listOf(
            navArgument("artistId") {
                type = NavType.StringType
            }
        )
    ) {
        ArtistAlbumsScreen(navController, scrollBehavior)
    }

    composable(
        route = "artist/{artistId}/items?browseId={browseId}?params={params}",
        arguments = listOf(
            navArgument("artistId") {
                type = NavType.StringType
            },
            navArgument("browseId") {
                type = NavType.StringType
                nullable = true
            },
            navArgument("params") {
                type = NavType.StringType
                nullable = true
            },
        ),
    ) {
        ArtistItemsScreen(navController, scrollBehavior)
    }

    composable(
        route = "online_playlist/{playlistId}",
        arguments = listOf(
            navArgument("playlistId") {
                type = NavType.StringType
            },
        ),
    ) {
        OnlinePlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "online_podcast/{playlistId}",
        arguments = listOf(
            navArgument("playlistId") {
                type = NavType.StringType
            },
        ),
    ) {
        OnlinePlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "local_playlist/{playlistId}",
        arguments = listOf(
            navArgument("playlistId") {
                type = NavType.StringType
            },
        ),
    ) {
        LocalPlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "auto_playlist/{playlist}",
        arguments = listOf(
            navArgument("playlist") {
                type = NavType.StringType
            },
        ),
    ) {
        AutoPlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "cache_playlist/{playlist}",
        arguments = listOf(
            navArgument("playlist") {
                type = NavType.StringType
            },
        ),
    ) {
        CachePlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "top_playlist/{top}",
        arguments = listOf(
            navArgument("top") {
                type = NavType.StringType
            },
        ),
    ) {
        TopPlaylistScreen(navController, scrollBehavior)
    }

    composable(
        route = "youtube_browse/{browseId}?params={params}",
        arguments = listOf(
            navArgument("browseId") {
                type = NavType.StringType
                nullable = true
            },
            navArgument("params") {
                type = NavType.StringType
                nullable = true
            },
        ),
    ) {
        YouTubeBrowseScreen(navController)
    }

    composable("settings") {
        SettingsScreen(navController, scrollBehavior, latestVersionName)
    }

    composable("settings/appearance") {
        AppearanceSettings(navController, scrollBehavior, activity, snackbarHostState)
    }

    composable("settings/appearance/theme") {
        ThemeScreen(navController)
    }

    composable("settings/content") {
        ContentSettings(navController, scrollBehavior)
    }

    composable("settings/content/romanization") {
        RomanizationSettings(navController, scrollBehavior)
    }

    composable("settings/ai") {
        AiSettings(navController, scrollBehavior)
    }
    
    composable("settings/player") {
        PlayerSettings(navController, scrollBehavior)
    }

    composable("settings/alarm") {
        AlarmSettingsScreen(navController, scrollBehavior)
    }

    composable("settings/storage") {
        StorageSettings(navController, scrollBehavior)
    }

    composable("settings/privacy") {
        PrivacySettings(navController, scrollBehavior)
    }

    composable("settings/backup_restore") {
        BackupAndRestore(navController, scrollBehavior)
    }

    composable("settings/integrations") {
        IntegrationScreen(navController, scrollBehavior)
    }

    composable("settings/integrations/discord") {
        DiscordSettings(navController, scrollBehavior)
    }

    composable("settings/integrations/lastfm") {
        LastFMSettings(navController, scrollBehavior)
    }

    composable(route = "settings/integrations/listen_together") {
        ListenTogetherSettings(navController, scrollBehavior)
    }


    composable("settings/updater") {
        UpdaterScreen(navController, scrollBehavior)
    }

    composable("settings/about") {
        AboutScreen(navController, scrollBehavior)
    }

    composable("login") {
        LoginScreen(navController)
    }

    composable("wrapped") {
        WrappedScreen(navController)
    }

    dialog(
        route = "equalizer",
        dialogProperties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
    ) {
        EqScreen()
    }

    composable("recognition") {
        RecognitionScreen(navController)
    }

    composable("recognition_history") {
        RecognitionHistoryScreen(navController)
    }
}
