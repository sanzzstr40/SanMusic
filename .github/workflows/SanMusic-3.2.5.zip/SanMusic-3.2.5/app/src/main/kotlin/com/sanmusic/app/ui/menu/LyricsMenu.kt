/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.ui.menu

import android.app.SearchManager
import android.content.Intent
import android.content.res.Configuration
import android.widget.Toast
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import com.sanmusic.app.LocalDatabase
import com.sanmusic.app.LocalPlayerConnection
import com.sanmusic.app.R
import com.sanmusic.app.db.entities.LyricsEntity
import com.sanmusic.app.db.entities.SongEntity
import com.sanmusic.app.lyrics.LyricsUtils
import com.sanmusic.app.models.MediaMetadata
import com.sanmusic.app.ui.component.LyricVideoCreationDialog
import com.sanmusic.app.ui.component.DefaultDialog
import com.sanmusic.app.ui.component.ListDialog
import com.sanmusic.app.ui.component.Material3MenuGroup
import com.sanmusic.app.ui.component.Material3MenuItemData
import com.sanmusic.app.ui.component.NewAction
import com.sanmusic.app.ui.component.NewActionGrid
import com.sanmusic.app.ui.component.TextFieldDialog
import com.sanmusic.app.viewmodels.LyricsMenuViewModel
import com.sanmusic.app.constants.AutoTranslateLyricsKey
import com.sanmusic.app.constants.LyricsTranslationProviderKey
import com.sanmusic.app.constants.OpenRouterApiKey
import com.sanmusic.app.lyrics.LyricsTranslationHelper
import com.sanmusic.app.ui.component.EnumDialog
import com.sanmusic.app.utils.rememberEnumPreference
import com.sanmusic.app.utils.rememberPreference

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LyricsMenu(
    lyricsProvider: () -> LyricsEntity?,
    songProvider: () -> SongEntity?,
    mediaMetadataProvider: () -> MediaMetadata,
    onDismiss: () -> Unit,
    onShowOffsetDialog: () -> Unit = {},
    viewModel: LyricsMenuViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    val database = LocalDatabase.current
    
    var autoTranslateLyrics by rememberPreference(AutoTranslateLyricsKey, true)
    val openRouterApiKey by rememberPreference(OpenRouterApiKey, "")
    var lyricsTranslationProvider by rememberPreference(LyricsTranslationProviderKey, "Auto")

    val translationProviders = listOf(
        "Auto",
        "Google",
        "Google (Clients5)",
        "MyMemory",
        "AI Kustom"
    )

    var showTranslationProviderDialog by rememberSaveable {
        mutableStateOf(false)
    }

    if (showTranslationProviderDialog) {
        EnumDialog(
            onDismiss = { showTranslationProviderDialog = false },
            onSelect = {
                lyricsTranslationProvider = it
                showTranslationProviderDialog = false
                LyricsTranslationHelper.clearCache()
                LyricsTranslationHelper.triggerManualTranslation()
            },
            title = "Penyedia Terjemahan Lirik",
            current = lyricsTranslationProvider,
            values = translationProviders,
            valueText = { provider ->
                when (provider) {
                    "Auto" -> "Otomatis (Multi-Provider Fallback - Rekomendasi)"
                    "Google" -> "Google Translate (translate.googleapis.com)"
                    "Google (Clients5)" -> "Google Translate (Mirror clients5)"
                    "MyMemory" -> "MyMemory Translate API"
                    "AI Kustom" -> "Model AI Kustom (OpenRouter / LLM)"
                    else -> provider
                }
            }
        )
    }


    var showEditDialog by rememberSaveable {
        mutableStateOf(false)
    }

    if (showEditDialog) {
        TextFieldDialog(
            onDismiss = { showEditDialog = false },
            icon = { Icon(painter = painterResource(R.drawable.edit), contentDescription = null) },
            title = { Text(text = mediaMetadataProvider().title) },
            initialTextFieldValue = TextFieldValue(lyricsProvider()?.lyrics.orEmpty()),
            singleLine = false,
            onDone = {
                database.query {
                    upsert(
                        LyricsEntity(
                            id = mediaMetadataProvider().id,
                            lyrics = it,
                            provider = lyricsProvider()?.provider ?: "Manual",
                        ),
                    )
                }
            },
        )
    }

    var showLyricVideoDialog by rememberSaveable {
        mutableStateOf(false)
    }

    if (showLyricVideoDialog) {
        val rawLyrics = lyricsProvider()?.lyrics.orEmpty()
        val parsedEntries = remember(rawLyrics) {
            if (rawLyrics.isNotBlank()) LyricsUtils.parseLyrics(rawLyrics) else emptyList()
        }
        val playerConnection = LocalPlayerConnection.current
        val currentPosition = playerConnection?.player?.currentPosition ?: 0L

        LyricVideoCreationDialog(
            mediaMetadata = mediaMetadataProvider(),
            lyrics = parsedEntries,
            currentPlaybackPositionMs = currentPosition,
            onDismiss = { showLyricVideoDialog = false }
        )
    }

    var showSearchDialog by rememberSaveable {
        mutableStateOf(false)
    }
    var showSearchResultDialog by rememberSaveable {
        mutableStateOf(false)
    }

    val searchMediaMetadata =
        remember(showSearchDialog) {
            mediaMetadataProvider()
        }
    val (titleField, onTitleFieldChange) =
        rememberSaveable(showSearchDialog, stateSaver = TextFieldValue.Saver) {
            mutableStateOf(
                TextFieldValue(
                    text = mediaMetadataProvider().title,
                ),
            )
        }
    val (artistField, onArtistFieldChange) =
        rememberSaveable(showSearchDialog, stateSaver = TextFieldValue.Saver) {
            mutableStateOf(
                TextFieldValue(
                    text = mediaMetadataProvider().artists.joinToString { it.name },
                ),
            )
        }

    val isNetworkAvailable by viewModel.isNetworkAvailable.collectAsState()

    if (showSearchDialog) {
        DefaultDialog(
            modifier = Modifier.verticalScroll(rememberScrollState()),
            onDismiss = { showSearchDialog = false },
            icon = {
                Icon(
                    painter = painterResource(R.drawable.search),
                    contentDescription = null
                )
            },
            title = { Text(stringResource(R.string.search_lyrics)) },
            buttons = {
                TextButton(
                    onClick = { showSearchDialog = false },
                ) {
                    Text(stringResource(android.R.string.cancel))
                }

                Spacer(Modifier.width(8.dp))

                TextButton(
                    onClick = {
                        showSearchDialog = false
                        onDismiss()
                        try {
                            context.startActivity(
                                Intent(Intent.ACTION_WEB_SEARCH).apply {
                                    putExtra(
                                        SearchManager.QUERY,
                                        "${artistField.text} ${titleField.text} lyrics"
                                    )
                                },
                            )
                        } catch (_: Exception) {
                        }
                    },
                ) {
                    Text(stringResource(R.string.search_online))
                }

                Spacer(Modifier.width(8.dp))

                TextButton(
                    onClick = {
                        // Try search regardless of network status indicator
                        // as it might be a false negative
                        viewModel.search(
                            searchMediaMetadata.id,
                            titleField.text,
                            artistField.text,
                            searchMediaMetadata.duration,
                            searchMediaMetadata.album?.title
                        )
                        showSearchResultDialog = true
                        
                        // Show warning only if network is definitely unavailable
                        if (!isNetworkAvailable) {
                            Toast.makeText(context, context.getString(R.string.error_no_internet), Toast.LENGTH_SHORT).show()
                        }
                    },
                ) {
                    Text(stringResource(android.R.string.ok))
                }
            },
        ) {
            OutlinedTextField(
                value = titleField,
                onValueChange = onTitleFieldChange,
                singleLine = true,
                label = { Text(stringResource(R.string.song_title)) },
            )

            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = artistField,
                onValueChange = onArtistFieldChange,
                singleLine = true,
                label = { Text(stringResource(R.string.song_artists)) },
            )
        }
    }

    if (showSearchResultDialog) {
        val results by viewModel.results.collectAsState()
        val isLoading by viewModel.isLoading.collectAsState()

        var expandedItemIndex by rememberSaveable {
            mutableIntStateOf(-1)
        }

        ListDialog(
            onDismiss = { showSearchResultDialog = false },
        ) {
            itemsIndexed(results) { index, result ->
                Row(
                    modifier =
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            onDismiss()
                            viewModel.cancelSearch()
                            database.query {
                                upsert(
                                    LyricsEntity(
                                        id = searchMediaMetadata.id,
                                        lyrics = result.lyrics,
                                        provider = result.providerName,
                                    ),
                                )
                            }
                        }
                        .padding(12.dp)
                        .animateContentSize(),
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(
                            text = result.lyrics,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = if (index == expandedItemIndex) Int.MAX_VALUE else 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(bottom = 4.dp),
                        )

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = result.providerName,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.secondary,
                                maxLines = 1,
                            )
                            if (result.lyrics.startsWith("[")) {
                                Icon(
                                    painter = painterResource(R.drawable.sync),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier =
                                    Modifier
                                        .padding(start = 4.dp)
                                        .size(18.dp),
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = {
                            expandedItemIndex = if (expandedItemIndex == index) -1 else index
                        },
                    ) {
                        Icon(
                            painter = painterResource(if (index == expandedItemIndex) R.drawable.expand_less else R.drawable.expand_more),
                            contentDescription = null,
                        )
                    }
                }
            }

            if (isLoading) {
                item {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        CircularProgressIndicator()
                    }
                }
            }

            if (!isLoading && results.isEmpty()) {
                item {
                    Text(
                        text = context.getString(R.string.lyrics_not_found),
                        textAlign = TextAlign.Center,
                        modifier =
                        Modifier
                            .fillMaxWidth(),
                    )
                }
            }
        }
    }

    var showRomanizationDialog by rememberSaveable {
        mutableStateOf(false)
    }

    var showRomanization by rememberSaveable { mutableStateOf(false) }
    var isChecked by remember { mutableStateOf(songProvider()?.romanizeLyrics ?: true) }

    var lyricsOffset by rememberSaveable { mutableIntStateOf(songProvider()?.lyricsOffset ?: 0) }

    // Sync isChecked with song changes
    LaunchedEffect(songProvider()) {
        isChecked = songProvider()?.romanizeLyrics ?: true
    }

    LaunchedEffect(songProvider()) {
        lyricsOffset = songProvider()?.lyricsOffset ?: 0
    }

    val configuration = LocalConfiguration.current
    val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT

    LazyColumn(
        contentPadding = PaddingValues(
            start = 0.dp,
            top = 0.dp,
            end = 0.dp,
            bottom = 8.dp + WindowInsets.systemBars.asPaddingValues().calculateBottomPadding(),
        ),
    ) {
        item {
            NewActionGrid(
                actions = listOf(
                    NewAction(
                        icon = {
                            Icon(
                                painter = painterResource(R.drawable.edit),
                                contentDescription = null,
                                modifier = Modifier.size(28.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        text = stringResource(R.string.edit),
                        onClick = {
                            showEditDialog = true
                        }
                    ),
                    NewAction(
                        icon = {
                            Icon(
                                painter = painterResource(R.drawable.cached),
                                contentDescription = null,
                                modifier = Modifier.size(28.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        text = stringResource(R.string.refetch),
                        onClick = {
                            onDismiss()
                            viewModel.refetchLyrics(mediaMetadataProvider(), lyricsProvider())
                        }
                    ),
                    NewAction(
                        icon = {
                            Icon(
                                painter = painterResource(R.drawable.search),
                                contentDescription = null,
                                modifier = Modifier.size(28.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        text = stringResource(R.string.search),
                        onClick = {
                            showSearchDialog = true
                        }
                    )
                ),
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 16.dp)
            )
        }

        item {
            val playerConnection = LocalPlayerConnection.current
            val (preferredLyricsProvider, _) = rememberEnumPreference(
                key = com.sanmusic.app.constants.PreferredLyricsProviderKey,
                defaultValue = com.sanmusic.app.constants.PreferredLyricsProvider.SIMPMUSIC
            )
            var showProviderSwitcherDialog by rememberSaveable { mutableStateOf(false) }

            if (showProviderSwitcherDialog) {
                com.sanmusic.app.ui.component.LyricsProviderSwitcherDialog(
                    currentPreferred = preferredLyricsProvider,
                    activeLoadedProviderName = lyricsProvider()?.provider,
                    onSelectProvider = { newProvider ->
                        showProviderSwitcherDialog = false
                        onDismiss()
                        com.sanmusic.app.ui.component.LyricsProviderSwitchState.switchProviderAsync(
                            context = context,
                            database = database,
                            playerConnection = playerConnection,
                            mediaMetadata = mediaMetadataProvider(),
                            newProvider = newProvider,
                            showToast = true
                        )
                    },
                    onDismiss = { showProviderSwitcherDialog = false }
                )
            }

            Material3MenuGroup(
                items = buildList {
                    add(
                        Material3MenuItemData(
                            title = { Text("Ganti Penyedia Lirik") },
                            description = {
                                val activeLoaded = lyricsProvider()?.provider?.takeIf { it != "Unknown" }
                                val prefName = com.sanmusic.app.lyrics.LyricsHelper.displayNameOf(preferredLyricsProvider)
                                Text(
                                    if (activeLoaded != null) "Utama: $prefName • Aktif: $activeLoaded"
                                    else "Utama: $prefName (Tanpa hapus cache)"
                                )
                            },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.lyrics),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                showProviderSwitcherDialog = true
                            }
                        )
                    )

                    add(
                        Material3MenuItemData(
                            title = { Text("Buat Video Lirik") },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.movie),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                showLyricVideoDialog = true
                            }
                        )
                    )

                    add(
                        Material3MenuItemData(
                            title = { Text("Terjemahan Lirik Otomatis") },
                            description = {
                                Text(
                                    if (openRouterApiKey.isNotBlank()) "Menggunakan API Key AI Kustom"
                                    else "Penyedia: $lyricsTranslationProvider"
                                )
                            },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.translate),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                autoTranslateLyrics = !autoTranslateLyrics
                            },
                            trailingContent = {
                                Switch(
                                    checked = autoTranslateLyrics,
                                    onCheckedChange = { autoTranslateLyrics = it }
                                )
                            }
                        )
                    )

                    add(
                        Material3MenuItemData(
                            title = { Text("Penyedia Terjemahan") },
                            description = {
                                Text(
                                    when (lyricsTranslationProvider) {
                                        "Auto" -> "Otomatis (Multi-Provider Fallback)"
                                        "Google" -> "Google Translate"
                                        "Google (Clients5)" -> "Google Translate (Mirror clients5)"
                                        "MyMemory" -> "MyMemory Translate API"
                                        "AI Kustom" -> "Model AI Kustom (${if (openRouterApiKey.isNotBlank()) "Aktif" else "Kunci Kosong"})"
                                        else -> lyricsTranslationProvider
                                    }
                                )
                            },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.language),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                showTranslationProviderDialog = true
                            }
                        )
                    )

                    add(
                        Material3MenuItemData(
                            title = { Text(stringResource(R.string.ai_lyrics_translation)) },
                            description = {
                                Text("Terjemahkan ulang dengan $lyricsTranslationProvider")
                            },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.translate),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                autoTranslateLyrics = true
                                onDismiss()
                                LyricsTranslationHelper.clearCache()
                                LyricsTranslationHelper.triggerManualTranslation()
                            },
                        )
                    )
                    
                    add(
                        Material3MenuItemData(
                            title = { Text(stringResource(R.string.lyrics_offset)) },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.fast_forward),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                onDismiss()
                                onShowOffsetDialog()
                            },
                            trailingContent = {
                                Text(
                                    text = "${if (lyricsOffset >= 0) "+" else ""}${lyricsOffset}ms",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        )
                    )
                    
                    add(
                        Material3MenuItemData(
                            title = { Text(text = stringResource(R.string.romanize_current_track)) },
                            icon = {
                                Icon(
                                    painter = painterResource(R.drawable.language_korean_latin),
                                    contentDescription = null,
                                )
                            },
                            onClick = {
                                isChecked = !isChecked
                                songProvider()?.let { song ->
                                    database.query {
                                        upsert(song.copy(romanizeLyrics = isChecked))
                                    }
                                }
                            },
                            trailingContent = {
                                Switch(
                                    checked = isChecked,
                                    onCheckedChange = { newCheckedState ->
                                        isChecked = newCheckedState
                                        songProvider()?.let { song ->
                                            database.query {
                                                upsert(song.copy(romanizeLyrics = newCheckedState))
                                            }
                                        }
                                    }
                                )
                            }
                        )
                    )
                }
            )
        }
    }
    
    /* if (showRomanizationDialog) {
        var isChecked by remember { mutableStateOf(songProvider()?.romanizeLyrics ?: true) }

        // Sync with song changes
        LaunchedEffect(songProvider()) {
            isChecked = songProvider()?.romanizeLyrics ?: true
        }

        DefaultDialog(
            onDismiss = { showRomanizationDialog = false },
            title = { Text(stringResource(R.string.romanization)) }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        // Toggle isChecked when the row is clicked
                        isChecked = !isChecked
                        songProvider()?.let { song ->
                            database.query {
                                upsert(song.copy(romanizeLyrics = isChecked))
                            }
                        }
                    }
                    .padding(vertical = 8.dp, horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.romanize_current_track),
                    modifier = Modifier.weight(1f)
                )
                Switch(
                    checked = isChecked,
                    onCheckedChange = { newCheckedState ->
                        isChecked = newCheckedState
                        songProvider()?.let { song ->
                            database.query {
                                upsert(song.copy(romanizeLyrics = newCheckedState))
                            }
                        }
                    }
                )
            }
        }
    } */
}
