/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.ui.screens.settings

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.navigation.NavController
import com.sanmusic.app.LocalPlayerAwareWindowInsets
import com.sanmusic.app.R
import com.sanmusic.app.db.entities.Song
import com.sanmusic.app.streak.MusicJourneyManager
import com.sanmusic.app.ui.component.HomeStreakCard
import com.sanmusic.app.ui.component.IconButton
import com.sanmusic.app.ui.component.Material3SettingsGroup
import com.sanmusic.app.ui.component.Material3SettingsItem
import com.sanmusic.app.ui.menu.AddToPlaylistDialogOnline
import com.sanmusic.app.ui.menu.CsvColumnMappingDialog
import com.sanmusic.app.ui.menu.CsvImportProgressDialog
import com.sanmusic.app.ui.menu.LoadingScreen
import com.sanmusic.app.ui.utils.backToMain
import com.sanmusic.app.viewmodels.BackupRestoreViewModel
import com.sanmusic.app.viewmodels.ConvertedSongLog
import com.sanmusic.app.viewmodels.CsvImportState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupAndRestore(
    navController: NavController,
    scrollBehavior: TopAppBarScrollBehavior,
    viewModel: BackupRestoreViewModel = hiltViewModel(),
) {
    var importedTitle by remember { mutableStateOf("") }
    val importedSongs = remember { mutableStateListOf<Song>() }
    var showChoosePlaylistDialogOnline by rememberSaveable {
        mutableStateOf(false)
    }

    var isProgressStarted by rememberSaveable {
        mutableStateOf(false)
    }

    var progressPercentage by rememberSaveable {
        mutableIntStateOf(0)
    }

    // CSV column mapping state
    var csvImportState by remember { mutableStateOf<CsvImportState?>(null) }
    var showCsvColumnMapping by rememberSaveable { mutableStateOf(false) }
    var showCsvImportProgress by rememberSaveable { mutableStateOf(false) }
    var csvImportProgress by rememberSaveable { mutableIntStateOf(0) }
    val csvRecentLogs = remember { mutableStateListOf<ConvertedSongLog>() }
    var pendingCsvUri by remember { mutableStateOf<android.net.Uri?>(null) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val backupLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
            if (uri != null) {
                viewModel.backup(context, uri)
            }
        }
    val restoreLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                viewModel.restore(context, uri)
            }
        }
    val exportStatsLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
            if (uri != null) {
                coroutineScope.launch {
                    val ok = MusicJourneyManager.exportAllStatsToUri(context, uri)
                    Toast.makeText(
                        context,
                        if (ok) "Semua statistik berhasil dicadangkan ke file!" else "Gagal mencadangkan statistik",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    val importStatsLauncher =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                coroutineScope.launch {
                    val ok = MusicJourneyManager.importAllStatsFromUri(context, uri)
                    Toast.makeText(
                        context,
                        if (ok) "Semua statistik berhasil dipulihkan dari file!" else "File statistik tidak valid",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    val importPlaylistFromCsv =
        rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri == null) return@rememberLauncherForActivityResult
            pendingCsvUri = uri
            val previewState = viewModel.previewCsvFile(context, uri)
            csvImportState = previewState
            showCsvColumnMapping = true
        }
    val importM3uLauncherOnline = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val result = viewModel.loadM3UOnline(context, uri)
        importedSongs.clear()
        importedSongs.addAll(result)

        if (importedSongs.isNotEmpty()) {
            showChoosePlaylistDialogOnline = true
        }
    }

    Column(
        Modifier
            .windowInsetsPadding(LocalPlayerAwareWindowInsets.current.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
    ) {
        Spacer(
            Modifier.windowInsetsPadding(
                LocalPlayerAwareWindowInsets.current.only(
                    WindowInsetsSides.Top
                )
            )
        )

        HomeStreakCard(
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Material3SettingsGroup(
            items = listOf(
                Material3SettingsItem(
                    title = { Text(stringResource(R.string.action_backup)) },
                    description = { Text("Termasuk database, pengaturan, profil, dan seluruh statistik musik") },
                    icon = painterResource(R.drawable.backup),
                    onClick = {
                        val formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
                        backupLauncher.launch(
                            "${context.getString(R.string.app_name)}_${
                                LocalDateTime.now().format(formatter)
                            }.backup"
                        )
                    },
                ),
                Material3SettingsItem(
                    title = { Text(stringResource(R.string.action_restore)) },
                    description = { Text("Pulihkan database, pengaturan, profil, dan seluruh statistik dari file .backup") },
                    icon = painterResource(R.drawable.restore),
                    onClick = {
                        restoreLauncher.launch(arrayOf("application/octet-stream", "*/*"))
                    },
                ),
                Material3SettingsItem(
                    title = { Text("Cadangkan Semua Statistik (.json)") },
                    description = { Text("Simpan Streak, Level XP, Rekor Harian/Bulanan, Ringkasan, & Top Lagu ke file") },
                    icon = painterResource(R.drawable.backup),
                    onClick = {
                        val formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmm")
                        exportStatsLauncher.launch(
                            "Statistik_Musik_${LocalDateTime.now().format(formatter)}.json"
                        )
                    },
                ),
                Material3SettingsItem(
                    title = { Text("Pulihkan Semua Statistik (.json / .backup)") },
                    description = { Text("Muat kembali seluruh statistik perjalanan musik dari file cadangan") },
                    icon = painterResource(R.drawable.restore),
                    onClick = {
                        importStatsLauncher.launch(arrayOf("application/json", "application/octet-stream", "*/*"))
                    },
                ),
                Material3SettingsItem(
                    title = { Text(stringResource(R.string.import_online)) },
                    icon = painterResource(R.drawable.playlist_add),
                    onClick = {
                        importM3uLauncherOnline.launch(arrayOf("audio/*"))
                    }
                ),
                Material3SettingsItem(
                    title = { Text(stringResource(R.string.import_csv)) },
                    icon = painterResource(R.drawable.playlist_add),
                    onClick = {
                        importPlaylistFromCsv.launch(arrayOf("text/csv", "text/comma-separated-values", "application/csv", "text/plain"))
                    }
                )
            )
        )
    }

    TopAppBar(
        title = { Text(stringResource(R.string.backup_restore)) },
        navigationIcon = {
            IconButton(
                onClick = navController::navigateUp,
                onLongClick = navController::backToMain,
            ) {
                Icon(
                    painterResource(R.drawable.arrow_back),
                    contentDescription = null,
                )
            }
        }
    )

    AddToPlaylistDialogOnline(
        isVisible = showChoosePlaylistDialogOnline,
        allowSyncing = false,
        initialTextFieldValue = importedTitle,
        songs = importedSongs,
        onDismiss = { showChoosePlaylistDialogOnline = false },
        onProgressStart = { newVal -> isProgressStarted = newVal },
        onPercentageChange = { newPercentage -> progressPercentage = newPercentage }
    )

    LaunchedEffect(progressPercentage, isProgressStarted) {
        if (isProgressStarted && progressPercentage == 99) {
            delay(10000)
            if (progressPercentage == 99) {
                isProgressStarted = false
                progressPercentage = 0
            }
        }
    }

    LoadingScreen(
        isVisible = isProgressStarted,
        value = progressPercentage,
    )

    // CSV column mapping dialog
    csvImportState?.let { state ->
        CsvColumnMappingDialog(
            isVisible = showCsvColumnMapping,
            csvState = state,
            onDismiss = {
                showCsvColumnMapping = false
                csvImportState = null
            },
            onConfirm = { mappingState ->
                showCsvColumnMapping = false
                csvImportState = mappingState
                pendingCsvUri?.let { uri ->
                    showCsvImportProgress = true
                    coroutineScope.launch(Dispatchers.Default) {
                        val result = viewModel.importPlaylistFromCsv(
                            context,
                            uri,
                            mappingState,
                            onProgress = { progress ->
                                csvImportProgress = progress
                            },
                            onLogUpdate = { logs ->
                                csvRecentLogs.clear()
                                csvRecentLogs.addAll(logs)
                            },
                        )
                        importedSongs.clear()
                        importedSongs.addAll(result)
                        if (result.isNotEmpty()) {
                            showCsvImportProgress = false
                            csvImportProgress = 0
                            csvRecentLogs.clear()
                            showChoosePlaylistDialogOnline = true
                        }
                    }
                }
            },
        )
    }

    // CSV import progress dialog
    CsvImportProgressDialog(
        isVisible = showCsvImportProgress,
        progress = csvImportProgress,
        recentLogs = csvRecentLogs.toList(),
        onDismiss = {
            // Cannot dismiss while importing
        },
    )
}

