/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.ui.screens.wrapped

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class WrappedViewModel @Inject constructor() : ViewModel()
