/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.ui.utils

import androidx.navigation.NavController
import com.sanmusic.app.ui.screens.Screens

fun NavController.backToMain() {
    val mainRoutes = Screens.MainScreens.mapNotNull { it?.route }

    while (previousBackStackEntry != null &&
        currentBackStackEntry?.destination?.route !in mainRoutes
    ) {
        popBackStack()
    }
}
