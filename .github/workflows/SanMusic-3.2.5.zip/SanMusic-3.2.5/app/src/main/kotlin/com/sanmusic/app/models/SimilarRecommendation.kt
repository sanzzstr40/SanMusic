/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.models

import com.sanmusic.innertube.models.YTItem
import com.sanmusic.app.db.entities.LocalItem

data class SimilarRecommendation(
    val title: LocalItem,
    val items: List<YTItem>,
)
