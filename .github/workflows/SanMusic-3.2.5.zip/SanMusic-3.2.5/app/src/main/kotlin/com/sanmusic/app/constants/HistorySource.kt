/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.constants

enum class HistorySource {
    LOCAL, REMOTE
}
