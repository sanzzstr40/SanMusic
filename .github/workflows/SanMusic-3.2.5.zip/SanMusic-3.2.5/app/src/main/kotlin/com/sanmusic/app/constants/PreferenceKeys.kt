/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.constants

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import java.time.LocalDateTime
import java.time.ZoneOffset

val EnableDynamicIconKey = booleanPreferencesKey("enableDynamicIcon")
val EnableHighRefreshRateKey = booleanPreferencesKey("enableHighRefreshRate")
val DynamicThemeKey = booleanPreferencesKey("dynamicTheme")
val SelectedThemeColorKey = intPreferencesKey("selectedThemeColor")
val SelectedFontKey = stringPreferencesKey("selectedFont")
val FontScaleKey = floatPreferencesKey("fontScale")
val FontBoldnessKey = floatPreferencesKey("fontBoldness")
val DarkModeKey = stringPreferencesKey("darkMode")
val SoftLightModeKey = booleanPreferencesKey("softLightMode")
val AppVisualStyleKey = stringPreferencesKey("appVisualStyle")

enum class AppVisualStyle(val title: String, val subtitle: String) {
    LIQUID_GLASS("Liquid Glass", "Glass Ringan & Bening"),
    EDITORIAL("Editorial", "Tipografi Majalah & Garis Tegas"),
}

val PureBlackKey = booleanPreferencesKey("pureBlack")
val PureBlackMiniPlayerKey = booleanPreferencesKey("pureBlackMiniPlayer")
val MiniPlayerOutlineKey = booleanPreferencesKey("miniPlayerOutline")
val DefaultOpenTabKey = stringPreferencesKey("defaultOpenTab")
val SlimNavBarKey = booleanPreferencesKey("slimNavBar")
val ListenTogetherAtTopKey = booleanPreferencesKey("listenTogetherAtTop")
val GridItemsSizeKey = stringPreferencesKey("gridItemSize")
val SliderStyleKey = stringPreferencesKey("sliderStyle")
val SquigglySliderKey = booleanPreferencesKey("squigglySlider")
val SwipeToSongKey = booleanPreferencesKey("SwipeToSong")
val SwipeToRemoveSongKey = booleanPreferencesKey("SwipeToRemoveSong")
val HomeSectionOrderKey = stringPreferencesKey("homeSectionOrder")
val UseNewPlayerDesignKey= booleanPreferencesKey("useNewPlayerDesign")
val UseNewMiniPlayerDesignKey = booleanPreferencesKey("useNewMiniPlayerDesign")
val MiniPlayerBallModeKey = booleanPreferencesKey("miniPlayerBallMode")
val StreakCountKey = intPreferencesKey("musicStreakCount")
val StreakLastListenEpochDayKey = longPreferencesKey("musicStreakLastListenEpochDay")
val StreakLongestKey = intPreferencesKey("musicStreakLongest")
val StreakHistoryEpochDaysKey = stringPreferencesKey("musicStreakHistoryEpochDays")
val StreakCustomFlamesJsonKey = stringPreferencesKey("musicStreakCustomFlamesJson")
val StreakSelectedFlameIdKey = stringPreferencesKey("musicStreakSelectedFlameId")
val StreakFreezeResetKey = booleanPreferencesKey("musicStreakFreezeReset")
val StreakCustomApiUrlKey = stringPreferencesKey("musicStreakCustomApiUrl")
val StreakCustomApiKeyKey = stringPreferencesKey("musicStreakCustomApiKey")
val ProfileLocalNameKey = stringPreferencesKey("profileLocalName")
val ProfileLocalHandleKey = stringPreferencesKey("profileLocalHandle")
val ProfileLocalBioKey = stringPreferencesKey("profileLocalBio")
val ProfileLocalAvatarUriKey = stringPreferencesKey("profileLocalAvatarUri")
val ProfileJourneyJsonKey = stringPreferencesKey("profileJourneyJson")
val ProfileLocalNameV2Key = stringPreferencesKey("profileLocalNameV2")
val ProfileLocalHandleV2Key = stringPreferencesKey("profileLocalHandleV2")
val ProfileLocalBioV2Key = stringPreferencesKey("profileLocalBioV2")
val ProfileLocalAvatarUriV2Key = stringPreferencesKey("profileLocalAvatarUriV2")
val ProfileLocalBannerUriKey = stringPreferencesKey("profileLocalBannerUri")
val ProfileLocalBannerIsVideoKey = booleanPreferencesKey("profileLocalBannerIsVideo")
val ProfileJourneyJsonV2Key = stringPreferencesKey("profileJourneyJsonV2")
val StreakInitializedZeroV2Key = booleanPreferencesKey("streakInitializedZeroV2")
val HidePlayerThumbnailKey = booleanPreferencesKey("hidePlayerThumbnail")
val CropAlbumArtKey = booleanPreferencesKey("cropAlbumArt")
val SeekExtraSeconds = booleanPreferencesKey("seekExtraSeconds")
val PauseOnMute = booleanPreferencesKey("pauseOnMute")
val KeepScreenOn = booleanPreferencesKey("keepScreenOn")
val DeveloperModeKey = booleanPreferencesKey("developerMode")
val EnableVoiceCommandsKey = booleanPreferencesKey("enableVoiceCommands")
val EnableVoiceWakeWordKey = booleanPreferencesKey("enableVoiceWakeWord")
val VoiceWakeWordKey = stringPreferencesKey("voiceWakeWord")

// Music Alarm
val AlarmEnabledKey = booleanPreferencesKey("alarmEnabled")
val AlarmHourKey = intPreferencesKey("alarmHour")
val AlarmMinuteKey = intPreferencesKey("alarmMinute")
val AlarmRepeatDailyKey = booleanPreferencesKey("alarmRepeatDaily")
val AlarmSongIdsKey = stringPreferencesKey("alarmSongIds")
val AlarmSourceKey = stringPreferencesKey("alarmSource")
val AlarmVibrateKey = booleanPreferencesKey("alarmVibrate")
val AlarmVolumeKey = floatPreferencesKey("alarmVolume")
val AlarmShuffleKey = booleanPreferencesKey("alarmShuffle")
val AlarmSnoozeMinutesKey = intPreferencesKey("alarmSnoozeMinutes")
val AlarmFadeInKey = booleanPreferencesKey("alarmFadeIn")

enum class SliderStyle {
    DEFAULT,
    WAVY,
    SLIM,
    LIQUID,
    VISUALIZER
}

const val SYSTEM_DEFAULT = "SYSTEM_DEFAULT"
val AppLanguageKey = stringPreferencesKey("appLanguage")
val ContentLanguageKey = stringPreferencesKey("contentLanguage")
val ContentCountryKey = stringPreferencesKey("contentCountry")
val EnableKugouKey = booleanPreferencesKey("enableKugou")
val EnableLrcLibKey = booleanPreferencesKey("enableLrclib")
val EnableBetterLyricsKey = booleanPreferencesKey("enableBetterLyrics")
val EnableRushLyricsKey = booleanPreferencesKey("enableRushLyrics")
val EnableSimpMusicKey = booleanPreferencesKey("enableSimpMusic")
val EnablePaxsenixKey = booleanPreferencesKey("enablePaxsenix")
val EnableMusixmatchKey = booleanPreferencesKey("enableMusixmatch")
val HideExplicitKey = booleanPreferencesKey("hideExplicit")
val HideVideoSongsKey = booleanPreferencesKey("hideVideoSongs")
val HideYoutubeShortsKey = booleanPreferencesKey("hideYoutubeShorts")
val ShowArtistDescriptionKey = booleanPreferencesKey("showArtistDescription")
val ShowArtistSubscriberCountKey = booleanPreferencesKey("showArtistSubscriberCount")
val ShowMonthlyListenersKey = booleanPreferencesKey("showMonthlyListeners")
val ProxyEnabledKey = booleanPreferencesKey("proxyEnabled")
val ProxyUrlKey = stringPreferencesKey("proxyUrl")
val ProxyTypeKey = stringPreferencesKey("proxyType")
val ProxyUsernameKey = stringPreferencesKey("proxyUsername")
val ProxyPasswordKey = stringPreferencesKey("proxyPassword")
val YtmSyncKey = booleanPreferencesKey("ytmSync")
val SelectedYtmPlaylistsKey = stringPreferencesKey("selectedYtmPlaylists")
val CheckForUpdatesKey = booleanPreferencesKey("checkForUpdates")
val DismissedUpdateVersionCodeKey = intPreferencesKey("dismissedUpdateVersionCode")
val UpdateNotificationsEnabledKey = booleanPreferencesKey("updateNotifications")
val NewReleaseNotificationsEnabledKey = booleanPreferencesKey("newReleaseNotifications")
val LastSeenSubscribedReleaseIdsKey = stringPreferencesKey("lastSeenSubscribedReleaseIds")
val UpdateVariantKey = stringPreferencesKey("updateVariant")
val UpdateArchitectureKey = stringPreferencesKey("updateArchitecture")
val LastSeenVersionKey = stringPreferencesKey("last_seen_version")
val LastUpdateCheckTimeKey = longPreferencesKey("lastUpdateCheckTime")

val AudioQualityKey = stringPreferencesKey("audioQuality")

enum class AudioQuality {
    AUTO,
    HIGH,
    LOW,
}

enum class VideoQuality {
    QUALITY_360P,
    QUALITY_480P,
    QUALITY_720P,
    QUALITY_1080P
}

val VideoQualityKey = stringPreferencesKey("videoQuality")
val VideoFitModeKey = intPreferencesKey("videoFitMode")
val VideoAutoplayEnabledKey = booleanPreferencesKey("videoAutoplayEnabled")

val SubtitlesEnabledKey = booleanPreferencesKey("subtitlesEnabled")
val SubtitleLanguageKey = stringPreferencesKey("subtitleLanguage")
val SubtitleFontSizeKey = floatPreferencesKey("subtitleFontSize")

val AudioOffload = booleanPreferencesKey("enableOffload")

val VideoModeEnabledKey = booleanPreferencesKey("videoModeEnabled")

val PersistentQueueKey = booleanPreferencesKey("persistentQueue")
val PersistentShuffleAcrossQueuesKey = booleanPreferencesKey("persistentShuffleAcrossQueues")
val RememberShuffleAndRepeatKey = booleanPreferencesKey("rememberShuffleAndRepeat")
val ShuffleModeKey = booleanPreferencesKey("shuffleMode")
val SkipSilenceKey = booleanPreferencesKey("skipSilence")
val SkipSilenceInstantKey = booleanPreferencesKey("skipSilenceInstant")
val AudioNormalizationKey = booleanPreferencesKey("audioNormalization")
val LateNightModeKey = booleanPreferencesKey("lateNightMode")
val AutoLoadMoreKey = booleanPreferencesKey("autoLoadMore")
val DisableLoadMoreWhenRepeatAllKey = booleanPreferencesKey("disableLoadMoreWhenRepeatAll")
val AutoDownloadOnLikeKey = booleanPreferencesKey("autoDownloadOnLike")
val SimilarContent = booleanPreferencesKey("similarContent")
val AutoSkipNextOnErrorKey = booleanPreferencesKey("autoSkipNextOnError")
val StopMusicOnTaskClearKey = booleanPreferencesKey("stopMusicOnTaskClear")
val ShufflePlaylistFirstKey = booleanPreferencesKey("shufflePlaylistFirst")
val CrossfadeEnabledKey = booleanPreferencesKey("crossfadeEnabled")
val CrossfadeDurationKey = floatPreferencesKey("crossfadeDuration")
val CrossfadeGaplessKey = booleanPreferencesKey("crossfadeGapless")
val CrossfadeCurveKey = stringPreferencesKey("crossfadeCurve")

enum class CrossfadeCurve {
    SMOOTH,
    EQUAL_POWER,
    LINEAR,
}

val AutomixEnabledKey = booleanPreferencesKey("automixEnabled")
val AutomixBlendPercentKey = floatPreferencesKey("automixBlendPercent")

val SleepTimerFadeOutEnabledKey = booleanPreferencesKey("sleepTimerFadeOutEnabled")
val SleepTimerFadeOutDurationKey = floatPreferencesKey("sleepTimerFadeOutDuration")
val SleepTimerDefaultDurationKey = floatPreferencesKey("sleepTimerDefaultDuration")

val MaxImageCacheSizeKey = intPreferencesKey("maxImageCacheSize")
val MaxSongCacheSizeKey = intPreferencesKey("maxSongCacheSize")

val PauseListenHistoryKey = booleanPreferencesKey("pauseListenHistory")
val PauseSearchHistoryKey = booleanPreferencesKey("pauseSearchHistory")
val DisableScreenshotKey = booleanPreferencesKey("disableScreenshot")

val DiscordTokenKey = stringPreferencesKey("discordToken")
val DiscordInfoDismissedKey = booleanPreferencesKey("discordInfoDismissed")
val DiscordUsernameKey = stringPreferencesKey("discordUsername")
val DiscordNameKey = stringPreferencesKey("discordName")
val DiscordAvatarUrlKey = stringPreferencesKey("discordAvatarUrl")
val EnableDiscordRPCKey = booleanPreferencesKey("discordRPCEnable")
val DiscordUseDetailsKey = booleanPreferencesKey("discordUseDetails")

// Google Cast
val EnableGoogleCastKey = booleanPreferencesKey("enableGoogleCast")

// SponsorBlock
val SponsorBlockEnabledKey = booleanPreferencesKey("sponsorBlockEnabled")
val SponsorBlockSkipSponsorKey = booleanPreferencesKey("sponsorBlockSkipSponsor")
val SponsorBlockSkipIntroKey = booleanPreferencesKey("sponsorBlockSkipIntro")
val SponsorBlockSkipOutroKey = booleanPreferencesKey("sponsorBlockSkipOutro")
val SponsorBlockSkipSelfPromoKey = booleanPreferencesKey("sponsorBlockSkipSelfPromo")
val SponsorBlockSkipInteractionKey = booleanPreferencesKey("sponsorBlockSkipInteraction")
val SponsorBlockSkipPreviewKey = booleanPreferencesKey("sponsorBlockSkipPreview")
val SponsorBlockSkipMusicOffTopicKey = booleanPreferencesKey("sponsorBlockSkipMusicOffTopic")
val SponsorBlockSkipFillerKey = booleanPreferencesKey("sponsorBlockSkipFiller")

// Listen Together
val ListenTogetherServerUrlKey = stringPreferencesKey("listenTogetherServerUrl")
val ListenTogetherUsernameKey = stringPreferencesKey("listenTogetherUsername")
val EnableListenTogetherKey = booleanPreferencesKey("enableListenTogether")
val ListenTogetherAutoApprovalKey = booleanPreferencesKey("listenTogetherAutoApproval")
val ListenTogetherSyncVolumeKey = booleanPreferencesKey("listenTogetherSyncVolume")
val ListenTogetherBlockedUsersKey = stringPreferencesKey("listenTogetherBlockedUsers")
// Session persistence for reconnection
val ListenTogetherSessionTokenKey = stringPreferencesKey("listenTogetherSessionToken")
val ListenTogetherRoomCodeKey = stringPreferencesKey("listenTogetherRoomCode")
val ListenTogetherUserIdKey = stringPreferencesKey("listenTogetherUserId")
val ListenTogetherIsHostKey = booleanPreferencesKey("listenTogetherIsHost")
val ListenTogetherSessionTimestampKey = longPreferencesKey("listenTogetherSessionTimestamp")

// Android TV Settings
val TvHdmiCecEnabledKey = booleanPreferencesKey("tvHdmiCecEnabled")
val TvAutoPlayOnBootKey = booleanPreferencesKey("tvAutoPlayOnBoot")
val TvScreenSaverTimeoutKey = intPreferencesKey("tvScreenSaverTimeout")
val TvAudioOutputKey = stringPreferencesKey("tvAudioOutput")

val LastFMSessionKey = stringPreferencesKey("lastfmSession")
val LastFMUsernameKey = stringPreferencesKey("lastfmUsername")
val EnableLastFMScrobblingKey = booleanPreferencesKey("lastfmScrobblingEnable")
val LastFMUseNowPlaying = booleanPreferencesKey("lastfmUseNowPlaying")

val LastFMUseSendLikes = booleanPreferencesKey("lastfmUseSendLikes")

val ScrobbleDelayPercentKey = floatPreferencesKey("scrobbleDelayPercent")
val ScrobbleMinSongDurationKey = intPreferencesKey("scrobbleMinSongDuration")
val ScrobbleDelaySecondsKey = intPreferencesKey("scrobbleDelaySeconds")

val ChipSortTypeKey = stringPreferencesKey("chipSortType")
val SongSortTypeKey = stringPreferencesKey("songSortType")
val SongSortDescendingKey = booleanPreferencesKey("songSortDescending")
val PlaylistSongSortTypeKey = stringPreferencesKey("playlistSongSortType")
val PlaylistSongSortDescendingKey = booleanPreferencesKey("playlistSongSortDescending")
val AutoPlaylistSongSortTypeKey = stringPreferencesKey("autoPlaylistSongSortType")
val AutoPlaylistSongSortDescendingKey = booleanPreferencesKey("autoPlaylistSongSortDescending")
val ArtistSortTypeKey = stringPreferencesKey("artistSortType")
val ArtistSortDescendingKey = booleanPreferencesKey("artistSortDescending")
val AlbumSortTypeKey = stringPreferencesKey("albumSortType")
val AlbumSortDescendingKey = booleanPreferencesKey("albumSortDescending")
val PlaylistSortTypeKey = stringPreferencesKey("playlistSortType")
val PlaylistSortDescendingKey = booleanPreferencesKey("playlistSortDescending")
val AddToPlaylistSortTypeKey = stringPreferencesKey("addToPlaylistSortType")
val AddToPlaylistSortDescendingKey = booleanPreferencesKey("playlistSortDescending")
val ArtistSongSortTypeKey = stringPreferencesKey("artistSongSortType")
val ArtistSongSortDescendingKey = booleanPreferencesKey("artistSongSortDescending")
val MixSortTypeKey = stringPreferencesKey("mixSortType")
val MixSortDescendingKey = booleanPreferencesKey("albumSortDescending")

val SongFilterKey = stringPreferencesKey("songFilter")
val ArtistFilterKey = stringPreferencesKey("artistFilter")
val AlbumFilterKey = stringPreferencesKey("albumFilter")

val LastLikeSongSyncKey = longPreferencesKey("last_like_song_sync")
val LastLibSongSyncKey = longPreferencesKey("last_library_song_sync")
val LastAlbumSyncKey = longPreferencesKey("last_album_sync")
val LastArtistSyncKey = longPreferencesKey("last_artist_sync")
val LastPlaylistSyncKey = longPreferencesKey("last_playlist_sync")
val LastFullSyncKey = longPreferencesKey("last_full_sync")

// Sync cooldown in seconds (30 minutes)
const val SYNC_COOLDOWN = 30 * 60L

val ArtistViewTypeKey = stringPreferencesKey("artistViewType")
val AlbumViewTypeKey = stringPreferencesKey("albumViewType")
val PlaylistViewTypeKey = stringPreferencesKey("playlistViewType")

val PlaylistEditLockKey = booleanPreferencesKey("playlistEditLock")
val QuickPicksKey = stringPreferencesKey("discover")
val PreferredLyricsProviderKey = stringPreferencesKey("lyricsProvider")
val LyricsProviderOrderKey = stringPreferencesKey("lyricsProviderOrder")
val QueueEditLockKey = booleanPreferencesKey("queueEditLock")
val ShowWrappedCardKey = booleanPreferencesKey("show_wrapped_card")
val WrappedSeenKey = booleanPreferencesKey("wrapped_seen")
val LastWrappedMonthKey = stringPreferencesKey("last_wrapped_month") // Format: "YYYY-MM"

val ShowLikedPlaylistKey = booleanPreferencesKey("show_liked_playlist")
val ShowDownloadedPlaylistKey = booleanPreferencesKey("show_downloaded_playlist")
val ShowTopPlaylistKey = booleanPreferencesKey("show_top_playlist")
val ShowCachedPlaylistKey = booleanPreferencesKey("show_cached_playlist")
val ShowUploadedPlaylistKey = booleanPreferencesKey("show_uploaded_playlist")

val AudioStyleModeKey = stringPreferencesKey("audio_style_mode")

enum class AudioStyleMode(
    val label: String,
    val description: String,
    val speed: Float,
    val pitch: Float,
    val reverbEnabled: Boolean,
) {
    NORMAL(
        label = "Normal",
        description = "Lagu apa adanya",
        speed = 1.0f,
        pitch = 1.0f,
        reverbEnabled = false,
    ),
    SPEED_UP(
        label = "Sped up",
        description = "Lebih cepat dan tinggi, seperti versi sped up",
        speed = 1.20f,
        pitch = 1.20f,
        reverbEnabled = false,
    ),
    SLOWED_REVERB(
        label = "Slowed + reverb",
        description = "Lebih pelan dan rendah, dengan gema lembut",
        speed = 0.86f,
        pitch = 0.86f,
        reverbEnabled = true,
    ),
    SUPER_SLOWED(
        label = "Super slowed",
        description = "Jauh lebih pelan dan rendah, dengan gema dalam",
        speed = 0.72f,
        pitch = 0.72f,
        reverbEnabled = true,
    ),
    NIGHTCORE(
        label = "Nightcore",
        description = "Jauh lebih cepat dan tinggi, 1.4x",
        speed = 1.40f,
        pitch = 1.40f,
        reverbEnabled = false,
    ),
    LOFI(
        label = "Lo-fi",
        description = "Hangat dan santai, sedikit lebih pelan, dengan gema tipis",
        speed = 0.94f,
        pitch = 0.94f,
        reverbEnabled = true,
    ),
    EIGHT_D(
        label = "8D",
        description = "Suara berputar di sekeliling kepala. Paling enak pakai headset",
        speed = 1.0f,
        pitch = 1.0f,
        reverbEnabled = true,
    ),
    CONCERT(
        label = "Konser",
        description = "Gema ruangan besar seperti aula konser",
        speed = 1.0f,
        pitch = 1.0f,
        reverbEnabled = true,
    ),
}

enum class LibraryViewType {
    LIST,
    GRID,
    ;

    fun toggle() =
        when (this) {
            LIST -> GRID
            GRID -> LIST
        }
}

enum class SongFilter {
    LIBRARY,
    LIKED,
    DOWNLOADED,
    UPLOADED
}

enum class ArtistFilter {
    LIBRARY,
    LIKED
}

enum class AlbumFilter {
    LIBRARY,
    LIKED,
    UPLOADED
}

enum class SongSortType {
    CREATE_DATE,
    NAME,
    ARTIST,
    PLAY_TIME,
}

enum class PlaylistSongSortType {
    CUSTOM,
    CREATE_DATE,
    NAME,
    ARTIST,
    PLAY_TIME,
}

enum class AutoPlaylistSongSortType {
    CREATE_DATE,
    NAME,
    ARTIST,
    PLAY_TIME,
}

enum class ArtistSortType {
    CREATE_DATE,
    NAME,
    SONG_COUNT,
    PLAY_TIME,
}

enum class ArtistSongSortType {
    CREATE_DATE,
    NAME,
    PLAY_TIME,
}

enum class AlbumSortType {
    CREATE_DATE,
    NAME,
    ARTIST,
    YEAR,
    SONG_COUNT,
    LENGTH,
    PLAY_TIME,
}

enum class PlaylistSortType {
    CREATE_DATE,
    NAME,
    SONG_COUNT,
    LAST_UPDATED,
}

enum class MixSortType {
    CREATE_DATE,
    NAME,
    LAST_UPDATED,
}

enum class GridItemSize {
    BIG,
    SMALL,
}

enum class MyTopFilter {
    ALL_TIME,
    DAY,
    WEEK,
    MONTH,
    YEAR,
    ;

    fun toTimeMillis(): Long =
        when (this) {
            DAY ->
                LocalDateTime
                    .now()
                    .minusDays(1)
                    .toInstant(ZoneOffset.UTC)
                    .toEpochMilli()

            WEEK ->
                LocalDateTime
                    .now()
                    .minusWeeks(1)
                    .toInstant(ZoneOffset.UTC)
                    .toEpochMilli()

            MONTH ->
                LocalDateTime
                    .now()
                    .minusMonths(1)
                    .toInstant(ZoneOffset.UTC)
                    .toEpochMilli()

            YEAR ->
                LocalDateTime
                    .now()
                    .minusMonths(12)
                    .toInstant(ZoneOffset.UTC)
                    .toEpochMilli()

            ALL_TIME -> 0
        }
}

enum class QuickPicks {
    QUICK_PICKS,
    LAST_LISTEN,
}

enum class PreferredLyricsProvider {
    SIMPMUSIC,
    BETTER_LYRICS,
    LRCLIB,
    RUSH_LYRICS,
    PAXSENIX,
    MUSIXMATCH,
    KUGOU,
}

enum class PlayerButtonsStyle {
    DEFAULT,
    PRIMARY,
    TERTIARY
}

enum class PlayerBackgroundStyle {
    DEFAULT,
    GRADIENT,
    BLUR,
    ANIMATED_GRADIENT,
}

val TopSize = stringPreferencesKey("topSize")
val HistoryDuration = floatPreferencesKey("historyDuration")

val PlayerButtonsStyleKey = stringPreferencesKey("player_buttons_style")
val PlayerBackgroundStyleKey = stringPreferencesKey("playerBackgroundStyle")
val ShowLyricsKey = booleanPreferencesKey("showLyrics")
val TvShowLyricsKey = booleanPreferencesKey("tvShowLyrics")
val LyricsTextPositionKey = stringPreferencesKey("lyricsTextPosition")
val LyricsClickKey = booleanPreferencesKey("lyricsClick")
val LyricsScrollKey = booleanPreferencesKey("lyricsScrollKey")
val LyricsRomanizeJapaneseKey = booleanPreferencesKey("lyricsRomanizeJapanese")
val LyricsRomanizeKoreanKey = booleanPreferencesKey("lyricsRomanizeKorean")
val LyricsRomanizeChineseKey = booleanPreferencesKey("lyricsRomanizeChinese")
val LyricsRomanizeRussianKey = booleanPreferencesKey("lyricsRomanizeRussian")
val LyricsRomanizeUkrainianKey = booleanPreferencesKey("lyricsRomanizeUkrainian")
val LyricsRomanizeSerbianKey = booleanPreferencesKey("lyricsRomanizeSerbian")
val LyricsRomanizeBulgarianKey = booleanPreferencesKey("lyricsRomanizeBulgarian")
val LyricsRomanizeBelarusianKey = booleanPreferencesKey("lyricsRomanizeBelarusian")
val LyricsRomanizeKyrgyzKey = booleanPreferencesKey("lyricsRomanizeKyrgyz")
val LyricsRomanizeMacedonianKey = booleanPreferencesKey("lyricsRomanizeMacedonian")
val LyricsRomanizeHindiKey = booleanPreferencesKey("lyricsRomanizeHindi")
val LyricsRomanizePunjabiKey = booleanPreferencesKey("lyricsRomanizePunjabi")
val LyricsRomanizeAsMainKey = booleanPreferencesKey("lyricsRomanizeAsMain")
val LyricsRomanizeCyrillicByLineKey = booleanPreferencesKey("lyricsRomanizeCyrillicByLine")
val EnhancedLyricsKey = booleanPreferencesKey("enhancedLyrics")
val TranslateLyricsKey = booleanPreferencesKey("translateLyrics")
val VideoLyricsOffsetKey = intPreferencesKey("videoLyricsOffset")
val VideoLyricsEnabledKey = booleanPreferencesKey("videoLyricsEnabled")

enum class VideoLyricsCardStyle {
    NORMAL, // Tanpa CD, hanya gambar album dan nama musik serta artis di bawahnya
    KASET;  // CD / Kaset jewel case dengan disc berputar
}

enum class VideoLyricsEffectStyle {
    KINETIC_SHAKE, // Efek Alight Motion: Camera Shake, 3D Sway, Zoom Beat, Word-by-Word Pop + Vertical Motion Blur & Glow (seperti di video)
    SMOOTH_FLOAT,  // Efek 3D Mengambang Halus + Glow tanpa getaran kuat
    STATIC_CLASSIC // Klasik Statis (hanya teks naik)
}

val VideoLyricsCardStyleKey = stringPreferencesKey("videoLyricsCardStyle")
val VideoLyricsEffectStyleKey = stringPreferencesKey("videoLyricsEffectStyle")
val VideoLyricsScalePercentKey = intPreferencesKey("videoLyricsScalePercent")
val VideoLyricsOffsetXPercentKey = intPreferencesKey("videoLyricsOffsetXPercent")
val VideoLyricsOffsetYPercentKey = intPreferencesKey("videoLyricsOffsetYPercent")
val VideoLyricsCardScalePercentKey = intPreferencesKey("videoLyricsCardScalePercent")
val VideoLyricsCardOffsetXPercentKey = intPreferencesKey("videoLyricsCardOffsetXPercent")
val VideoLyricsCardOffsetYPercentKey = intPreferencesKey("videoLyricsCardOffsetYPercent")
val VideoLyricsCardAlphaPercentKey = intPreferencesKey("videoLyricsCardAlphaPercent")
val VideoLyricsLineSpacingPercentKey = intPreferencesKey("videoLyricsLineSpacingPercent")
val VideoLyricsShowUpcomingKey = booleanPreferencesKey("videoLyricsShowUpcoming")
val VideoLyricsHideInactiveKey = booleanPreferencesKey("videoLyricsHideInactive")
val VideoLyricsJedagJedugKey = booleanPreferencesKey("videoLyricsJedagJedug")
val VideoLyricsSnowKey = booleanPreferencesKey("videoLyricsSnow")
val VideoLyricsWaveAmplitudePercentKey = intPreferencesKey("videoLyricsWaveAmplitudePercent")
val VideoLyricsWaveSpeedPercentKey = intPreferencesKey("videoLyricsWaveSpeedPercent")
val VideoLyricsLyricsRotationKey = intPreferencesKey("videoLyricsLyricsRotation")
val VideoLyricsCardRotationKey = intPreferencesKey("videoLyricsCardRotation")
val OpenRouterApiKey = stringPreferencesKey("openRouterApiKey")
val AiProviderKey = stringPreferencesKey("aiProvider")
val OpenRouterBaseUrlKey = stringPreferencesKey("openRouterBaseUrl")
val OpenRouterModelKey = stringPreferencesKey("openRouterModel")
val AutoTranslateLyricsKey = booleanPreferencesKey("autoTranslateLyrics")
val AutoTranslateLyricsMismatchKey = booleanPreferencesKey("autoTranslateLyricsMismatch")
val TranslateModeKey = stringPreferencesKey("translateMode")
val TranslateLanguageKey = stringPreferencesKey("translateLanguage")
val LyricsTranslationProviderKey = stringPreferencesKey("lyricsTranslationProvider")

const val LYRICS_TRANSLATION_PROVIDER_AUTO = "Auto"
const val LYRICS_TRANSLATION_PROVIDER_GOOGLE = "Google"
const val LYRICS_TRANSLATION_PROVIDER_GOOGLE_CLIENTS5 = "Google (Clients5)"
const val LYRICS_TRANSLATION_PROVIDER_MYMEMORY = "MyMemory"
const val LYRICS_TRANSLATION_PROVIDER_AI = "AI Kustom"
val LyricsGlowEffectKey = booleanPreferencesKey("lyricsGlowEffect")
val LiquidGlassEffectKey = booleanPreferencesKey("liquidGlassEffect")
val LiquidGlassBlurRadiusKey = floatPreferencesKey("liquidGlassBlurRadius")
val LiquidGlassCornerRadiusKey = floatPreferencesKey("liquidGlassCornerRadius")
val LiquidGlassOpacityKey = floatPreferencesKey("liquidGlassOpacity")
val LiquidGlassApplyHomeCardsKey = booleanPreferencesKey("liquidGlassApplyHomeCards")
val LiquidGlassApplyPlayerKey = booleanPreferencesKey("liquidGlassApplyPlayer")
val LiquidGlassApplyNavBarKey = booleanPreferencesKey("liquidGlassApplyNavBar")

// Home layout
enum class HomeLayoutMode {
    LIST,
    GRID;

    fun toggle() = when (this) {
        LIST -> GRID
        GRID -> LIST
    }
}

val HomeLayoutModeKey = stringPreferencesKey("homeLayoutMode")

// Mini player customization
val MiniPlayerHeightKey = floatPreferencesKey("miniPlayerHeight")
val MiniPlayerCornerRadiusKey = floatPreferencesKey("miniPlayerCornerRadius")
val MiniPlayerShowFavoriteKey = booleanPreferencesKey("miniPlayerShowFavorite")
val MiniPlayerShowSubscribeKey = booleanPreferencesKey("miniPlayerShowSubscribe")
val MiniPlayerShowPlayPauseKey = booleanPreferencesKey("miniPlayerShowPlayPause")
val MiniPlayerShowHardwareKey = booleanPreferencesKey("miniPlayerShowHardware")

// Dynamic Island (Opt-in feature, default OFF)
enum class DynamicIslandMode {
    KECIL,
    SEDANG,
    BOLA
}

enum class DynamicIslandTheme {
    NORMAL,
    LIQUID_GLASS
}

val DynamicIslandEnabledKey = booleanPreferencesKey("dynamicIslandEnabled")
val DynamicIslandAutoEnableOnStartKey = booleanPreferencesKey("dynamicIslandAutoEnableOnStart")
val DynamicIslandDismissedKey = booleanPreferencesKey("dynamicIslandDismissed")
val DynamicIslandModeKey = stringPreferencesKey("dynamicIslandMode")
val DynamicIslandThemeKey = stringPreferencesKey("dynamicIslandTheme")
val DynamicIslandAccentColorKey = intPreferencesKey("dynamicIslandAccentColor")
val DynamicIslandUseDynamicAccentKey = booleanPreferencesKey("dynamicIslandUseDynamicAccent")
val DynamicIslandBgColorKey = intPreferencesKey("dynamicIslandBgColor")
val DynamicIslandUseDynamicBgKey = booleanPreferencesKey("dynamicIslandUseDynamicBg")
val DynamicIslandBorderGlowKey = booleanPreferencesKey("dynamicIslandBorderGlow")
val DynamicIslandBlurEnabledKey = booleanPreferencesKey("dynamicIslandBlurEnabled")
val DynamicIslandBlurRadiusKey = intPreferencesKey("dynamicIslandBlurRadius")
val DynamicIslandPermissionConfirmedKey = booleanPreferencesKey("dynamicIslandPermissionConfirmed")

val LyricsAnimationStyleKey = stringPreferencesKey("lyricsAnimationStyle")
enum class LyricsAnimationStyle {
    NONE,
    FADE,
    GLOW,
    SLIDE,
    KARAOKE,
    APPLE,
}

// Preferences used by the Enhanced Lyrics renderer.
val RespectAgentPositioningKey = booleanPreferencesKey("respectAgentPositioning")
val ShowIntervalIndicatorKey = booleanPreferencesKey("showIntervalIndicator")

// OpenRouter default values reused by both legacy and Enhanced lyrics paths.
const val OpenRouterDefaultBaseUrl = "https://openrouter.ai/api/v1/chat/completions"
const val OpenRouterDefaultModel = "mistralai/mistral-small-3.1-24b-instruct:free"

val LyricsTextSizeKey = floatPreferencesKey("lyricsTextSize")
val LyricsLineSpacingKey = floatPreferencesKey("lyricsLineSpacing")

// Show a music-symbol indicator with a progress bar between lyric lines
// when the silence/instrumental gap is at least this many milliseconds.
// 0 disables the feature.
val LyricsInstrumentalGapMsKey = intPreferencesKey("lyricsInstrumentalGapMs")

// When true, neighbouring lyric lines whose word-timings still cover the
// playback position remain "active" so word-by-word animations are not
// cut off when a new line starts (e.g. background {bg} vocals).
val LyricsConnectedLinesKey = booleanPreferencesKey("lyricsConnectedLines")

// Optional user-selected font (URI of a .ttf/.otf file) used to render lyrics.
// Empty string means "use the system default".
val LyricsCustomFontUriKey = stringPreferencesKey("lyricsCustomFontUri")

val LyricsFontKey = stringPreferencesKey("lyricsFont")
enum class LyricsFont {
    SYSTEM_DEFAULT,
    OUTFIT,
    MANROPE,
    SPACE_GROTESK,
}

val PlayerVolumeKey = floatPreferencesKey("playerVolume")
val RepeatModeKey = intPreferencesKey("repeatMode")

val AudiobookIdsKey = stringPreferencesKey("audiobookIds")
val AudiobookPositionsKey = stringPreferencesKey("audiobookPositions")

val SearchSourceKey = stringPreferencesKey("searchSource")
val SwipeThumbnailKey = booleanPreferencesKey("swipeThumbnail")
val SwipeSensitivityKey = floatPreferencesKey("swipeSensitivity")

enum class SearchSource {
    LOCAL,
    ONLINE,
    ;

    fun toggle() =
        when (this) {
            LOCAL -> ONLINE
            ONLINE -> LOCAL
        }
}

val VisitorDataKey = stringPreferencesKey("visitorData")
val DataSyncIdKey = stringPreferencesKey("dataSyncId")
val InnerTubeCookieKey = stringPreferencesKey("innerTubeCookie")
val AccountNameKey = stringPreferencesKey("accountName")
val AccountEmailKey = stringPreferencesKey("accountEmail")
val AccountChannelHandleKey = stringPreferencesKey("accountChannelHandle")
val UseLoginForBrowse = booleanPreferencesKey("useLoginForBrowse")
val EnableLevelGifIconsKey = booleanPreferencesKey("enableLevelGifIcons")

val LanguageCodeToName =
    mapOf(
        "af" to "Afrikaans",
        "az" to "Azərbaycan",
        "id" to "Bahasa Indonesia",
        "ms" to "Bahasa Malaysia",
        "ca" to "Català",
        "cs" to "Čeština",
        "da" to "Dansk",
        "de" to "Deutsch",
        "et" to "Eesti",
        "en-GB" to "English (UK)",
        "en" to "English (US)",
        "es" to "Español (España)",
        "es-419" to "Español (Latinoamérica)",
        "eu" to "Euskara",
        "fil" to "Filipino",
        "fr" to "Français",
        "fr-CA" to "Français (Canada)",
        "gl" to "Galego",
        "hr" to "Hrvatski",
        "zu" to "IsiZulu",
        "is" to "Íslenska",
        "it" to "Italiano",
        "sw" to "Kiswahili",
        "lt" to "Lietuvių",
        "hu" to "Magyar",
        "nl" to "Nederlands",
        "no" to "Norsk",
        "or" to "Odia",
        "uz" to "O‘zbe",
        "pl" to "Polski",
        "pt-PT" to "Português",
        "pt" to "Português (Brasil)",
        "ro" to "Română",
        "sq" to "Shqip",
        "sk" to "Slovenčina",
        "sl" to "Slovenščina",
        "fi" to "Suomi",
        "sv" to "Svenska",
        "bo" to "Tibetan བོད་སྐད།",
        "vi" to "Tiếng Việt",
        "tr" to "Türkçe",
        "bg" to "Български",
        "ky" to "Кыргызча",
        "kk" to "Қазақ Тілі",
        "mk" to "Македонски",
        "mn" to "Монгол",
        "ru" to "Русский",
        "sr" to "Српски",
        "uk" to "Українська",
        "el" to "Ελληνικά",
        "hy" to "Հայերեն",
        "iw" to "עברית",
        "ur" to "اردو",
        "ar" to "العربية",
        "fa" to "فارسی",
        "ne" to "नेपाली",
        "mr" to "मराठी",
        "hi" to "हिन्दी",
        "bn" to "বাংলা",
        "pa" to "ਪੰਜਾਬੀ",
        "gu" to "ગુજરાતી",
        "ta" to "தமிழ்",
        "te" to "తెలుగు",
        "kn" to "ಕನ್ನಡ",
        "ml" to "മലയാളം",
        "si" to "සිංහල",
        "th" to "ภาษาไทย",
        "lo" to "ລາວ",
        "my" to "ဗမာ",
        "ka" to "ქართული",
        "am" to "አማርኛ",
        "km" to "ខ្មែរ",
        "zh-CN" to "中文 (简体)",
        "zh-TW" to "中文 (繁體)",
        "zh-HK" to "中文 (香港)",
        "ja" to "日本語",
        "ko" to "한국어",
    )

val CountryCodeToName =
    mapOf(
        "DZ" to "Algeria",
        "AR" to "Argentina",
        "AU" to "Australia",
        "AT" to "Austria",
        "AZ" to "Azerbaijan",
        "BH" to "Bahrain",
        "BD" to "Bangladesh",
        "BY" to "Belarus",
        "BE" to "Belgium",
        "BO" to "Bolivia",
        "BA" to "Bosnia and Herzegovina",
        "BR" to "Brazil",
        "BG" to "Bulgaria",
        "KH" to "Cambodia",
        "CA" to "Canada",
        "CL" to "Chile",
        "HK" to "Hong Kong",
        "CO" to "Colombia",
        "CR" to "Costa Rica",
        "HR" to "Croatia",
        "CY" to "Cyprus",
        "CZ" to "Czech Republic",
        "DK" to "Denmark",
        "DO" to "Dominican Republic",
        "EC" to "Ecuador",
        "EG" to "Egypt",
        "SV" to "El Salvador",
        "EE" to "Estonia",
        "FI" to "Finland",
        "FR" to "France",
        "GE" to "Georgia",
        "DE" to "Germany",
        "GH" to "Ghana",
        "GR" to "Greece",
        "GT" to "Guatemala",
        "HN" to "Honduras",
        "HU" to "Hungary",
        "IS" to "Iceland",
        "IN" to "India",
        "ID" to "Indonesia",
        "IQ" to "Iraq",
        "IE" to "Ireland",
        "IL" to "Israel",
        "IT" to "Italy",
        "JM" to "Jamaica",
        "JP" to "Japan",
        "JO" to "Jordan",
        "KZ" to "Kazakhstan",
        "KE" to "Kenya",
        "KR" to "South Korea",
        "KW" to "Kuwait",
        "LA" to "Lao",
        "LV" to "Latvia",
        "LB" to "Lebanon",
        "LY" to "Libya",
        "LI" to "Liechtenstein",
        "LT" to "Lithuania",
        "LU" to "Luxembourg",
        "MK" to "Macedonia",
        "MY" to "Malaysia",
        "MT" to "Malta",
        "MX" to "Mexico",
        "ME" to "Montenegro",
        "MA" to "Morocco",
        "NP" to "Nepal",
        "NL" to "Netherlands",
        "NZ" to "New Zealand",
        "NI" to "Nicaragua",
        "NG" to "Nigeria",
        "NO" to "Norway",
        "OM" to "Oman",
        "PK" to "Pakistan",
        "PA" to "Panama",
        "PG" to "Papua New Guinea",
        "PY" to "Paraguay",
        "PE" to "Peru",
        "PH" to "Philippines",
        "PL" to "Poland",
        "PT" to "Portugal",
        "PR" to "Puerto Rico",
        "QA" to "Qatar",
        "RO" to "Romania",
        "RU" to "Russian Federation",
        "SA" to "Saudi Arabia",
        "SN" to "Senegal",
        "RS" to "Serbia",
        "SG" to "Singapore",
        "SK" to "Slovakia",
        "SI" to "Slovenia",
        "ZA" to "South Africa",
        "ES" to "Spain",
        "LK" to "Sri Lanka",
        "SE" to "Sweden",
        "CH" to "Switzerland",
        "TW" to "Taiwan",
        "TZ" to "Tanzania",
        "TH" to "Thailand",
        "TN" to "Tunisia",
        "TR" to "Turkey",
        "UG" to "Uganda",
        "UA" to "Ukraine",
        "AE" to "United Arab Emirates",
        "GB" to "United Kingdom",
        "US" to "United States",
        "UY" to "Uruguay",
        "VE" to "Venezuela (Bolivarian Republic)",
        "VN" to "Vietnam",
        "YE" to "Yemen",
        "ZW" to "Zimbabwe",
    )
