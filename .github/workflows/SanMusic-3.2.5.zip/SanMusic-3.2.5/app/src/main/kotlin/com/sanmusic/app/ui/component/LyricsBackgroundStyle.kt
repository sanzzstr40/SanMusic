/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.ui.component

enum class LyricsBackgroundStyle {
    SOLID, BLUR, GRADIENT
}