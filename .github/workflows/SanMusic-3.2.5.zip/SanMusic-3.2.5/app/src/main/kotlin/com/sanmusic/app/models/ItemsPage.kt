/**
 * San Music Project (C) 2026
 */

package com.sanmusic.app.models

import com.sanmusic.innertube.models.YTItem

data class ItemsPage(
    val items: List<YTItem>,
    val continuation: String?,
)
