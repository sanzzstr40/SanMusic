import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.gradle.jvm.toolchain.JavaLanguageVersion
import java.util.Properties

val localProperties = Properties()
val localPropertiesFile = rootProject.file("local.properties")
if (localPropertiesFile.exists()) {
    localProperties.load(localPropertiesFile.inputStream())
}
plugins {
    id("com.android.application")
    alias(libs.plugins.hilt)
    alias(libs.plugins.kotlin.ksp)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.secrets)
}


android {
    namespace = "com.sanmusic.app"
    compileSdk = 36
    ndkVersion = "27.0.12077973"

    defaultConfig {
        applicationId = "com.sanmusic.app"
        minSdk = 24
        targetSdk = 36
        versionCode = 325
        versionName = "3.2.5"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true
        resourceConfigurations += listOf("in", "id")

        // LastFM API keys from GitHub Secrets
        val lastFmKey = localProperties.getProperty("LASTFM_API_KEY") ?: System.getenv("LASTFM_API_KEY") ?: ""
        val lastFmSecret = localProperties.getProperty("LASTFM_SECRET") ?: System.getenv("LASTFM_SECRET") ?: ""

        buildConfigField("String", "LASTFM_API_KEY", "\"$lastFmKey\"")
        buildConfigField("String", "LASTFM_SECRET", "\"$lastFmSecret\"")

        // BetterLyrics API key from GitHub Secrets
        val betterLyricsKey = localProperties.getProperty("BETTERLYRICS_API_KEY") ?: System.getenv("BETTERLYRICS_API_KEY") ?: ""
        buildConfigField("String", "BETTERLYRICS_API_KEY", "\"$betterLyricsKey\"")

        // Discord application ID used for OAuth2 login and Rich Presence
        buildConfigField("Long", "DISCORD_APP_ID", "1450052823617372160L")
    }
    
    externalNativeBuild {
        cmake {
            path("src/main/cpp/vibrafp/lib/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    flavorDimensions += listOf("variant", "ui", "abi")
    productFlavors {
        // FOSS variant (default) - F-Droid compatible, no Google Play Services
        create("foss") {
            dimension = "variant"
            isDefault = true
            buildConfigField("Boolean", "CAST_AVAILABLE", "false")
        }
        
        // GMS variant - with Google Cast support (requires Google Play Services)
        create("gms") {
            dimension = "variant"
            buildConfigField("Boolean", "CAST_AVAILABLE", "true")
        }

        // Architecture-specific release APKs. These intentionally use neither the FOSS nor
        // GMS flavor name; they share the non-Cast implementation without branding as FOSS.
        create("standalone") {
            dimension = "variant"
            buildConfigField("Boolean", "CAST_AVAILABLE", "false")
        }
        
        create("universal") {
            dimension = "abi"
            ndk {
                abiFilters += listOf("armeabi-v7a", "arm64-v8a")
            }
            buildConfigField("String", "ARCHITECTURE", "\"universal\"")
        }
        create("arm64") {
            dimension = "abi"
            ndk { abiFilters += "arm64-v8a" }
            buildConfigField("String", "ARCHITECTURE", "\"arm64\"")
        }
        create("armeabi") {
            dimension = "abi"
            ndk { abiFilters += "armeabi-v7a" }
            buildConfigField("String", "ARCHITECTURE", "\"armeabi\"")
        }
        create("x86") {
            dimension = "abi"
            ndk { abiFilters += "x86" }
            buildConfigField("String", "ARCHITECTURE", "\"x86\"")
        }
        create("x86_64") {
            dimension = "abi"
            ndk { abiFilters += "x86_64" }
            buildConfigField("String", "ARCHITECTURE", "\"x86_64\"")
        }

        create("mobile") {
            dimension = "ui"
            isDefault = true
        }

        create("tv") {
            dimension = "ui"
        }
    }

    sourceSets {
        getByName("main") {
            kotlin.srcDir("src/main/kotlin")
        }
        getByName("foss") {
            kotlin.srcDirs("src/foss/kotlin")
        }
        getByName("gms") {
            kotlin.srcDirs("src/gms/kotlin")
        }
        getByName("standalone") {
            kotlin.srcDirs("src/foss/kotlin")
            manifest.srcFile("src/foss/AndroidManifest.xml")
        }
        getByName("tv") {
            kotlin.srcDirs("src/tv/kotlin")
            res.srcDirs("src/tv/res")
        }
    }

    signingConfigs {
        // Load from local.properties for persistent debug and release builds
        create("persistentDebug") {
            val storeFilePath = localProperties.getProperty("debug.persistent.storeFile", "")
            if (storeFilePath.isNotEmpty()) {
                storeFile = file(storeFilePath)
            }
            storePassword = localProperties.getProperty("debug.persistent.storePassword", "android")
            keyAlias = localProperties.getProperty("debug.persistent.keyAlias", "androiddebugkey")
            keyPassword = localProperties.getProperty("debug.persistent.keyPassword", "android")
        }
        
        create("release") {
            val storeFilePath = localProperties.getProperty("release.storeFile", "")
            if (storeFilePath.isNotEmpty() && file(storeFilePath).exists()) {
                storeFile = file(storeFilePath)
                storePassword = localProperties.getProperty("release.storePassword", "android")
                keyAlias = localProperties.getProperty("release.keyAlias", "nanzbeatles")
                keyPassword = localProperties.getProperty("release.keyPassword", "android")
            } else if (file("keystore/release.keystore").exists()) {
                storeFile = file("keystore/release.keystore")
                storePassword = localProperties.getProperty("release.storePassword", "android")
                keyAlias = localProperties.getProperty("release.keyAlias", "nanzbeatles")
                keyPassword = localProperties.getProperty("release.keyPassword", "android")
            } else {
                storeFile = signingConfigs.getByName("debug").storeFile
                storePassword = signingConfigs.getByName("debug").storePassword
                keyAlias = signingConfigs.getByName("debug").keyAlias
                keyPassword = signingConfigs.getByName("debug").keyPassword
            }
        }
        
        getByName("debug") {
            val storeFilePath = localProperties.getProperty("debug.storeFile", "")
            if (storeFilePath.isNotEmpty() && file(storeFilePath).exists()) {
                storeFile = file(storeFilePath)
            }
            storePassword = localProperties.getProperty("debug.storePassword", "android")
            keyAlias = localProperties.getProperty("debug.keyAlias", "nanzbeatlesdebug")
            keyPassword = localProperties.getProperty("debug.keyPassword", "android")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isCrunchPngs = true
            isDebuggable = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
            externalNativeBuild {
                cmake {
                    arguments += listOf(
                        "-DENABLE_LTO=ON",
                        "-DCMAKE_BUILD_TYPE=Release"
                    )
                }
            }
            ndk {
                debugSymbolLevel = "NONE"
            }
        }
        debug {
            applicationIdSuffix = ".debug"
            isDebuggable = true
            signingConfig = signingConfigs.getByName("debug")
            externalNativeBuild {
                cmake {
                    arguments += listOf(
                        "-DENABLE_LTO=OFF",
                        "-DCMAKE_BUILD_TYPE=Debug"
                    )
                }
            }
            ndk {
                debugSymbolLevel = "FULL"
            }
        }
    }

    // Custom APK naming for TV builds
    tasks.register("renameTvApk") {
        doLast {
            val apkDir = layout.buildDirectory.dir("outputs/apk").get().asFile
            apkDir.walkTopDown().filter {
                it.isFile && it.name.endsWith(".apk") &&
                it.name.contains("tv", ignoreCase = true) &&
                it.name.contains("release", ignoreCase = true)
            }.forEach { apkFile ->
                val newName = "SanMusic-Tv.apk"
                val newFile = apkFile.parentFile.resolve(newName)
                apkFile.renameTo(newFile)
                println("Renamed TV APK: ${apkFile.name} -> $newName")
            }
        }
    }

    tasks.matching {
        it.name == "assembleFossTvUniversalRelease" || it.name == "assembleGmsTvUniversalRelease"
    }.configureEach {
        finalizedBy("renameTvApk")
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    kotlin {
        jvmToolchain(21)
        compilerOptions {
            freeCompilerArgs.addAll(
                "-Xannotation-default-target=param-property",
                "-Xno-param-assertions",
                "-Xno-call-assertions",
                "-Xno-receiver-assertions",
            )
            jvmTarget.set(JvmTarget.JVM_21)
        }
    }

    java {
        toolchain {
            languageVersion = JavaLanguageVersion.of(21)
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    lint {
        lintConfig = file("lint.xml")
        warningsAsErrors = false
        abortOnError = false
        checkDependencies = false
    }

    androidResources {
        generateLocaleConfig = true
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/NOTICE.md"
            excludes += "META-INF/CONTRIBUTORS.md"
            excludes += "META-INF/LICENSE.md"
            excludes += "META-INF/INDEX.LIST"
            excludes += "META-INF/io.netty.versions.properties"
            excludes += "META-INF/DEPENDENCIES"
            excludes += "META-INF/LICENSE"
            excludes += "META-INF/LICENSE.txt"
            excludes += "META-INF/license.txt"
            excludes += "META-INF/NOTICE"
            excludes += "META-INF/NOTICE.txt"
            excludes += "META-INF/notice.txt"
            excludes += "META-INF/ASL2.0"
            excludes += "META-INF/*.kotlin_module"
            excludes += "META-INF/proguard/**"
            excludes += "META-INF/*.version"
            excludes += "DebugProbesKt.bin"
            excludes += "kotlin-tooling-metadata.json"
        }
    }
}

secrets {
    propertiesFileName = ".env"
    defaultPropertiesFileName = ".env.example"
    ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

tasks.withType<org.jetbrains.kotlin.gradle.tasks.KotlinCompile>().configureEach {
    compilerOptions {
        freeCompilerArgs.addAll(
            "-opt-in=kotlin.RequiresOptIn"
        )
        suppressWarnings.set(false)
    }
}

dependencies {
    implementation(libs.guava)
    implementation(libs.coroutines.guava)
    implementation(libs.concurrent.futures)

    implementation(libs.activity)
    implementation(libs.hilt.navigation)
    implementation(libs.datastore)

    implementation(libs.compose.runtime)
    implementation(libs.compose.foundation)
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.util)
    implementation(libs.compose.ui.tooling)
    implementation(libs.compose.animation)
    implementation(libs.compose.reorderable)

    implementation(libs.viewmodel)
    implementation(libs.viewmodel.compose)

    implementation(libs.material3)
    implementation("androidx.compose.material:material-icons-extended:1.6.8")
    implementation(libs.palette)
    // Poster Musik Favorit: hapus background foto orang (model dibundel, offline)
    implementation(libs.mlkit.selfie.segmentation)
    implementation(libs.materialKolor)

    implementation(libs.appcompat)

    implementation(libs.coil)
    implementation(libs.coil.network.okhttp)
    implementation(libs.coil.gif)

    implementation(libs.ucrop)

    implementation(libs.shimmer)

    implementation(libs.media3)
    implementation(libs.media3.ui)
    implementation(libs.media3.session)
    implementation(libs.media3.okhttp)

    // Google Cast - only included in GMS flavor (not available in F-Droid/FOSS builds)
    "gmsImplementation"(libs.media3.cast)
    "gmsImplementation"(libs.mediarouter)
    "gmsImplementation"(libs.cast.framework)

    implementation(libs.room.runtime)
    implementation(libs.kuromoji.ipadic)
    implementation(libs.tinypinyin)
    ksp(libs.room.compiler)
    implementation(libs.room.ktx)

    implementation(libs.apache.lang3)

    implementation(libs.hilt)
    implementation(libs.jsoup)
    ksp(libs.hilt.compiler)

    // Ktor for networking
    implementation(libs.browser)
    implementation(libs.ktor.client.core)
    implementation(libs.ktor.client.cio)
    implementation(libs.ktor.client.okhttp)
    implementation(libs.ktor.client.content.negotiation)
    implementation(libs.ktor.serialization.json)

    // VOSK offline speech recognition (wake word detection)
    implementation("com.alphacephei:vosk-android:0.3.75") {
        exclude(group = "net.java.dev.jna")
    }
    // Force latest JNA to fix Android 16 (SDK 36) UnsatisfiedLinkError
    // in com.sun.jna.Pointer peer field resolution
    implementation("net.java.dev.jna:jna:5.19.1@aar")

    implementation(project(":innertube"))
    implementation(project(":auravideo"))
    implementation(project(":kugou"))
    implementation(project(":lrclib"))
    implementation(project(":lastfm"))
    implementation(project(":betterlyrics"))
    implementation(project(":musixmatch"))
    implementation(project(":simpmusic"))
    implementation(project(":shazamkit"))
    implementation(project(":rush"))
    implementation(project(":paxsenix"))

    // Protobuf for message serialization (lite version for Android)
    implementation(libs.protobuf.javalite)
    implementation(libs.protobuf.kotlin.lite)

    coreLibraryDesugaring(libs.desugaring)

    implementation(libs.timber)

    // Android TV support
    implementation("androidx.leanback:leanback:1.2.0-alpha04")
    implementation("androidx.leanback:leanback-preference:1.2.0-alpha04")
    implementation("androidx.tv:tv-material:1.0.0-beta01")
    implementation("androidx.tv:tv-foundation:1.0.0-beta01")
    implementation("androidx.tvprovider:tvprovider:1.0.0")
}

// Build via bot Telegram / `./gradlew assembleRelease` polos:
// kalau file `bot-build.flag` ada di root project, hanya varian fossMobileUniversal yang dibuat
// (tanpa flag, semua varian tetap seperti biasa, jadi workflow build.yml tidak terpengaruh).
androidComponents {
    beforeVariants { variant ->
        if (rootProject.file("bot-build.flag").exists()) {
            val names = variant.productFlavors.map { it.second }.toSet()
            if (!names.containsAll(setOf("foss", "universal", "mobile"))) {
                variant.enable = false
            }
        }
    }
}
